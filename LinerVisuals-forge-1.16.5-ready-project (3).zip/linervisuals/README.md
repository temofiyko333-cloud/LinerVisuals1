# Liner Visuals (Forge 1.16.5)

Клієнтський мод. Меню - **Right Shift** (клавіша змінюється в Керування -> Liner Visuals).

## Меню (чорно-білий стиль)
- Вкладки: Combat / Visual / HUD / Utility / Team / Servers / Status.
- ЛКМ по модулю - вмик/вимик. ПКМ - налаштування модуля (права панель).
- Клік по рамці з клавішею -> натисни кнопку -> бінд готовий. ESC - прибрати бінд.
- Вгорі праворуч ENABLED - головний перемикач (за замовчуванням F6).
- Status - живі показники: що ввімкнено, чи дозволені бойові модулі на цьому сервері, FPS, ping, ціль aim assist.
- За замовчуванням: Aim Assist - K, ESP - F7, Tracers - F8, Nametags - F9, Pulse - F10.

## Що в моді
Combat: Aim Assist, Triggerbot (б'є тільки коли приціл УЖЕ на ворозі), Shield Breaker (сокира -> удар -> одразу назад),
Auto Totem, Auto Armor, Team Protect.
Visual: ESP, Tracers, Nametags, Pulse, Hit Particles, Damage Text, Jump Rings, Pearl Path, Pearl Trail,
China Hat, Block Overlay, Hand Swing, Chroma/RGB, Fullbright, Freecam.
HUD: Watermark (Liner Visuals + FPS + ping зверху зліва), Potion Effects (справа посередині, з таймером),
Armor HUD (міцність броні/зброї), Target HUD, Ring Crosshair, Aim Hint, Module List, Coords & Death Point (координати, напрямок, незер-координати, місце смерті).
Utility: Auto Tool (сам бере найкращий інструмент/зброю), Auto Eat, Auto Fish (сам підсікає на поклювку й закидає знову; Auto cast, захист від зависання), Item Scroller, Streamer Mode, Command Binds.

Command Binds (вкладка Commands): вводиш команду (напр. /home), тиснеш ADD, клікаєш на клавішу біля неї й натискаєш кнопку.
Потім у грі ця кнопка одразу пише команду в чат і виконує її. Без "/" на початку - додасться автоматично.

Streamer Mode (вкладка Streamer): замінює ТВІЙ нік на обраний аліас у чаті, повідомленнях про смерть/вхід
і в таб-листі - лише на твоєму екрані, інші гравці бачать справжній нік. У меню справжній нік не показується.
Кожен елемент можна вимкнути окремо (FPS, ping, watermark - теж).

## Безпечний режим сервера
Косметика та інфо про себе (HUD, FPS/ping, партикли, вотермарка, ефекти, броня, China Hat, Streamer, бінди команд)
працюють на будь-якому сервері. Чити й автоматизація (aim assist, triggerbot, ESP, fullbright, freecam, auto-модулі,
траєкторія перла тощо) працюють лише в одиночній грі та на серверах зі списку Servers - на решті вони вимкнені
автоматично, у меню видно "SAFE MODE". Мод не ховається від античітів.

## Бойові модулі і сервери
Aim Assist, Triggerbot, Shield Breaker, Auto Totem працюють в одиночній грі та на серверах зі списку
(вкладка Servers; за замовчуванням: 2b2t.org, 9b9t.com, constantiam.net). Перемикач Combat lock там же
(або `restrictToAllowedServers` у конфігу) знімає обмеження. На серверах з правилами такі модулі = бан.

## Перевірка
- `sh tests/run.sh` - тести реальної логіки (конфіг, команди, наведення, triggerbot, streamer, колір) без запуску Minecraft.
- `TESTING.md` - чек-ліст для перевірки в грі.

## Збірка
1. JDK 8. Завантаж MDK Forge 1.16.5-36.2.39 (files.minecraftforge.net) і скопіюй з нього
   `gradlew`, `gradlew.bat` та папку `gradle/` у цю папку.
2. `./gradlew build` -> `build/libs/linervisuals-1.0.0.jar` -> у `.minecraft/mods` (Forge 1.16.5-36.2.x).
3. Для запуску з IDE: `./gradlew genIntellijRuns` (або `genEclipseRuns`), потім запусти runClient.

Конфіг: `.minecraft/config/linervisuals-client.toml`.
