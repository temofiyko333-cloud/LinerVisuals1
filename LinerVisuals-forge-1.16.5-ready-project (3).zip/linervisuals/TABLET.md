# Зібрати мод з планшета (грати потім на ПК)

Мод для ПК (Forge 1.16.5). Планшет потрібен лише щоб ЗІБРАТИ .jar - збірку робить безкоштовний сервер GitHub.
Нічого встановлювати на планшет не треба, тільки браузер.

## 1. Репозиторій
1. Відкрий github.com -> Sign up (або увійди). Якщо сайт показує мобільну версію - у меню браузера увімкни "Версія для ПК".
2. "+" (New repository) -> назва, наприклад `liner` -> Create repository.

## 2. Завантаж архів
3. У репозиторії: Add file -> Upload files -> вибери `LinerVisuals-forge-1.16.5.zip` (НЕ розпаковуй!) -> Commit changes.
   Назва файлу має бути саме `LinerVisuals-forge-1.16.5.zip` (якщо браузер додав "(1)" - перейменуй перед завантаженням).

## 3. Додай файл збірки
4. Add file -> Create new file. У полі імені введи: `.github/workflows/build.yml`
   (коли вводиш "/", GitHub сам створює папки).
5. Встав у велике поле цей текст без змін (відступи важливі - краще копіювати цілком):

```yaml
name: build-jar
on: workflow_dispatch
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Unzip project
        run: unzip -q LinerVisuals-forge-1.16.5.zip
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 8
      - uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: 7.4.2
      - name: Build
        working-directory: linervisuals
        run: gradle build --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: LinerVisuals-jar
          path: linervisuals/build/libs/*.jar
```
6. Commit changes.

## 4. Запусти збірку
7. Вкладка Actions -> зліва "build-jar" -> Run workflow -> Run workflow. Перша збірка йде ~5-10 хвилин
   (качається Forge). Зелена галочка = готово. Червоний хрестик = відкрий запуск, скопіюй текст помилки і скинь мені.

## 5. Забери .jar
8. Відкрий завершений запуск -> внизу розділ Artifacts -> `LinerVisuals-jar` (скачається як .zip).
9. Розпакуй на планшеті (Files / будь-який архіватор) - всередині `linervisuals-1.0.0.jar`.
10. Перекинь .jar на ПК (Telegram "Збережене", Google Drive, пошта, USB).

## 6. На ПК
11. Встанови Minecraft Forge 1.16.5 (версія 36.2.x, напр. 36.2.39) з files.minecraftforge.net, запусти гру один раз.
12. Поклади .jar у `%appdata%\.minecraft\mods` (Win+R -> `%appdata%\.minecraft`; папки `mods` нема - створи).
13. Запускай профіль Forge 1.16.5. Меню мода - Right Shift.
