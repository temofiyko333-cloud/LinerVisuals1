package com.liner.visuals;

import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

/**
 * Бінди команд: натискаєш клавішу - команда одразу відправляється в чат і виконується (наприклад /home).
 * Зберігається у конфігу як рядки "код_клавіші|команда" (код -1 = клавішу ще не призначено).
 */
public class CommandBinds {

    public static class Bind {
        public final int key;
        public final String cmd;

        Bind(int key, String cmd) {
            this.key = key;
            this.cmd = cmd;
        }
    }

    public static List<Bind> all() {
        List<Bind> list = new ArrayList<>();
        for (String s : Config.CMD_BINDS.get()) {
            int bar = s.indexOf('|');
            if (bar <= 0) continue;
            try {
                list.add(new Bind(Integer.parseInt(s.substring(0, bar)), s.substring(bar + 1)));
            } catch (NumberFormatException ignored) {
                // пошкоджений рядок пропускаємо
            }
        }
        return list;
    }

    private static void write(List<Bind> binds) {
        List<String> out = new ArrayList<>();
        for (Bind b : binds) out.add(b.key + "|" + b.cmd);
        Config.CMD_BINDS.set(out);
        Config.CMD_BINDS.save();
    }

    /** Команда без "/" на початку отримає його автоматично. */
    public static String normalize(String text) {
        String t = text.trim();
        if (t.isEmpty()) return "";
        return t.startsWith("/") ? t : "/" + t;
    }

    public static void add(String text) {
        String cmd = normalize(text);
        if (cmd.isEmpty()) return;
        List<Bind> binds = all();
        binds.add(new Bind(-1, cmd));
        write(binds);
    }

    public static void remove(int index) {
        List<Bind> binds = all();
        if (index < 0 || index >= binds.size()) return;
        binds.remove(index);
        write(binds);
    }

    public static void setKey(int index, int key) {
        List<Bind> binds = all();
        if (index < 0 || index >= binds.size()) return;
        binds.set(index, new Bind(key, binds.get(index).cmd));
        write(binds);
    }

    /** Викликається при натисканні клавіші в грі (коли жодне меню не відкрите). */
    public static void onKey(Minecraft mc, int keyCode) {
        if (mc.player == null || !Config.COMMAND_BINDS.on()) return;
        for (Bind b : all()) {
            if (b.key > 0 && b.key == keyCode) {
                mc.player.chat(b.cmd);
            }
        }
    }
}
