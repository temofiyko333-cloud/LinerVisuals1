package com.liner.visuals;

/** Вибір найкращого інструмента/зброї (без залежностей від Minecraft). */
public final class ToolLogic {
    private ToolLogic() {
    }

    public static final int UNBREAKABLE = Integer.MAX_VALUE;

    /**
     * Оцінка предмета для ламання блока.
     *
     * @param baseSpeed      швидкість ламання цим предметом (1.0 = рука)
     * @param efficiency     рівень Efficiency
     * @param correctForDrops чи випаде дроп (наприклад, алмазна руда лише від залізної кирки й вище)
     * @param durabilityLeft скільки міцності лишилось (UNBREAKABLE, якщо не ламається)
     */
    public static double blockScore(float baseSpeed, int efficiency, boolean correctForDrops, int durabilityLeft) {
        if (durabilityLeft <= 1) return -1.0D;      // не ризикуємо останнім ударом
        double speed = baseSpeed;
        if (speed > 1.0D && efficiency > 0) speed += efficiency * efficiency + 1;
        return speed + (correctForDrops ? 1000.0D : 0.0D);
    }

    /** Оцінка зброї: шкода * швидкість атаки (меч > сокира за DPS). */
    public static double weaponScore(double damageModifiers, double sharpnessBonus, double attackSpeedModifiers,
                                     int durabilityLeft) {
        if (durabilityLeft <= 1) return -1.0D;
        double damage = 1.0D + damageModifiers + sharpnessBonus;   // 1.0 - базова шкода руки
        double speed = 4.0D + attackSpeedModifiers;                 // 4.0 - базова швидкість атаки
        return Math.max(0.0D, damage) * Math.max(0.1D, speed);
    }

    /** Індекс найкращого слота або -1, якщо міняти не треба (поточний уже достатньо хороший). */
    public static int pickBest(double[] scores, int current, double minGain) {
        int best = current;
        double bestScore = scores[current];
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > bestScore + 1.0E-9D) {
                best = i;
                bestScore = scores[i];
            }
        }
        if (best == current) return -1;
        return bestScore >= scores[current] + minGain ? best : -1;
    }
}
