package com.liner.visuals;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.IRenderTypeBuffer;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Quaternion;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector3f;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Усе, що малюється у 3D-світі. */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class WorldVisuals {

    private static final float[] RED = {1.0F, 0.25F, 0.25F};
    private static final float[] GREEN = {0.30F, 1.0F, 0.40F};
    private static final float[] WHITE = {1.0F, 1.0F, 1.0F};
    private static final float[] FIRE_HOT = {1.0F, 0.92F, 0.35F};
    private static final float[] FIRE_COOL = {1.0F, 0.42F, 0.06F};

    private static class Ctx {
        Minecraft mc;
        MatrixStack ms;
        Matrix4f mat;
        ActiveRenderInfo camera;
        Vector3d cam;
        float pt;
        float time;
        float wave;
    }

    @SubscribeEvent
    public static void onRenderWorld(RenderWorldLastEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || !Config.MASTER.on()) return;

        Ctx c = new Ctx();
        c.mc = mc;
        c.ms = event.getMatrixStack();
        c.mat = c.ms.last().pose();
        c.pt = event.getPartialTicks();
        c.camera = mc.gameRenderer.getMainCamera();
        c.cam = c.camera.getPosition();
        c.time = mc.level.getGameTime() + c.pt;
        c.wave = 0.5F + 0.5F * MathHelper.sin(c.time * 0.15F);

        List<PlayerEntity> targets = nearbyPlayers(c);
        playerOverlays(c, targets);
        particles(c);
        if (Config.JUMP_RINGS.on()) jumpRings(c);
        if (Config.PEARL_PATH.on()) trajectory(c);
        if (Config.CHINA_HAT.on()) chinaHat(c);
        texts(c, targets);
    }

    // ------------------------------------------------------------------
    //  Гравці поруч: ESP, трейсери, пульсація
    // ------------------------------------------------------------------
    private static List<PlayerEntity> nearbyPlayers(Ctx c) {
        List<PlayerEntity> list = new ArrayList<>();
        if (!(Config.ESP.on() || Config.TRACERS.on() || Config.NAMETAGS.on() || Config.PULSE.on())) return list;
        double range = Config.ESP_RANGE.get();
        for (PlayerEntity p : c.mc.level.players()) {
            if (p == c.mc.player || !p.isAlive() || p.isSpectator()) continue;
            if (c.mc.player.distanceTo(p) > range) continue;
            list.add(p);
        }
        return list;
    }

    private static AxisAlignedBB relativeBox(PlayerEntity p, float pt, Vector3d cam) {
        double dx = MathHelper.lerp(pt, p.xo, p.getX()) - p.getX();
        double dy = MathHelper.lerp(pt, p.yo, p.getY()) - p.getY();
        double dz = MathHelper.lerp(pt, p.zo, p.getZ()) - p.getZ();
        return p.getBoundingBox().move(dx - cam.x, dy - cam.y, dz - cam.z);
    }

    private static void playerOverlays(Ctx c, List<PlayerEntity> targets) {
        boolean esp = Config.ESP.on(), tracers = Config.TRACERS.on(), pulse = Config.PULSE.on();
        if (targets.isEmpty() || !(esp || tracers || pulse)) return;

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        Vector3f look = c.camera.getLookVector();

        Draw.begin(false, 2.0F);
        try {
            if (esp) {
                buf.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
                int idx = 0;
                for (PlayerEntity p : targets) {
                    float[] col = Team.isFriend(p) ? GREEN : Chroma.get(idx++ * 0.09F);
                    AxisAlignedBB bb = relativeBox(p, c.pt, c.cam).inflate(pulse ? 0.03D + 0.07D * c.wave : 0.02D);
                    Draw.fillBox(buf, c.mat, bb, col, pulse ? 0.08F + 0.14F * c.wave : 0.12F);
                }
                tess.end();
            }

            buf.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
            int idx = 0;
            for (PlayerEntity p : targets) {
                boolean friend = Team.isFriend(p);
                float[] col = friend ? GREEN : Chroma.get(idx * 0.09F);
                float[] col2 = friend ? GREEN : Chroma.get(0.5F + idx * 0.09F);
                idx++;

                AxisAlignedBB base = relativeBox(p, c.pt, c.cam);
                double cx = (base.minX + base.maxX) * 0.5D;
                double cy = (base.minY + base.maxY) * 0.5D;
                double cz = (base.minZ + base.maxZ) * 0.5D;

                if (esp) {
                    Draw.boxLines(buf, c.mat, base.inflate(pulse ? 0.03D + 0.07D * c.wave : 0.02D), col, 0.95F);
                }
                if (tracers) {
                    Draw.line(buf, c.mat, look.x() * 0.6F, look.y() * 0.6F, look.z() * 0.6F,
                            (float) cx, (float) cy, (float) cz, col, 0.9F);
                }
                if (pulse) {
                    for (int k = 0; k < 3; k++) {
                        float t = ((c.time * 0.025F) + k / 3.0F) % 1.0F;
                        Draw.ring(buf, c.mat, cx, base.minY + 0.03D, cz, 0.45F + t * 1.9F, col2, (1.0F - t) * 0.95F);
                    }
                }
            }
            tess.end();
        } finally {
            Draw.end();
        }
    }

    // ------------------------------------------------------------------
    //  Партикли (удари, слід перла)
    // ------------------------------------------------------------------
    private static void particles(Ctx c) {
        if (Fx.PARTICLES.isEmpty()) return;

        Quaternion q = c.camera.rotation();
        Vector3f right = new Vector3f(1.0F, 0.0F, 0.0F);
        right.transform(q);
        Vector3f up = new Vector3f(0.0F, 1.0F, 0.0F);
        up.transform(q);

        boolean hasTris = false, hasLines = false;
        for (Fx.P p : Fx.PARTICLES) {
            if (p.style == Config.ParticleStyle.LINES) hasLines = true;
            else hasTris = true;
        }

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        boolean chroma = Config.CHROMA.on();

        Draw.begin(true, 2.0F);
        try {
            if (hasTris) {
                buf.begin(GL11.GL_TRIANGLES, DefaultVertexFormats.POSITION_COLOR);
                for (Fx.P p : Fx.PARTICLES) {
                    if (p.style == Config.ParticleStyle.LINES) continue;
                    float f = (p.age + c.pt) / p.maxAge;
                    float x = (float) (p.px + (p.x - p.px) * c.pt - c.cam.x);
                    float y = (float) (p.py + (p.y - p.py) * c.pt - c.cam.y);
                    float z = (float) (p.pz + (p.z - p.pz) * c.pt - c.cam.z);
                    float alpha = p.alpha * (1.0F - f);
                    float size = p.size * (1.0F - f * 0.5F);

                    if (p.style == Config.ParticleStyle.FIRE) {
                        float[] cool = chroma ? Chroma.get(p.hue) : FIRE_COOL;
                        Draw.flame(buf, c.mat, x, y, z, right, up, size, FIRE_HOT, cool, alpha);
                    } else {
                        float[] col = (p.crit && !chroma) ? RED : Chroma.get(p.hue);
                        Draw.star(buf, c.mat, x, y, z, right, up, size, col, alpha);
                    }
                }
                tess.end();
            }
            if (hasLines) {
                buf.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
                for (Fx.P p : Fx.PARTICLES) {
                    if (p.style != Config.ParticleStyle.LINES) continue;
                    float f = (p.age + c.pt) / p.maxAge;
                    float x = (float) (p.px + (p.x - p.px) * c.pt - c.cam.x);
                    float y = (float) (p.py + (p.y - p.py) * c.pt - c.cam.y);
                    float z = (float) (p.pz + (p.z - p.pz) * c.pt - c.cam.z);
                    float[] col = (p.crit && !chroma) ? RED : Chroma.get(p.hue);
                    float len = 2.5F * p.size / 0.1F;
                    Draw.line(buf, c.mat, x, y, z,
                            x - (float) p.vx * len, y - (float) p.vy * len, z - (float) p.vz * len,
                            col, p.alpha * (1.0F - f));
                }
                tess.end();
            }
        } finally {
            Draw.end();
        }
    }

    // ------------------------------------------------------------------
    //  Кола від стрибків
    // ------------------------------------------------------------------
    private static void jumpRings(Ctx c) {
        if (Fx.RINGS.isEmpty()) return;
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        Draw.begin(true, 1.0F);
        try {
            buf.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            for (Fx.Ring r : Fx.RINGS) {
                float f = (r.age + c.pt) / r.maxAge;
                float radius = 0.3F + f * 1.9F;
                float thick = 0.06F + (1.0F - f) * 0.07F;
                Draw.annulus(buf, c.mat, r.x - c.cam.x, r.y - c.cam.y, r.z - c.cam.z,
                        radius, radius + thick, 48, 0.9F * (1.0F - f), r.hue);
            }
            tess.end();
        } finally {
            Draw.end();
        }
    }

    // ------------------------------------------------------------------
    //  Траєкторія перла / сніжка / яйця / зілля / стріли
    // ------------------------------------------------------------------
    /** {швидкість, гравітація, зсув кута у градусах} або null. */
    private static double[] projectileParams(PlayerEntity p, ItemStack s) {
        if (s.isEmpty()) return null;
        Item it = s.getItem();
        if (it == Items.ENDER_PEARL || it == Items.SNOWBALL || it == Items.EGG) {
            return new double[]{1.5D, 0.03D, 0.0D};
        }
        if (it == Items.EXPERIENCE_BOTTLE) return new double[]{0.7D, 0.07D, -20.0D};
        if (it == Items.SPLASH_POTION || it == Items.LINGERING_POTION) return new double[]{0.5D, 0.05D, -20.0D};
        if (it == Items.BOW && p.isUsingItem() && p.getUseItem().getItem() == Items.BOW) {
            float power = BowItem.getPowerForTime(p.getTicksUsingItem());
            if (power < 0.1F) return null;
            return new double[]{power * 3.0D, 0.05D, 0.0D};
        }
        if (it == Items.CROSSBOW && CrossbowItem.isCharged(s)) return new double[]{3.15D, 0.05D, 0.0D};
        return null;
    }

    private static void trajectory(Ctx c) {
        Minecraft mc = c.mc;
        PlayerEntity p = mc.player;
        double[] prm = projectileParams(p, p.getMainHandItem());
        if (prm == null) prm = projectileParams(p, p.getOffhandItem());
        if (prm == null) return;

        double yr = Math.toRadians(p.getViewYRot(c.pt));
        double pr = Math.toRadians(p.getViewXRot(c.pt));
        double por = Math.toRadians(p.getViewXRot(c.pt) + prm[2]);
        Vector3d motion = new Vector3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(por), Math.cos(yr) * Math.cos(pr))
                .normalize().scale(prm[0]);
        Vector3d pm = p.getDeltaMovement();
        motion = motion.add(pm.x, p.isOnGround() ? 0.0D : pm.y, pm.z);
        Vector3d pos = p.getEyePosition(c.pt).subtract(0.0D, 0.1D, 0.0D);
        double gravity = prm[1];

        List<Vector3d> pts = new ArrayList<>();
        pts.add(pos);
        Entity hitEntity = null;
        boolean landed = false;

        for (int i = 0; i < 160; i++) {
            Vector3d next = pos.add(motion);
            Vector3d end = next;
            boolean hit = false;

            BlockRayTraceResult br = mc.level.clip(new RayTraceContext(pos, next,
                    RayTraceContext.BlockMode.COLLIDER, RayTraceContext.FluidMode.NONE, p));
            if (br.getType() != RayTraceResult.Type.MISS) {
                end = br.getLocation();
                hit = true;
            }

            double best = pos.distanceToSqr(end);
            for (Entity e : mc.level.getEntities(p, new AxisAlignedBB(pos, end).inflate(1.0D))) {
                if (e == p || !e.isPickable() || e.isSpectator()) continue;
                Optional<Vector3d> o = e.getBoundingBox().inflate(0.3D).clip(pos, end);
                if (o.isPresent()) {
                    double d = pos.distanceToSqr(o.get());
                    if (d < best) {
                        best = d;
                        end = o.get();
                        hit = true;
                        hitEntity = e;
                    }
                }
            }

            pts.add(end);
            if (hit) {
                landed = true;
                break;
            }
            pos = next;
            motion = motion.scale(0.99D).subtract(0.0D, gravity, 0.0D);
        }

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        Draw.begin(true, 2.5F);
        try {
            buf.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 1; i < pts.size(); i++) {
                Vector3d a = pts.get(i - 1).subtract(c.cam);
                Vector3d b = pts.get(i).subtract(c.cam);
                float[] col = hitEntity != null ? RED : Chroma.get(i * 0.012F);
                Draw.line(buf, c.mat, (float) a.x, (float) a.y, (float) a.z, (float) b.x, (float) b.y, (float) b.z, col, 0.95F);
            }
            if (landed) {
                Vector3d e = pts.get(pts.size() - 1).subtract(c.cam);
                float[] col = hitEntity != null ? RED : Chroma.get(0.0F);
                Draw.ring(buf, c.mat, e.x, e.y + 0.02D, e.z, 0.32F, col, 1.0F);
                Draw.ring(buf, c.mat, e.x, e.y + 0.02D, e.z, 0.18F, col, 0.8F);
                if (hitEntity != null) {
                    Draw.boxLines(buf, c.mat, hitEntity.getBoundingBox().move(-c.cam.x, -c.cam.y, -c.cam.z), RED, 1.0F);
                }
            }
            tess.end();
        } finally {
            Draw.end();
        }
    }

    // ------------------------------------------------------------------
    //  China Hat
    // ------------------------------------------------------------------
    private static void chinaHat(Ctx c) {
        Minecraft mc = c.mc;
        if (mc.options.getCameraType().isFirstPerson() && !Freecam.isActive()) return;
        PlayerEntity p = mc.player;

        double x = MathHelper.lerp(c.pt, p.xo, p.getX()) - c.cam.x;
        double y = MathHelper.lerp(c.pt, p.yo, p.getY()) + p.getBbHeight() - 0.02D - c.cam.y;
        double z = MathHelper.lerp(c.pt, p.zo, p.getZ()) - c.cam.z;
        float r = Config.HAT_SIZE.get().floatValue();
        float h = Config.HAT_HEIGHT.get().floatValue();
        boolean grad = Config.HAT_GRADIENT.get();
        final int seg = 40;

        float[] tip = grad ? Chroma.mix(Chroma.get(0.5F), WHITE, 0.5F) : Chroma.get(0.0F);

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        Draw.begin(true, 2.0F);
        try {
            buf.begin(GL11.GL_TRIANGLES, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 0; i < seg; i++) {
                double a1 = 2.0D * Math.PI * i / seg;
                double a2 = 2.0D * Math.PI * (i + 1) / seg;
                float[] c1 = grad ? Chroma.get(i / (float) seg) : tip;
                float[] c2 = grad ? Chroma.get((i + 1) / (float) seg) : tip;
                Draw.vert(buf, c.mat, (float) x, (float) (y + h), (float) z, tip, 0.95F);
                Draw.vert(buf, c.mat, (float) (x + Math.cos(a1) * r), (float) y, (float) (z + Math.sin(a1) * r), c1, 0.55F);
                Draw.vert(buf, c.mat, (float) (x + Math.cos(a2) * r), (float) y, (float) (z + Math.sin(a2) * r), c2, 0.55F);
            }
            tess.end();

            buf.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 0; i < seg; i++) {
                double a1 = 2.0D * Math.PI * i / seg;
                double a2 = 2.0D * Math.PI * (i + 1) / seg;
                float[] c1 = grad ? Chroma.get(i / (float) seg) : tip;
                Draw.line(buf, c.mat,
                        (float) (x + Math.cos(a1) * r), (float) y, (float) (z + Math.sin(a1) * r),
                        (float) (x + Math.cos(a2) * r), (float) y, (float) (z + Math.sin(a2) * r), c1, 1.0F);
            }
            tess.end();
        } finally {
            Draw.end();
        }
    }

    // ------------------------------------------------------------------
    //  Текст у світі: нікнейми та цифри шкоди
    // ------------------------------------------------------------------
    private static void texts(Ctx c, List<PlayerEntity> targets) {
        boolean names = Config.NAMETAGS.on() && !targets.isEmpty();
        boolean dmg = Config.DAMAGE_TEXT.on() && !Fx.TEXTS.isEmpty();
        if (!names && !dmg) return;

        Minecraft mc = c.mc;
        IRenderTypeBuffer.Impl src = mc.renderBuffers().bufferSource();

        if (names) {
            for (PlayerEntity p : targets) {
                double x = MathHelper.lerp(c.pt, p.xo, p.getX()) - c.cam.x;
                double y = MathHelper.lerp(c.pt, p.yo, p.getY()) + p.getBbHeight() + 0.55D - c.cam.y;
                double z = MathHelper.lerp(c.pt, p.zo, p.getZ()) - c.cam.z;
                float dist = mc.player.distanceTo(p);
                float hp = p.getHealth() + p.getAbsorptionAmount();
                float frac = MathHelper.clamp(p.getHealth() / p.getMaxHealth(), 0.0F, 1.0F);

                String text = (Team.isFriend(p) ? "[T] " : "") + p.getName().getString()
                        + "  " + String.format("%.1f", hp) + " HP  " + (int) dist + "m";
                float scale = 0.025F * Math.max(1.0F, dist / 6.0F);
                Draw.worldText(mc, c.ms, src, text, x, y, z, scale, Draw.healthColor(frac), 0x66000000);
            }
        }

        if (dmg) {
            for (Fx.Text t : Fx.TEXTS) {
                float f = (t.age + c.pt) / t.maxAge;
                int alpha = (int) (255.0F * (1.0F - f * f));
                if (alpha < 8) continue;
                double x = t.x - c.cam.x;
                double y = t.y + f * 0.9D - c.cam.y;
                double z = t.z - c.cam.z;
                float dist = (float) Math.sqrt(x * x + y * y + z * z);
                float pop = f < 0.2F ? 0.6F + (f / 0.2F) * 0.4F : 1.0F;
                float scale = (t.crit ? 0.045F : 0.032F) * pop * Math.max(1.0F, dist / 12.0F);
                int rgb = t.crit ? 0xFF5555 : 0xFFFF55;
                String s = t.crit ? "\u00a7l" + t.text + "!" : t.text;
                Draw.worldText(mc, c.ms, src, s, x, y, z, scale, (alpha << 24) | rgb, 0);
            }
        }
        src.endBatch();
    }
}
