package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** Right Shift відкриває меню; кожен модуль вмикається власною клавішею (бінд задається в меню). */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class KeyHandler {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || ClientSetup.KEY_MENU == null) return;
        while (ClientSetup.KEY_MENU.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new ModMenuScreen());
        }
    }

    @SubscribeEvent
    public static void onKey(InputEvent.KeyInputEvent event) {
        if (event.getAction() != GLFW.GLFW_PRESS) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;

        CommandBinds.onKey(mc, event.getKey());

        for (Config.Module m : Config.MODULES) {
            int k = m.key.get();
            if (k > 0 && k == event.getKey()) {
                m.toggle();
                if (!m.hidden || m == Config.MASTER) {
                    mc.player.displayClientMessage(new StringTextComponent(
                            "\u00a7d[Liner] \u00a7f" + m.name + ": " + (m.enabled.get() ? "\u00a7aON" : "\u00a7cOFF")
                            + (m.lockedHere() ? " \u00a77(locked: safe mode on this server)" : "")), true);
                }
            }
        }
    }
}
