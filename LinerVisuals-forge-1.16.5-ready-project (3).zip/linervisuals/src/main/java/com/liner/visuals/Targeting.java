package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;

import java.util.Optional;

public class Targeting {

    /** Чи можна вважати сутність ворогом (не друг, не спектатор, живий). */
    public static boolean isValid(Minecraft mc, Entity e, boolean mobs) {
        if (e == null || e == mc.player || !(e instanceof LivingEntity)) return false;
        LivingEntity le = (LivingEntity) e;
        if (!le.isAlive() || le.isSpectator()) return false;
        if (le instanceof PlayerEntity) return !Team.isFriend(le);
        return mobs && le instanceof IMob;
    }

    /** Точка, в яку наводимось: верх грудей/шия. */
    public static Vector3d aimPoint(Entity e, float pt) {
        double x = MathHelper.lerp(pt, e.xo, e.getX());
        double y = MathHelper.lerp(pt, e.yo, e.getY()) + e.getBbHeight() * 0.85D;
        double z = MathHelper.lerp(pt, e.zo, e.getZ());
        return new Vector3d(x, y, z);
    }

    /** Найближча до центру екрана ціль у конусі fov та радіусі range. */
    public static LivingEntity findAimTarget(Minecraft mc, float pt, double range, double fov,
                                             boolean mobs, LivingEntity prefer) {
        Vector3d eye = mc.player.getEyePosition(pt);
        Vector3d look = mc.player.getViewVector(pt);
        AxisAlignedBB box = mc.player.getBoundingBox().inflate(range + 1.0D);

        LivingEntity result = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, box)) {
            if (!isValid(mc, e, mobs)) continue;
            Vector3d p = aimPoint(e, pt);
            if (eye.distanceTo(p) > range) continue;
            Vector3d dir = p.subtract(eye).normalize();
            double angle = Math.toDegrees(Math.acos(MathHelper.clamp(look.dot(dir), -1.0D, 1.0D)));
            if (angle > fov * 0.5D) continue;
            if (!mc.player.canSee(e)) continue;
            double score = angle - (e == prefer ? 15.0D : 0.0D); // трохи "липне" до поточної цілі
            if (score < best) {
                best = score;
                result = e;
            }
        }
        return result;
    }

    /** Жива істота, на яку дивиться гравець (для Target HUD); крізь блоки не бачить. */
    public static LivingEntity lookedAt(Minecraft mc, float pt, double range) {
        PlayerEntity p = mc.player;
        Vector3d eye = p.getEyePosition(pt);
        Vector3d look = p.getViewVector(pt);
        Vector3d end = eye.add(look.x * range, look.y * range, look.z * range);
        AxisAlignedBB search = p.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0D);

        LivingEntity best = null;
        double bestD = range * range;
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, search)) {
            if (e == p || !e.isAlive() || e.isSpectator()) continue;
            AxisAlignedBB bb = e.getBoundingBox().inflate(e.getPickRadius());
            Optional<Vector3d> hit = bb.clip(eye, end);
            if (hit.isPresent()) {
                double d = eye.distanceToSqr(hit.get());
                if (d < bestD) {
                    bestD = d;
                    best = e;
                }
            }
        }
        if (best != null) {
            BlockRayTraceResult br = mc.level.clip(new RayTraceContext(eye, end,
                    RayTraceContext.BlockMode.COLLIDER, RayTraceContext.FluidMode.NONE, p));
            if (br.getType() == RayTraceResult.Type.BLOCK && eye.distanceToSqr(br.getLocation()) < bestD) {
                return null;
            }
        }
        return best;
    }
}
