package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.client.gui.screen.inventory.InventoryScreen;
import net.minecraft.inventory.container.ClickType;
import net.minecraft.item.Items;

/** Тримає тотем безсмертя в лівій руці (свап через слот-клік з кнопкою 40). */
public class AutoTotem {
    private static int cooldown = 0;

    public static void tick(Minecraft mc) {
        if (cooldown > 0) cooldown--;
        if (!Config.AUTO_TOTEM.on() || !CombatGate.allowed(mc)) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.gameMode == null || cooldown > 0) return;
        if (p.isCreative() || p.isSpectator() || !p.isAlive()) return;
        if (mc.screen != null && !(mc.screen instanceof InventoryScreen)) return;

        if (p.getOffhandItem().getItem() == Items.TOTEM_OF_UNDYING) return;
        if (p.getHealth() > Config.AUTO_TOTEM_HP.get()) return;

        for (int i = 0; i < 36; i++) {
            if (p.inventory.getItem(i).getItem() == Items.TOTEM_OF_UNDYING) {
                int slot = i < 9 ? 36 + i : i; // індекс у контейнері гравця
                mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
                cooldown = 4;
                return;
            }
        }
    }
}
