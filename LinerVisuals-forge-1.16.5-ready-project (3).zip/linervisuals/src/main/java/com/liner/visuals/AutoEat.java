package com.liner.visuals;

import com.mojang.datafixers.util.Pair;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.item.Food;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.EffectType;
import net.minecraft.util.FoodStats;
import net.minecraft.util.Hand;

/** Їсть їжу з хотбару, коли голод <= ліміту. Золоті яблука та їжа зі шкідливими ефектами пропускаються. */
public class AutoEat {
    private static boolean eating = false;
    private static int prevSlot = -1;
    private static int cooldown = 0;

    public static void tick(Minecraft mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.gameMode == null) return;
        if (!Config.AUTO_EAT.on()) {
            if (eating) stop(mc);
            return;
        }
        if (cooldown > 0) cooldown--;

        if (eating) {
            if (p.isUsingItem() && mc.screen == null) mc.options.keyUse.setDown(true);
            else stop(mc);
            return;
        }
        if (cooldown > 0 || mc.screen != null || p.isUsingItem() || p.isCreative() || p.isSpectator()) return;

        FoodStats fd = p.getFoodData();
        if (fd.getFoodLevel() > Config.AUTO_EAT_LEVEL.get()) return;

        int slot = findFood(p, 20 - fd.getFoodLevel());
        if (slot < 0) return;

        prevSlot = p.inventory.selected;
        p.inventory.selected = slot;
        mc.gameMode.useItem(p, mc.level, Hand.MAIN_HAND);
        mc.options.keyUse.setDown(true); // утримуємо "використати", поки їмо
        eating = true;
    }

    private static void stop(Minecraft mc) {
        eating = false;
        mc.options.keyUse.setDown(false);
        if (prevSlot >= 0 && mc.player != null) mc.player.inventory.selected = prevSlot;
        prevSlot = -1;
        cooldown = 30;
    }

    private static int findFood(ClientPlayerEntity p, int deficit) {
        int best = -1;
        int bestDiff = Integer.MAX_VALUE;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.inventory.getItem(i);
            if (s.isEmpty() || !s.getItem().isEdible()) continue;
            if (s.getItem() == Items.GOLDEN_APPLE || s.getItem() == Items.ENCHANTED_GOLDEN_APPLE) continue;
            Food f = s.getItem().getFoodProperties();
            if (f == null) continue;

            boolean bad = false;
            for (Pair<EffectInstance, Float> e : f.getEffects()) {
                if (e.getFirst() != null && e.getFirst().getEffect().getCategory() == EffectType.HARMFUL) bad = true;
            }
            if (bad) continue;

            int diff = Math.abs(f.getNutrition() - deficit);
            if (diff < bestDiff) {
                bestDiff = diff;
                best = i;
            }
        }
        return best;
    }
}
