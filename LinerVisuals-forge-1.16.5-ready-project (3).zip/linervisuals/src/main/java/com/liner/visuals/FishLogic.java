package com.liner.visuals;

import java.util.Random;

/**
 * Логіка авто-риболовлі без залежностей від Minecraft (тестується окремо).
 * Цикл: поклювка -> невелика затримка -> підсічка -> пауза -> закид -> чекаємо наступну поклювку.
 */
public final class FishLogic {
    public enum Action { NONE, USE }

    /** Звуки сплеску в перші тіки після закиду - це приводнення, а не поклювка. */
    public static final int MIN_BITE_AGE = 30;
    /** Якщо поплавок висить довше (тіків) без поклювки - вважаємо, що вудка застрягла: підсікаємо й закидаємо знову. */
    public static final int MAX_WAIT_TICKS = 1200;

    private final Random rand;
    private int reelIn = -1;
    private int recastIn = -1;
    private int waited = 0;
    private int idle = 0;

    public FishLogic(Random rand) {
        this.rand = rand;
    }

    public void reset() {
        reelIn = -1;
        recastIn = -1;
        waited = 0;
        idle = 0;
    }

    /** Звук поклювки. Повертає true, якщо прийнято. Ігнорується під час підсічки/закиду та одразу після закиду. */
    public boolean onBite(boolean bobberPresent, int bobberAge, int delayTicks) {
        if (!bobberPresent || bobberAge < MIN_BITE_AGE || reelIn >= 0 || recastIn >= 0) return false;
        reelIn = Math.max(1, delayTicks) + rand.nextInt(3);
        return true;
    }

    /** Викликається щотіка. USE = використати вудку (підсікти або закинути). */
    public Action tick(boolean rodInHand, boolean bobberPresent, int delayTicks, boolean autoCast) {
        if (!rodInHand) {
            reset();
            return Action.NONE;
        }

        if (reelIn >= 0) {
            if (--reelIn <= 0) {
                reelIn = -1;
                if (bobberPresent) {
                    recastIn = 14 + rand.nextInt(8);
                    return Action.USE;
                }
                waited = 0; // ліску вже зібрано вручну - не закидаємо зайвий раз
            }
            return Action.NONE;
        }

        if (recastIn >= 0) {
            if (--recastIn <= 0) {
                recastIn = -1;
                waited = 0;
                idle = 0;
                if (!bobberPresent) return Action.USE; // якщо вже закинув сам - не чіпаємо
            }
            return Action.NONE;
        }

        if (bobberPresent) {
            idle = 0;
            if (++waited > MAX_WAIT_TICKS) {
                waited = 0;
                reelIn = Math.max(1, delayTicks);
            }
            return Action.NONE;
        }

        waited = 0;
        if (autoCast) {
            if (++idle >= 40) {
                idle = 0;
                return Action.USE;
            }
        } else {
            idle = 0;
        }
        return Action.NONE;
    }

    public String describe(boolean bobberPresent) {
        if (reelIn >= 0) return "reeling in";
        if (recastIn >= 0) return "recasting";
        return bobberPresent ? "waiting for bite" : "idle";
    }
}
