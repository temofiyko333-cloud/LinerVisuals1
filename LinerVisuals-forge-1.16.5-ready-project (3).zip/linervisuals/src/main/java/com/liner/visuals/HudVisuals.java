package com.liner.visuals;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.network.play.NetworkPlayerInfo;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.EffectInstance;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Весь 2D-інтерфейс: вотермарка (FPS/ping), ефекти, броня, Target HUD, приціл, підказка наведення. */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class HudVisuals {

    // --- FPS ---
    private static int frames = 0;
    private static int fps = 0;
    private static long lastFpsTime = System.currentTimeMillis();

    // --- приціл ---
    private static float crossRadius = 8.0F;
    public static float hitPulse = 0.0F;

    // --- Target HUD ---
    private static LivingEntity lastTarget;
    private static long lastSeen;
    private static float shownHp = -1.0F;
    private static int shownFor = -1;

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        frames++;
        long now = System.currentTimeMillis();
        if (now - lastFpsTime >= 500L) {
            fps = (int) (frames * 1000L / (now - lastFpsTime));
            frames = 0;
            lastFpsTime = now;
        }
    }

    // ------------------------------------------------------------------
    //  Приціл-кільце (замінює ванільний)
    // ------------------------------------------------------------------
    @SubscribeEvent
    public static void onPre(RenderGameOverlayEvent.Pre event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.CROSSHAIRS) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || !Config.RING_CROSSHAIR.on()) return;
        if (!mc.options.getCameraType().isFirstPerson()) return;
        event.setCanceled(true);
        drawRingCrosshair(mc, event.getMatrixStack(), event.getPartialTicks());
    }

    private static void drawRingCrosshair(Minecraft mc, MatrixStack ms, float pt) {
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        float cx = w / 2.0F, cy = h / 2.0F;

        Vector3d mv = mc.player.getDeltaMovement();
        float speed = (float) Math.sqrt(mv.x * mv.x + mv.z * mv.z);
        float target = 5.0F + speed * 28.0F + (mc.player.isOnGround() ? 0.0F : 3.0F) + hitPulse * 6.0F;
        crossRadius += (target - crossRadius) * 0.2F;
        hitPulse = Math.max(0.0F, hitPulse - 0.06F);

        LivingEntity t = Targeting.lookedAt(mc, pt, 4.5D);
        boolean onEnemy = t != null && !Team.isFriend(t);
        boolean onFriend = t != null && Team.isFriend(t);

        Matrix4f m = ms.last().pose();
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder b = tess.getBuilder();
        Draw.begin(false, 1.0F);
        try {
            b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            final int seg = 56;
            final float th = 0.9F;
            for (int i = 0; i < seg; i++) {
                float[] col = onEnemy ? new float[]{1.0F, 0.25F, 0.25F}
                        : onFriend ? new float[]{0.3F, 1.0F, 0.4F}
                        : Chroma.get(i / (float) seg);
                double a1 = 2.0D * Math.PI * i / seg, a2 = 2.0D * Math.PI * (i + 1) / seg;
                float c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
                float c2 = (float) Math.cos(a2), s2 = (float) Math.sin(a2);
                float r1 = crossRadius - th, r2 = crossRadius + th;
                v2(b, m, cx + c1 * r1, cy + s1 * r1, col, 0.95F);
                v2(b, m, cx + c1 * r2, cy + s1 * r2, col, 0.95F);
                v2(b, m, cx + c2 * r2, cy + s2 * r2, col, 0.95F);
                v2(b, m, cx + c2 * r1, cy + s2 * r1, col, 0.95F);
            }
            // точка в центрі
            float[] dot = onEnemy ? new float[]{1.0F, 0.25F, 0.25F} : Chroma.get(0.0F);
            v2(b, m, cx - 0.8F, cy - 0.8F, dot, 1.0F);
            v2(b, m, cx - 0.8F, cy + 0.8F, dot, 1.0F);
            v2(b, m, cx + 0.8F, cy + 0.8F, dot, 1.0F);
            v2(b, m, cx + 0.8F, cy - 0.8F, dot, 1.0F);
            tess.end();
        } finally {
            Draw.end();
        }
        mc.getTextureManager().bind(AbstractGui.GUI_ICONS_LOCATION);
    }

    private static void v2(BufferBuilder b, Matrix4f m, float x, float y, float[] c, float a) {
        b.vertex(m, x, y, 0.0F).color(c[0], c[1], c[2], a).endVertex();
    }

    // ------------------------------------------------------------------
    //  Основний HUD
    // ------------------------------------------------------------------
    @SubscribeEvent
    public static void onPost(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        if (!Config.MASTER.on()) return;

        MatrixStack ms = event.getMatrixStack();
        float pt = event.getPartialTicks();

        drawWatermark(mc, ms);
        if (Config.EFFECTS_HUD.on()) drawEffects(mc, ms);
        if (Config.ARMOR_HUD.on()) drawArmor(mc, ms);
        if (mc.screen == null) {
            if (Config.TARGET_HUD.on()) drawTargetHud(mc, ms, pt);
            if (Config.AIM_HINT.on()) drawAimHint(mc, ms, pt);
        }
        if (Config.COORDS.on()) drawCoords(mc, ms);
        if (Config.MODULE_LIST.on()) drawModuleList(mc, ms);
    }

    // ---------------- Вотермарка: Liner Visuals | FPS | ping ----------------
    private static void drawWatermark(Minecraft mc, MatrixStack ms) {
        boolean title = Config.WATERMARK.on();
        boolean showFps = Config.FPS.on();
        boolean showPing = Config.PING.on();
        if (!title && !showFps && !showPing) return;

        List<String> texts = new ArrayList<>();
        List<Integer> colors = new ArrayList<>(); // -1 = веселка (заголовок)
        if (title) {
            texts.add("Liner Visuals");
            colors.add(-1);
        }
        if (showFps) {
            texts.add(fps + " FPS");
            colors.add(fps >= 60 ? 0xFF55FF55 : fps >= 30 ? 0xFFFFFF55 : 0xFFFF5555);
        }
        if (showPing) {
            int ping = ping(mc);
            texts.add(ping + " ms");
            colors.add(ping < 80 ? 0xFF55FF55 : ping < 150 ? 0xFFFFFF55 : 0xFFFF5555);
        }

        String sep = " | ";
        int sepW = mc.font.width(sep);
        int total = 10;
        for (int i = 0; i < texts.size(); i++) {
            total += mc.font.width(texts.get(i));
            if (i > 0) total += sepW;
        }

        int x = 4, y = 4;
        AbstractGui.fill(ms, x, y, x + total, y + 14, 0xB0101018);
        for (int i = 0; i < total; i += 3) {
            AbstractGui.fill(ms, x + i, y, Math.min(x + i + 3, x + total), y + 1, 0xFF000000 | Chroma.rgb(i / 140.0F));
        }

        int cx = x + 5;
        for (int i = 0; i < texts.size(); i++) {
            if (i > 0) {
                mc.font.drawShadow(ms, sep, cx, y + 4, 0xFF777788);
                cx += sepW;
            }
            String t = texts.get(i);
            if (colors.get(i) == -1) {
                for (int k = 0; k < t.length(); k++) {
                    String ch = String.valueOf(t.charAt(k));
                    mc.font.drawShadow(ms, ch, cx, y + 4, 0xFF000000 | Chroma.rgb(k * 0.06F));
                    cx += mc.font.width(ch);
                }
            } else {
                mc.font.drawShadow(ms, t, cx, y + 4, colors.get(i));
                cx += mc.font.width(t);
            }
        }
    }

    public static int currentFps() {
        return fps;
    }

    public static int ping(Minecraft mc) {
        if (mc.getConnection() == null || mc.player == null) return 0;
        NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        return info == null ? 0 : info.getLatency();
    }

    // ---------------- Ефекти зілля (справа посередині) ----------------
    private static void drawEffects(Minecraft mc, MatrixStack ms) {
        if (mc.player.getActiveEffects().isEmpty()) return;
        List<EffectInstance> list = new ArrayList<>(mc.player.getActiveEffects());
        list.sort(Comparator.comparingInt(EffectInstance::getDuration));

        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        final int rowH = 15;
        int y = h / 2 - list.size() * rowH / 2;
        boolean flash = (System.currentTimeMillis() / 250L) % 2L == 0L;

        for (EffectInstance e : list) {
            String name = e.getEffect().getDisplayName().getString();
            if (e.getAmplifier() > 0) name += " " + roman(e.getAmplifier() + 1);
            boolean infinite = e.getDuration() > 99999;
            String time = infinite ? "**" : formatTicks(e.getDuration());
            int tw = mc.font.width(time);
            int rowW = mc.font.width(name) + tw + 22;
            int x = w - 4 - rowW;

            AbstractGui.fill(ms, x, y, x + rowW, y + rowH - 2, 0xB0101018);
            AbstractGui.fill(ms, x + rowW - 2, y, x + rowW, y + rowH - 2, 0xFF000000 | e.getEffect().getColor());
            mc.font.drawShadow(ms, name, x + 4, y + 3, 0xFFFFFFFF);
            boolean low = !infinite && e.getDuration() <= 200;
            int tc = low ? (flash ? 0xFFFF5555 : 0xFFFFAAAA) : 0xFFAAAAAA;
            mc.font.drawShadow(ms, time, x + rowW - tw - 6, y + 3, tc);
            y += rowH;
        }
    }

    private static String formatTicks(int ticks) {
        int s = Math.max(0, ticks) / 20;
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    private static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return n >= 0 && n < r.length ? r[n] : String.valueOf(n);
    }

    // ---------------- Броня / зброя: скільки лишилось міцності ----------------
    private static void drawArmor(Minecraft mc, MatrixStack ms) {
        int h = mc.getWindow().getGuiScaledHeight();
        ItemStack[] stacks = {
                mc.player.inventory.armor.get(3), mc.player.inventory.armor.get(2),
                mc.player.inventory.armor.get(1), mc.player.inventory.armor.get(0),
                mc.player.getMainHandItem(), mc.player.getOffhandItem()};

        int y = h / 2 - 58;
        for (ItemStack s : stacks) {
            if (!s.isEmpty()) {
                int x = 4;
                AbstractGui.fill(ms, x - 2, y - 1, x + 88, y + 17, 0x90101018);
                mc.getItemRenderer().renderGuiItem(s, x, y);
                if (s.isDamageableItem()) {
                    int max = s.getMaxDamage();
                    int left = max - s.getDamageValue();
                    float frac = left / (float) max;
                    int col = Draw.healthColor(frac);
                    mc.font.drawShadow(ms, left + "/" + max, x + 20, y + 1, col);
                    AbstractGui.fill(ms, x + 20, y + 11, x + 82, y + 13, 0xFF2A2A34);
                    AbstractGui.fill(ms, x + 20, y + 11, x + 20 + (int) (62 * frac), y + 13, col);
                } else if (s.getCount() > 1) {
                    mc.font.drawShadow(ms, "x" + s.getCount(), x + 20, y + 5, 0xFFFFFFFF);
                }
            }
            y += 19;
        }
    }

    // ---------------- Target HUD ----------------
    private static void drawTargetHud(Minecraft mc, MatrixStack ms, float pt) {
        LivingEntity t = Targeting.lookedAt(mc, pt, Config.TARGET_RANGE.get());
        long now = System.currentTimeMillis();
        if (t != null) {
            lastTarget = t;
            lastSeen = now;
        } else if (lastTarget == null || now - lastSeen > 1500L || !lastTarget.isAlive()) {
            lastTarget = null;
            return;
        }
        LivingEntity e = lastTarget;
        float fade = t != null ? 1.0F : 1.0F - (now - lastSeen) / 1500.0F;
        if (fade < 0.06F) return;

        float hp = e.getHealth();
        float max = Math.max(1.0F, e.getMaxHealth());
        if (shownFor != e.getId() || shownHp < 0) {
            shownFor = e.getId();
            shownHp = hp;
        }
        shownHp += (hp - shownHp) * 0.15F;
        float frac = MathHelper.clamp(shownHp / max, 0.0F, 1.0F);

        // міцність броні (середня по елементах)
        int armorPts = e.getArmorValue();
        float durSum = 0.0F;
        int durCount = 0;
        for (ItemStack s : e.getArmorSlots()) {
            if (!s.isEmpty() && s.isDamageableItem()) {
                durSum += (s.getMaxDamage() - s.getDamageValue()) / (float) s.getMaxDamage();
                durCount++;
            }
        }
        String armorText = "Armor " + armorPts + (durCount > 0 ? "  (" + (int) (durSum / durCount * 100) + "%)" : "");
        float dist = mc.player.distanceTo(e);

        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        int pw = 132, ph = 46;
        int x = w / 2 - pw / 2;
        int y = h / 2 + 32;
        int a = (int) (fade * 255);
        int bg = ((int) (fade * 176) << 24) | 0x101018;
        int text = (a << 24) | 0xFFFFFF;
        int gray = (a << 24) | 0xAAAAAA;

        AbstractGui.fill(ms, x, y, x + pw, y + ph, bg);
        for (int i = 0; i < pw; i += 3) {
            AbstractGui.fill(ms, x + i, y, Math.min(x + i + 3, x + pw), y + 1, (a << 24) | Chroma.rgb(i / 130.0F));
        }
        String name = e.getName().getString();
        if (name.length() > 20) name = name.substring(0, 20);
        mc.font.drawShadow(ms, name, x + 5, y + 5, text);

        int bx1 = x + 5, bx2 = x + pw - 5;
        AbstractGui.fill(ms, bx1, y + 17, bx2, y + 23, (a << 24) | 0x2A2A34);
        AbstractGui.fill(ms, bx1, y + 17, bx1 + (int) ((bx2 - bx1) * frac), y + 23,
                Config.CHROMA.on() ? ((a << 24) | Chroma.rgb(0.0F)) : ((a << 24) | (Draw.healthColor(frac) & 0xFFFFFF)));

        mc.font.drawShadow(ms, String.format("%.1f / %.0f HP", hp, max), x + 5, y + 27, text);
        mc.font.drawShadow(ms, armorText, x + 5, y + 37, gray);
        String d = String.format("%.1fm", dist);
        mc.font.drawShadow(ms, d, x + pw - 5 - mc.font.width(d), y + 27, gray);
    }

    // ---------------- Підказка в бік найближчого гравця (тільки візуально) ----------------
    private static void drawAimHint(Minecraft mc, MatrixStack ms, float pt) {
        PlayerEntity best = null;
        double bd = Double.MAX_VALUE;
        double range = Config.ESP_RANGE.get();
        for (PlayerEntity p : mc.level.players()) {
            if (!Targeting.isValid(mc, p, false)) continue;
            double d = mc.player.distanceToSqr(p);
            if (d < bd && d <= range * range) {
                bd = d;
                best = p;
            }
        }
        if (best == null) return;

        Vector3d eye = mc.player.getEyePosition(pt);
        Vector3d aim = Targeting.aimPoint(best, pt);
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float dyaw = CombatMath.wrapDegrees(CombatMath.yawTo(dx, dz) - mc.player.getViewYRot(pt));
        float dpitch = CombatMath.pitchTo(dx, dy, dz) - mc.player.getViewXRot(pt);

        boolean aligned = Math.abs(dyaw) < 6.0F && Math.abs(dpitch) < 8.0F;
        float len = (float) Math.sqrt(dyaw * dyaw + dpitch * dpitch);
        float ux = len < 0.001F ? 0.0F : dyaw / len;
        float uy = len < 0.001F ? -1.0F : dpitch / len;

        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        float cx = w / 2.0F, cy = h / 2.0F;
        float R = 52.0F;
        float[] col = aligned ? new float[]{0.3F, 1.0F, 0.4F} : Chroma.get(0.0F);

        Matrix4f m = ms.last().pose();
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder b = tess.getBuilder();
        Draw.begin(false, 1.0F);
        try {
            b.begin(GL11.GL_TRIANGLES, DefaultVertexFormats.POSITION_COLOR);
            float bx = cx + ux * R, by = cy + uy * R;
            float tx = cx + ux * (R + 11.0F), ty = cy + uy * (R + 11.0F);
            float px = -uy * 5.0F, py = ux * 5.0F;
            v2(b, m, bx + px, by + py, col, 0.95F);
            v2(b, m, bx - px, by - py, col, 0.95F);
            v2(b, m, tx, ty, col, 0.95F);
            tess.end();
        } finally {
            Draw.end();
        }
        mc.getTextureManager().bind(AbstractGui.GUI_ICONS_LOCATION);
        String dist = String.format("%.0fm", Math.sqrt(bd));
        mc.font.drawShadow(ms, dist, cx + ux * (R + 18.0F) - mc.font.width(dist) / 2.0F, cy + uy * (R + 18.0F) - 4.0F,
                aligned ? 0xFF55FF55 : 0xFFFFFFFF);
    }

    // ---------------- Координати, напрямок, смерть ----------------
    private static void drawCoords(Minecraft mc, MatrixStack ms) {
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        List<String> lines = new ArrayList<>();
        lines.add("XYZ  " + CoordsMath.block(px) + " " + CoordsMath.block(py) + " " + CoordsMath.block(pz));
        lines.add(CoordsMath.facing(mc.player.getViewYRot(1.0F)));
        if (Config.COORDS_NETHER.get()) {
            boolean nether = mc.level.dimension() == World.NETHER;
            double[] o = CoordsMath.otherDimension(px, pz, nether);
            lines.add((nether ? "Overworld  " : "Nether  ") + CoordsMath.block(o[0]) + " " + CoordsMath.block(o[1]));
        }
        String death = Config.DEATH_POINT.get();
        if (Config.COORDS_DEATH.get() && death != null && !death.isEmpty()) lines.add("Death  " + death);

        int w = 0;
        for (String s : lines) w = Math.max(w, mc.font.width(s));
        int x = 4;
        int y = (Config.WATERMARK.on() || Config.FPS.on() || Config.PING.on()) ? 22 : 4;
        int h = lines.size() * 10 + 6;
        AbstractGui.fill(ms, x, y, x + w + 10, y + h, 0xB0101018);
        AbstractGui.fill(ms, x, y, x + 2, y + h, 0xFF000000 | Chroma.rgb(0.3F));
        for (int i = 0; i < lines.size(); i++) {
            mc.font.drawShadow(ms, lines.get(i), x + 6, y + 4 + i * 10, i == 0 ? 0xFFFFFFFF : 0xFFBBBBBB);
        }
    }

    // ---------------- Список увімкнених модулів ----------------
    private static void drawModuleList(Minecraft mc, MatrixStack ms) {
        List<Config.Module> on = new ArrayList<>();
        for (Config.Module m : Config.MODULES) {
            if (!m.hidden && m.enabled.get()) on.add(m);
        }
        on.sort(Comparator.comparingInt((Config.Module m) -> -mc.font.width(m.name)));

        int w = mc.getWindow().getGuiScaledWidth();
        int y = 4;
        int i = 0;
        for (Config.Module m : on) {
            int tw = mc.font.width(m.name);
            int x = w - 4 - tw - 6;
            AbstractGui.fill(ms, x - 2, y, w - 2, y + 11, 0x90101018);
            AbstractGui.fill(ms, w - 4, y, w - 2, y + 11, 0xFF000000 | Chroma.rgb(i * 0.07F));
            mc.font.drawShadow(ms, m.name, x + 1, y + 2, 0xFF000000 | Chroma.rgb(i * 0.07F));
            y += 11;
            i++;
        }
        if (Config.COMBAT_LOCK.get() && !CombatGate.allowed(mc)) {
            String s = "SAFE MODE";
            mc.font.drawShadow(ms, s, w - 4 - mc.font.width(s), y + 3, 0xFFFF5555);
        }
    }
}
