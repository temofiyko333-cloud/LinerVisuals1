package com.liner.visuals;

/** Чисті формули бойових модулів без залежностей від Minecraft - щоб їх можна було тестувати окремо. */
public final class CombatMath {
    private CombatMath() {
    }

    /** Yaw у системі Minecraft: 0 = південь (+Z), 90 = захід (-X), -90 = схід (+X), 180 = північ (-Z). */
    public static float yawTo(double dx, double dz) {
        return (float) (Math.atan2(dz, dx) * 57.29577951308232D) - 90.0F;
    }

    /** Pitch у системі Minecraft: вгору - від'ємний, вниз - додатний. */
    public static float pitchTo(double dx, double dy, double dz) {
        return (float) (-(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 57.29577951308232D));
    }

    /** Різниця кутів у діапазоні [-180, 180): завжди обирає короткий шлях повороту. */
    public static float wrapDegrees(float d) {
        d = d % 360.0F;
        if (d >= 180.0F) d -= 360.0F;
        if (d < -180.0F) d += 360.0F;
        return d;
    }

    /** Крок повороту за кадр: плавне наближення з обмеженням швидкості, не залежить від FPS. */
    public static float aimStep(float delta, float dtTicks, float speedDegPerTick) {
        float maxStep = speedDegPerTick * dtTicks;
        float k = 1.0F - (float) Math.pow(0.55D, dtTicks);
        float step = delta * k;
        return Math.max(-maxStep, Math.min(maxStep, step));
    }

    /** Рішення triggerbot: ціль валідна, у межах дальності і зброя відкотилась. */
    public static boolean shouldAttack(boolean validTarget, double distance, double maxRange, float attackStrength) {
        return validTarget && distance <= maxRange + 1.0E-6D && attackStrength >= 0.92F;
    }
}
