package com.liner.visuals;

/** Колірний рушій: або фіксований колір теми, або веселка (Chroma). */
public class Chroma {

    public static float[] theme() {
        int c = Config.THEME_COLOR.get();
        return new float[]{((c >> 16) & 255) / 255.0F, ((c >> 8) & 255) / 255.0F, (c & 255) / 255.0F};
    }

    /** offset 0..1 зсуває відтінок, щоб різні елементи мали різні кольори. */
    public static float[] get(float offset) {
        if (!Config.CHROMA.on()) return theme();
        float speed = Config.CHROMA_SPEED.get().floatValue();
        float t = (System.currentTimeMillis() % 100000L) / 1000.0F;
        float hue = (t * speed * 0.1F + offset) % 1.0F;
        if (hue < 0.0F) hue += 1.0F;
        return hsv(hue, 0.65F, 1.0F);
    }

    public static int rgb(float offset) {
        float[] c = get(offset);
        return ((int) (c[0] * 255) << 16) | ((int) (c[1] * 255) << 8) | (int) (c[2] * 255);
    }

    public static int argb(float offset, int alpha) {
        return (alpha << 24) | rgb(offset);
    }

    /** Лінійне змішування двох 0xRRGGBB кольорів. */
    public static int mixRgb(int a, int b, float t) {
        t = Math.max(0.0F, Math.min(1.0F, t));
        int r = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return (r << 16) | (g << 8) | bl;
    }

    public static float[] mix(float[] a, float[] b, float t) {
        return new float[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t};
    }

    private static float[] hsv(float h, float s, float v) {
        int i = (int) (h * 6.0F);
        float f = h * 6.0F - i;
        float p = v * (1.0F - s);
        float q = v * (1.0F - f * s);
        float t = v * (1.0F - (1.0F - f) * s);
        switch (i % 6) {
            case 0:  return new float[]{v, t, p};
            case 1:  return new float[]{q, v, p};
            case 2:  return new float[]{p, v, t};
            case 3:  return new float[]{p, q, v};
            case 4:  return new float[]{t, p, v};
            default: return new float[]{v, p, q};
        }
    }
}
