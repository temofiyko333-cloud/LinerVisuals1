package com.liner.visuals;

import net.minecraft.entity.Entity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/** Власна система ефектів: партикли ударів, сліди, кола від стрибків, цифри шкоди. */
public class Fx {
    private static final Random RAND = new Random();
    private static final int MAX_PARTICLES = 3000;

    public static class P {
        public double x, y, z, px, py, pz, vx, vy, vz;
        public int age, maxAge;
        public float size, alpha, gravity, drag, hue;
        public boolean crit;
        public Config.ParticleStyle style;
    }

    public static class Ring {
        public double x, y, z;
        public int age;
        public final int maxAge = 22;
        public float hue;
    }

    public static class Text {
        public double x, y, z;
        public String text;
        public int age;
        public final int maxAge = 30;
        public boolean crit;
    }

    public static final List<P> PARTICLES = new ArrayList<>();
    public static final List<Ring> RINGS = new ArrayList<>();
    public static final List<Text> TEXTS = new ArrayList<>();

    public static void spawnHit(Entity target, boolean crit) {
        if (PARTICLES.size() > MAX_PARTICLES) return;
        Config.ParticleStyle style = crit ? Config.CRIT_STYLE.get() : Config.HIT_STYLE.get();
        int count = crit ? Config.CRIT_COUNT.get() : Config.HIT_COUNT.get();
        float scale = (crit ? Config.CRIT_SCALE : Config.HIT_SCALE).get().floatValue();
        float alpha = (crit ? Config.CRIT_ALPHA : Config.HIT_ALPHA).get().floatValue();

        double cx = target.getX();
        double cy = target.getY() + target.getBbHeight() * 0.6D;
        double cz = target.getZ();

        for (int i = 0; i < count; i++) {
            P p = new P();
            p.x = p.px = cx + (RAND.nextDouble() - 0.5D) * 0.4D;
            p.y = p.py = cy + (RAND.nextDouble() - 0.5D) * 0.4D;
            p.z = p.pz = cz + (RAND.nextDouble() - 0.5D) * 0.4D;

            double ang = RAND.nextDouble() * Math.PI * 2.0D;
            double sp = 0.05D + RAND.nextDouble() * 0.17D;
            p.vx = Math.cos(ang) * sp;
            p.vz = Math.sin(ang) * sp;
            if (style == Config.ParticleStyle.FIRE) {
                p.vy = 0.02D + RAND.nextDouble() * 0.10D;
                p.gravity = -0.004F;
            } else if (style == Config.ParticleStyle.LINES) {
                p.vy = (RAND.nextDouble() - 0.3D) * 0.25D;
                p.vx *= 1.6D;
                p.vz *= 1.6D;
                p.gravity = 0.01F;
            } else {
                p.vy = 0.04D + RAND.nextDouble() * 0.16D;
                p.gravity = 0.012F;
            }
            p.drag = 0.9F;
            p.maxAge = 12 + RAND.nextInt(14);
            p.size = (0.07F + RAND.nextFloat() * 0.06F) * scale;
            p.alpha = alpha;
            p.style = style;
            p.crit = crit;
            p.hue = RAND.nextFloat() * 0.35F;
            PARTICLES.add(p);
        }
    }

    public static void spawnTrail(double x, double y, double z, float hue) {
        if (PARTICLES.size() > MAX_PARTICLES) return;
        P p = new P();
        p.x = p.px = x;
        p.y = p.py = y;
        p.z = p.pz = z;
        p.vx = (RAND.nextDouble() - 0.5D) * 0.02D;
        p.vy = (RAND.nextDouble() - 0.5D) * 0.02D;
        p.vz = (RAND.nextDouble() - 0.5D) * 0.02D;
        p.drag = 0.9F;
        p.gravity = 0.0F;
        p.maxAge = 16 + RAND.nextInt(8);
        p.size = 0.09F;
        p.alpha = 0.9F;
        p.style = Config.ParticleStyle.STARS;
        p.hue = hue;
        PARTICLES.add(p);
    }

    public static void spawnRing(double x, double y, double z) {
        Ring r = new Ring();
        r.x = x;
        r.y = y;
        r.z = z;
        r.hue = RAND.nextFloat();
        RINGS.add(r);
    }

    public static void spawnText(double x, double y, double z, String text, boolean crit) {
        Text t = new Text();
        t.x = x;
        t.y = y;
        t.z = z;
        t.text = text;
        t.crit = crit;
        TEXTS.add(t);
    }

    public static void tick() {
        for (Iterator<P> it = PARTICLES.iterator(); it.hasNext(); ) {
            P p = it.next();
            p.px = p.x;
            p.py = p.y;
            p.pz = p.z;
            p.x += p.vx;
            p.y += p.vy;
            p.z += p.vz;
            p.vy -= p.gravity;
            p.vx *= p.drag;
            p.vy *= p.drag;
            p.vz *= p.drag;
            if (++p.age >= p.maxAge) it.remove();
        }
        for (Iterator<Ring> it = RINGS.iterator(); it.hasNext(); ) {
            if (++it.next().age >= 22) it.remove();
        }
        for (Iterator<Text> it = TEXTS.iterator(); it.hasNext(); ) {
            if (++it.next().age >= 30) it.remove();
        }
    }

    public static void clear() {
        PARTICLES.clear();
        RINGS.clear();
        TEXTS.clear();
    }
}
