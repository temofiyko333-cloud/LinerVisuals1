package com.liner.visuals;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Заміна ніка на аліас у тексті (без залежностей від Minecraft). */
public final class NickMask {
    private static String cachedName = "";
    private static Pattern cachedPattern = null;

    private NickMask() {
    }

    /** Нік у будь-якому регістрі, але не всередині іншого слова чи ніка (Steve_2 і Steve - різні). */
    public static Pattern pattern(String name) {
        if (cachedPattern == null || !name.equals(cachedName)) {
            cachedName = name;
            cachedPattern = Pattern.compile("(?i)(?<![A-Za-z0-9_])" + Pattern.quote(name) + "(?![A-Za-z0-9_])");
        }
        return cachedPattern;
    }

    public static String mask(String text, Pattern p, String alias) {
        return p.matcher(text).replaceAll(Matcher.quoteReplacement(alias));
    }
}
