package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Fullbright через gamma. Оригінальну яскравість зберігаємо в конфіг, тому навіть якщо гру закрито
 * з увімкненим модулем, при наступному запуску вона відновиться.
 */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class Fullbright {
    private static boolean active = false;

    public static boolean isActive() {
        return active;
    }

    public static void tick(Minecraft mc) {
        if (Config.FULLBRIGHT.on()) {
            if (!active) {
                double g = mc.options.gamma;
                if (g <= 1.0D) {
                    Config.FB_SAVED.set(g);
                    Config.FB_SAVED.save();
                }
                active = true;
            }
            mc.options.gamma = Config.FB_LEVEL.get();
        } else if (active) {
            restore(mc);
        }
    }

    public static void restore(Minecraft mc) {
        double saved = Config.FB_SAVED.get();
        mc.options.gamma = saved >= 0.0D ? saved : 1.0D;
        Config.FB_SAVED.set(-1.0D);
        Config.FB_SAVED.save();
        active = false;
    }

    /** Викликається при старті клієнта; ніколи не кидає винятків, щоб не завалити запуск гри. */
    public static void restoreAtStartup() {
        try {
            Minecraft mc = Minecraft.getInstance();
            double saved = Config.FB_SAVED.get();
            if (mc != null && mc.options != null && saved >= 0.0D) {
                mc.options.gamma = saved;
                Config.FB_SAVED.set(-1.0D);
                Config.FB_SAVED.save();
            }
        } catch (Exception ignored) {
            // нічого страшного
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggedOutEvent event) {
        if (active) restore(Minecraft.getInstance());
    }
}
