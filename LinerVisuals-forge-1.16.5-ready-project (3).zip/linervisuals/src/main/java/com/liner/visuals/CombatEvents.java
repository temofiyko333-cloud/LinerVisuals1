package com.liner.visuals;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.EnderPearlEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.potion.Effects;
import net.minecraft.util.Hand;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Vector3f;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

/** Події гри: удари, стрибки, тіки автоматизації, змах руки. */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class CombatEvents {

    private static class HitInfo {
        final long tick;
        final boolean crit;

        HitInfo(long tick, boolean crit) {
            this.tick = tick;
            this.crit = crit;
        }
    }

    private static final Map<Integer, HitInfo> HITS = new HashMap<>();
    private static final Map<Integer, Float> LAST_HP = new HashMap<>();

    // ---- Aim assist працює щокадру (плавність) ----
    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getInstance();
        AimAssist.frame(mc, event.renderTickTime);
    }

    // ---- Удар: партикли + запис для цифр шкоди ----
    @SubscribeEvent
    public static void onAttack(AttackEntityEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || event.getPlayer() != mc.player) return;
        if (!(event.getTarget() instanceof LivingEntity)) return;
        PlayerEntity p = event.getPlayer();

        boolean crit = p.getAttackStrengthScale(0.5F) > 0.9F && p.fallDistance > 0.0F && !p.isOnGround()
                && !p.onClimbable() && !p.isInWater() && !p.hasEffect(Effects.BLINDNESS)
                && !p.isPassenger() && !p.isSprinting();

        if (Config.HIT_PARTICLES.on()) Fx.spawnHit(event.getTarget(), crit);
        HITS.put(event.getTarget().getId(), new HitInfo(mc.level.getGameTime(), crit));
        HudVisuals.hitPulse = 1.0F;
    }

    // ---- Team Protect: не даємо клікнути по другові ----
    @SubscribeEvent
    public static void onClick(InputEvent.ClickInputEvent event) {
        if (!event.isAttack() || !Config.TEAM_PROTECT.on()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.hitResult instanceof EntityRayTraceResult
                && Team.isFriend(((EntityRayTraceResult) mc.hitResult).getEntity())) {
            event.setCanceled(true);
        }
    }

    // ---- Стрибок: коло під ногами ----
    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || event.getEntityLiving() != mc.player) return;
        if (Config.JUMP_RINGS.on()) {
            Fx.spawnRing(mc.player.getX(), mc.player.getY() + 0.02D, mc.player.getZ());
        }
    }

    // ---- Щотіка ----
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            Minecraft m0 = Minecraft.getInstance();
            if (m0.level != null && m0.player != null && !m0.isPaused()) AutoTool.tick(m0);
            return;
        }
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            Fx.clear();
            HITS.clear();
            LAST_HP.clear();
            return;
        }
        if (mc.isPaused()) return;

        Fx.tick();
        Fullbright.tick(mc);
        Streamer.tick(mc);
        if (!Config.MASTER.on()) return;

        trackDamage(mc);
        pearlTrail(mc);
        slowSwing(mc);

        TriggerBot.tick(mc);
        AutoTotem.tick(mc);
        AutoArmor.tick(mc);
        AutoEat.tick(mc);
        AutoFish.tick(mc);
    }

    private static void trackDamage(Minecraft mc) {
        if (!Config.DAMAGE_TEXT.on()) return;
        long now = mc.level.getGameTime();
        for (LivingEntity le : mc.level.getEntitiesOfClass(LivingEntity.class, mc.player.getBoundingBox().inflate(40.0D))) {
            if (le == mc.player) continue;
            float hp = le.getHealth();
            Float prev = LAST_HP.put(le.getId(), hp);
            HitInfo hi = HITS.get(le.getId());
            if (prev != null && hp < prev - 0.01F && hi != null && now - hi.tick <= 15L) {
                Fx.spawnText(le.getX(), le.getY() + le.getBbHeight() + 0.2D, le.getZ(),
                        String.format("%.1f", prev - hp), hi.crit);
                HITS.remove(le.getId());
            }
        }
        if (now % 200L == 0L) {
            LAST_HP.clear();
            HITS.entrySet().removeIf(e -> now - e.getValue().tick > 40L);
        }
    }

    private static void pearlTrail(Minecraft mc) {
        if (!Config.PEARL_TRAIL.on()) return;
        for (EnderPearlEntity pearl : mc.level.getEntitiesOfClass(EnderPearlEntity.class,
                mc.player.getBoundingBox().inflate(160.0D))) {
            for (int i = 0; i < 4; i++) {
                double f = i / 4.0D;
                Fx.spawnTrail(MathHelper.lerp(f, pearl.xo, pearl.getX()),
                        MathHelper.lerp(f, pearl.yo, pearl.getY()),
                        MathHelper.lerp(f, pearl.zo, pearl.getZ()), i / 4.0F);
            }
        }
    }

    private static void slowSwing(Minecraft mc) {
        if (!Config.HAND_SWING.on() || !Config.HAND_SLOW.get()) return;
        ClientPlayerEntity p = mc.player;
        if (p.swinging && p.swingTime > 0 && p.tickCount % 2 == 0) p.swingTime--;
    }

    // ---- Кастомний змах руки (First-person) ----
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (!Config.HAND_SWING.on() || event.getHand() != Hand.MAIN_HAND) return;
        float s = event.getSwingProgress();
        if (s <= 0.0F) return;

        MatrixStack ms = event.getMatrixStack();
        float sin = MathHelper.sin(s * (float) Math.PI);
        float ang = Config.HAND_ANGLE.get().floatValue();
        float off = Config.HAND_OFFSET.get().floatValue();

        Config.SwingStyle style = Config.HAND_STYLE.get();
        if (style == Config.SwingStyle.SMOOTH) {
            float k = sin * sin * (3.0F - 2.0F * sin);
            ms.mulPose(Vector3f.ZP.rotationDegrees(-ang * 0.4F * k));
            ms.translate(0.0D, -off * 0.3F * k, -off * k);
        } else if (style == Config.SwingStyle.SLASH) {
            float sweep = (0.5F - s) * 2.0F;
            ms.mulPose(Vector3f.YP.rotationDegrees(ang * sweep * sin));
            ms.mulPose(Vector3f.ZP.rotationDegrees(-ang * 0.6F * sin));
            ms.translate(off * sweep * 0.5F, 0.0D, -off * 0.5F * sin);
        } else if (style == Config.SwingStyle.CHOP) {
            ms.mulPose(Vector3f.XP.rotationDegrees(-ang * 1.4F * sin));
            ms.translate(0.0D, off * 0.3F * sin, -off * sin);
        } else {
            ms.translate(0.0D, -off * 1.2F * sin, -off * 0.3F * sin);
            ms.mulPose(Vector3f.ZP.rotationDegrees(ang * 0.3F * sin));
        }
    }
}
