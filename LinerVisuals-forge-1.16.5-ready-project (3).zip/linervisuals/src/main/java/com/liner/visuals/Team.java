package com.liner.visuals;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.List;

/** Список друзів: їх не чіпають aim assist / triggerbot і не можна вдарити (Team Protect). */
public class Team {

    public static boolean isFriend(Entity e) {
        if (!(e instanceof PlayerEntity)) return false;
        String name = e.getName().getString();
        for (String s : Config.TEAM.get()) {
            if (s.equalsIgnoreCase(name)) return true;
        }
        return false;
    }

    public static void add(String name) {
        name = name.trim();
        if (name.isEmpty()) return;
        List<String> list = new ArrayList<>(Config.TEAM.get());
        for (String s : list) if (s.equalsIgnoreCase(name)) return;
        list.add(name);
        Config.TEAM.set(list);
        Config.TEAM.save();
    }

    public static void remove(String name) {
        List<String> list = new ArrayList<>(Config.TEAM.get());
        list.removeIf(s -> s.equalsIgnoreCase(name));
        Config.TEAM.set(list);
        Config.TEAM.save();
    }
}
