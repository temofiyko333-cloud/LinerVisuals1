package com.liner.visuals;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.common.ForgeConfigSpec;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Меню Liner Visuals (Right Shift).
 * Вкладки Combat / Visual / HUD / Utility / Team / Servers / Status, анімовані перемикачі,
 * бінд клавіш на кожен модуль, панель налаштувань (ПКМ), живий статус-екран.
 */
public class ModMenuScreen extends Screen {

    private static final String[] TABS = {"Combat", "Visual", "HUD", "Utility", "Team", "Servers", "Status", "Streamer", "Commands"};
    private static final int TAB_TEAM = 4, TAB_SERVERS = 5, TAB_STATUS = 6, TAB_STREAMER = 7, TAB_COMMANDS = 8;
    private static final int HEADER = 36;
    private static final int SIDEBAR = 98;
    private static final int ROW_H = 30;
    private static final int FOOTER = 26;

    private static final int T_TAB = 0, T_ROW = 1, T_BIND = 2, T_DEC = 3, T_INC = 4,
            T_REMOVE = 5, T_ADD = 6, T_MASTER = 7, T_LOCK = 8, T_FLAG = 9, T_ALIAS = 10, T_CMD_BIND = 11, T_CMD_REMOVE = 12;

    private static class Hit {
        final int x1, y1, x2, y2, type;
        final Object data;

        Hit(int x1, int y1, int x2, int y2, int type, Object data) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.type = type;
            this.data = data;
        }
    }

    private static class Setting {
        final String label;
        final Supplier<String> value;
        final Supplier<Float> frac; // 0..1 для смужки, може бути null
        final Runnable dec;
        final Runnable inc;

        Setting(String label, Supplier<String> value, Supplier<Float> frac, Runnable dec, Runnable inc) {
            this.label = label;
            this.value = value;
            this.frac = frac;
            this.dec = dec;
            this.inc = inc;
        }
    }

    private final List<Hit> hits = new ArrayList<>();
    private final Map<Object, Float> anim = new HashMap<>();
    private final long openTime = System.currentTimeMillis();

    private int px, py, pw, ph;
    private int tab = 0;
    private int scroll = 0;
    private Config.Module selected = null;
    private Config.Module listening = null;
    private int listeningCmd = -1;
    private String input = "";
    private String hoverDesc = "";

    public ModMenuScreen() {
        super(new StringTextComponent("Liner Visuals"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private boolean isListTab() {
        return tab == TAB_TEAM || tab == TAB_SERVERS;
    }

    private boolean isInputTab() {
        return isListTab() || tab == TAB_STREAMER || tab == TAB_COMMANDS;
    }

    // ------------------------------------------------------------------
    //  Малювання
    // ------------------------------------------------------------------
    @Override
    public void render(MatrixStack ms, int mx, int my, float pt) {
        hits.clear();
        hoverDesc = "";
        pw = Math.min(470, this.width - 12);
        ph = Math.min(310, this.height - 12);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;

        float t = Math.min(1.0F, (System.currentTimeMillis() - openTime) / 240.0F);
        float ease = 1.0F - (1.0F - t) * (1.0F - t) * (1.0F - t);

        int bgA = (int) (0xA8 * ease);
        this.fillGradient(ms, 0, 0, this.width, this.height, (bgA << 24) | 0x0A0A0A, (bgA << 24) | 0x000000);

        ms.pushPose();
        ms.translate(0.0D, (1.0F - ease) * 14.0F, 0.0D);

        // м'яка тінь
        for (int i = 5; i >= 1; i--) {
            box(ms, px - i, py - i, px + pw + i, py + ph + i, 0x0E000000);
        }
        // веселкова рамка
        for (int i = 0; i < pw + 2; i += 4) {
            int col = 0xFF000000 | accent(i / 240.0F);
            int xa = px - 1 + i, xb = Math.min(xa + 4, px + pw + 1);
            AbstractGui.fill(ms, xa, py - 1, xb, py, col);
            AbstractGui.fill(ms, xa, py + ph, xb, py + ph + 1, col);
        }
        AbstractGui.fill(ms, px - 1, py, px, py + ph, 0xFF000000 | accent(0.0F));
        AbstractGui.fill(ms, px + pw, py, px + pw + 1, py + ph, 0xFF000000 | accent(0.5F));
        box(ms, px, py, px + pw, py + ph, 0xF3030303);

        drawHeader(ms);
        drawSidebar(ms, mx, my);

        int x0 = px + SIDEBAR + 10;
        int y0 = py + HEADER + 10;
        int x1 = px + pw - 10;
        int yEnd = py + ph - FOOTER - 4;

        if (tab == TAB_STATUS) drawStatus(ms, x0, y0, x1, yEnd);
        else if (tab == TAB_STREAMER) drawStreamer(ms, mx, my, x0, y0, x1, yEnd);
        else if (tab == TAB_COMMANDS) drawCommands(ms, mx, my, x0, y0, x1, yEnd);
        else if (isListTab()) drawListPage(ms, mx, my, x0, y0, x1, yEnd);
        else drawModules(ms, mx, my, x0, y0, x1, yEnd);

        drawFooter(ms);
        ms.popPose();

        super.render(ms, mx, my, pt);
    }

    private void drawHeader(MatrixStack ms) {
        AbstractGui.fill(ms, px, py, px + pw, py + HEADER, 0xFF0A0A0A);
        for (int i = 0; i < pw; i += 3) {
            AbstractGui.fill(ms, px + i, py + HEADER - 1, Math.min(px + i + 3, px + pw), py + HEADER,
                    0xFF000000 | accent(i / 260.0F));
        }

        ms.pushPose();
        ms.translate(px + 12, py + 9, 0.0D);
        ms.scale(1.5F, 1.5F, 1.0F);
        drawChroma(ms, "LINER VISUALS", 0.0F, 0.0F);
        ms.popPose();
        this.font.drawShadow(ms, "forge 1.16.5", px + 12 + 13 * 9, py + 21, 0xFF5A5A5A);

        if (Config.COMBAT_LOCK.get() && this.minecraft != null && !CombatGate.allowed(this.minecraft)) {
            this.font.drawShadow(ms, "SAFE MODE", px + pw - 150, py + 8, 0xFFFFFFFF);
        }

        int sx = px + pw - 38, sy = py + 12;
        this.font.drawShadow(ms, "ENABLED", sx - 50, sy + 1, 0xFFB4B4B4);
        drawSwitch(ms, sx, sy, "master", Config.MASTER.enabled.get(), 0.0F);
        hits.add(new Hit(sx - 54, sy - 4, sx + 28, sy + 16, T_MASTER, null));
    }

    private void drawSidebar(MatrixStack ms, int mx, int my) {
        AbstractGui.fill(ms, px, py + HEADER, px + SIDEBAR, py + ph, 0xFF070707);
        for (int i = 0; i < TABS.length; i++) {
            int y = py + HEADER + 8 + i * 23;
            boolean sel = i == tab;
            boolean hover = in(mx, my, px + 6, y, px + SIDEBAR - 6, y + 20);
            float a = approach("tab" + i, sel ? 1.0F : hover ? 0.5F : 0.0F);

            int bg = ((int) (0xFF * a) << 24) | Chroma.mixRgb(0x070707, 0x1F1F1F, a);
            box(ms, px + 6, y, px + SIDEBAR - 6, y + 20, bg);
            if (sel) AbstractGui.fill(ms, px + 6, y + 2, px + 8, y + 18, 0xFF000000 | accent(i * 0.12F));

            // кольорова позначка
            AbstractGui.fill(ms, px + 15, y + 7, px + 22, y + 13, 0xFF000000 | accent(i * 0.12F));
            this.font.drawShadow(ms, TABS[i], px + 28, y + 6, sel ? 0xFFFFFFFF : 0xFFA8A8A8);

            String badge = badge(i);
            if (!badge.isEmpty()) {
                this.font.drawShadow(ms, badge, px + SIDEBAR - 12 - this.font.width(badge), y + 6, 0xFF6A6A6A);
            }
            hits.add(new Hit(px + 6, y, px + SIDEBAR - 6, y + 20, T_TAB, i));
        }
    }

    private String badge(int i) {
        if (i < 4) {
            int on = 0, total = 0;
            for (Config.Module m : Config.MODULES) {
                if (m.cat == Config.Category.values()[i] && !m.hidden) {
                    total++;
                    if (m.enabled.get()) on++;
                }
            }
            return on + "/" + total;
        }
        if (i == TAB_TEAM) return String.valueOf(Config.TEAM.get().size());
        if (i == TAB_SERVERS) return String.valueOf(Config.COMBAT_SERVERS.get().size());
        if (i == TAB_STREAMER) return Config.STREAMER.enabled.get() ? "ON" : "OFF";
        if (i == TAB_COMMANDS) return String.valueOf(CommandBinds.all().size());
        return "";
    }

    private List<Config.Module> modulesOfTab() {
        Config.Category cat = Config.Category.values()[tab];
        List<Config.Module> list = new ArrayList<>();
        for (Config.Module m : Config.MODULES) {
            if (m.cat == cat && !m.hidden) list.add(m);
        }
        return list;
    }

    private void drawModules(MatrixStack ms, int mx, int my, int x0, int y0, int x1, int yEnd) {
        List<Config.Module> list = modulesOfTab();
        int rows = Math.max(1, (yEnd - y0) / ROW_H);
        int maxScroll = Math.max(0, list.size() - rows);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        int listW = selected != null ? (int) ((x1 - x0) * 0.58D) : (x1 - x0);

        for (int idx = scroll; idx < Math.min(list.size(), scroll + rows); idx++) {
            Config.Module m = list.get(idx);
            int y = y0 + (idx - scroll) * ROW_H;
            boolean hover = in(mx, my, x0, y, x0 + listW, y + ROW_H - 3);
            boolean on = m.enabled.get();
            float hue = idx * 0.08F;
            float a = approach(m, on ? 1.0F : 0.0F);

            if (hover || m == selected) {
                this.fillGradient(ms, x0, y, x0 + listW, y + ROW_H - 3, 0xFF1F1F1F, 0xFF141414);
            } else {
                box(ms, x0, y, x0 + listW, y + ROW_H - 3, 0xFF0F0F0F);
            }
            AbstractGui.fill(ms, x0, y + 2, x0 + 2, y + ROW_H - 5,
                    ((int) (0xFF * a) << 24) | accent(hue));
            if (hover) {
                AbstractGui.fill(ms, x0 + 2, y + ROW_H - 4, x0 + listW, y + ROW_H - 3,
                        0x66000000 | accent(hue));
            }

            int swx = x0 + listW - 32;
            int bw = 48, bx = swx - bw - 8;

            this.font.drawShadow(ms, m.name, x0 + 9, y + 6, on ? 0xFFFFFFFF : 0xFFBDBDBD);
            boolean locked = m.lockedHere();
            this.font.drawShadow(ms, trim(locked ? "заблоковано на цьому сервері (безпечний режим)" : m.desc, bx - x0 - 14),
                    x0 + 9, y + 17, locked ? 0xFF8C8C8C : 0xFF7C7C7C);

            drawSwitch(ms, swx, y + 8, m, on, hue);

            boolean lis = listening == m;
            box(ms, bx, y + 6, bx + bw, y + ROW_H - 9, lis ? 0xFF2A2A2A : 0xFF090909);
            String bt = lis ? "press..." : keyName(m.key.get());
            this.font.drawShadow(ms, bt, bx + (bw - this.font.width(bt)) / 2.0F, y + 10,
                    lis ? 0xFFFFFFFF : m.key.get() > 0 ? 0xFFE6E6E6 : 0xFF6A6A6A);

            hits.add(new Hit(bx, y + 6, bx + bw, y + ROW_H - 9, T_BIND, m));
            hits.add(new Hit(x0, y, x0 + listW, y + ROW_H - 3, T_ROW, m));
            if (hover) hoverDesc = m.desc;
        }

        if (maxScroll > 0) {
            int trackH = yEnd - y0;
            int barH = Math.max(16, trackH * rows / list.size());
            int barY = y0 + (trackH - barH) * scroll / maxScroll;
            AbstractGui.fill(ms, x0 + listW + 3, y0, x0 + listW + 5, yEnd, 0xFF0F0F0F);
            AbstractGui.fill(ms, x0 + listW + 3, barY, x0 + listW + 5, barY + barH, 0xFF000000 | accent(0.3F));
        }

        if (selected != null) drawSettings(ms, x0 + listW + 10, y0, x1, yEnd);
    }

    private void drawSettings(MatrixStack ms, int sx, int y0, int x1, int yEnd) {
        box(ms, sx, y0, x1, yEnd, 0xFF0B0B0B);
        AbstractGui.fill(ms, sx, y0, x1, y0 + 1, 0xFF000000 | accent(0.0F));
        this.font.drawShadow(ms, selected.name, sx + 8, y0 + 8, 0xFF000000 | accent(0.0F));
        this.font.drawShadow(ms, "settings", sx + 8 + this.font.width(selected.name) + 5, y0 + 8, 0xFF5A5A5A);

        List<Setting> ss = settingsFor(selected);
        int ry = y0 + 26;
        if (ss.isEmpty()) {
            this.font.drawShadow(ms, "У цього модуля нема налаштувань", sx + 8, ry, 0xFF6A6A6A);
            return;
        }
        int w = x1 - sx;
        for (Setting s : ss) {
            if (ry + 34 > yEnd) break;
            this.font.drawShadow(ms, s.label, sx + 8, ry, 0xFFBDBDBD);

            int by = ry + 13;
            box(ms, sx + 8, by, sx + 24, by + 14, 0xFF1C1C1C);
            this.font.drawShadow(ms, "-", sx + 14, by + 3, 0xFFFFFFFF);
            box(ms, x1 - 24, by, x1 - 8, by + 14, 0xFF1C1C1C);
            this.font.drawShadow(ms, "+", x1 - 18, by + 3, 0xFFFFFFFF);

            String val = s.value.get();
            int vc = val.equals("ON") ? 0xFFFFFFFF : val.equals("OFF") ? 0xFF8C8C8C : 0xFFFFFFFF;
            this.font.drawShadow(ms, val, sx + w / 2.0F - this.font.width(val) / 2.0F, by + 3, vc);

            if (s.frac != null) {
                float f = Math.max(0.0F, Math.min(1.0F, s.frac.get()));
                int bx1 = sx + 8, bx2 = x1 - 8;
                AbstractGui.fill(ms, bx1, ry + 9, bx2, ry + 11, 0xFF1C1C1C);
                int fillTo = bx1 + (int) ((bx2 - bx1) * f);
                for (int i = bx1; i < fillTo; i += 2) {
                    AbstractGui.fill(ms, i, ry + 9, Math.min(i + 2, fillTo), ry + 11, 0xFF000000 | accent(i / 160.0F));
                }
            }
            hits.add(new Hit(sx + 8, by, sx + 24, by + 14, T_DEC, s));
            hits.add(new Hit(x1 - 24, by, x1 - 8, by + 14, T_INC, s));
            ry += 36;
        }
    }

    private void drawListPage(MatrixStack ms, int mx, int my, int x0, int y0, int x1, int yEnd) {
        boolean team = tab == TAB_TEAM;
        List<? extends String> entries = team ? Config.TEAM.get() : Config.COMBAT_SERVERS.get();

        this.font.drawShadow(ms, team ? "TEAM" : "ALLOWED SERVERS", x0, y0, 0xFF000000 | accent(0.0F));
        String sub = team ? "друзі: aim assist і triggerbot їх ігнорують, вдарити їх не можна"
                : "чити та автоматизація працюють лише тут і в одиночній грі (на решті - безпечний режим)";
        this.font.drawShadow(ms, sub, x0 + 10 + this.font.width(team ? "TEAM" : "ALLOWED SERVERS"), y0, 0xFF7C7C7C);

        int iy = y0 + 16;
        box(ms, x0, iy, x1 - 62, iy + 18, 0xFF090909);
        boolean caret = (System.currentTimeMillis() / 500L) % 2L == 0L;
        String shown = input.isEmpty() ? (team ? "нікнейм друга..." : "адреса сервера, напр. 2b2t.org") : input;
        this.font.drawShadow(ms, shown + (!input.isEmpty() && caret ? "_" : ""), x0 + 6, iy + 5,
                input.isEmpty() ? 0xFF5A5A5A : 0xFFFFFFFF);
        box(ms, x1 - 58, iy, x1, iy + 18, 0xFF000000 | accent(0.2F));
        this.font.drawShadow(ms, "ADD", x1 - 58 + (58 - this.font.width("ADD")) / 2.0F, iy + 5, 0xFF050505);
        hits.add(new Hit(x1 - 58, iy, x1, iy + 18, T_ADD, null));

        int y = iy + 26;
        if (!team) {
            box(ms, x0, y, x1, y + 20, 0xFF0F0F0F);
            this.font.drawShadow(ms, "Server lock", x0 + 8, y + 6, 0xFFE6E6E6);
            this.font.drawShadow(ms, "інші сервери = безпечний режим", x0 + 8 + this.font.width("Server lock") + 8, y + 6, 0xFF7C7C7C);
            drawSwitch(ms, x1 - 32, y + 5, "lock", Config.COMBAT_LOCK.get(), 0.1F);
            hits.add(new Hit(x0, y, x1, y + 20, T_LOCK, null));
            y += 26;
        }

        int rows = Math.max(1, (yEnd - y) / 20);
        int maxScroll = Math.max(0, entries.size() - rows);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
        for (int i = scroll; i < Math.min(entries.size(), scroll + rows); i++) {
            String e = entries.get(i);
            int ey = y + (i - scroll) * 20;
            boolean hover = in(mx, my, x0, ey, x1, ey + 18);
            box(ms, x0, ey, x1, ey + 18, hover ? 0xFF1A1A1A : 0xFF0F0F0F);
            AbstractGui.fill(ms, x0, ey + 2, x0 + 2, ey + 16, 0xFF000000 | accent(i * 0.1F));
            this.font.drawShadow(ms, e, x0 + 9, ey + 5, 0xFFFFFFFF);
            this.font.drawShadow(ms, "x", x1 - 12, ey + 5, hover ? 0xFF8C8C8C : 0xFF6A6A6A);
            hits.add(new Hit(x1 - 22, ey, x1, ey + 18, T_REMOVE, e));
        }
        if (entries.isEmpty()) {
            this.font.drawShadow(ms, "Список порожній", x0 + 8, y + 5, 0xFF5A5A5A);
        }
    }

    // ---------------- Commands: кнопка = команда ----------------
    private void drawCommands(MatrixStack ms, int mx, int my, int x0, int y0, int x1, int yEnd) {
        this.font.drawShadow(ms, "COMMAND BINDS", x0, y0, 0xFF000000 | accent(0.0F));
        this.font.drawShadow(ms, "кнопка = команда в чат, виконується одразу",
                x0 + 10 + this.font.width("COMMAND BINDS"), y0, 0xFF7C7C7C);

        int y = y0 + 16;
        drawToggleCard(ms, mx, my, x0, y, x1, "Command Binds", "вимкни, щоб кнопки не надсилали команди",
                "cb-main", Config.COMMAND_BINDS.enabled.get(), T_ROW, Config.COMMAND_BINDS);
        y += 30;

        box(ms, x0, y, x1 - 58, y + 18, 0xFF090909);
        boolean caret = (System.currentTimeMillis() / 500L) % 2L == 0L;
        String shown = input.isEmpty() ? "/home" : input;
        this.font.drawShadow(ms, trim(shown, x1 - x0 - 80) + (!input.isEmpty() && caret ? "_" : ""), x0 + 6, y + 5,
                input.isEmpty() ? 0xFF5A5A5A : 0xFFFFFFFF);
        box(ms, x1 - 54, y, x1, y + 18, 0xFF000000 | accent(0.2F));
        this.font.drawShadow(ms, "ADD", x1 - 54 + (54 - this.font.width("ADD")) / 2.0F, y + 5, 0xFF050505);
        hits.add(new Hit(x1 - 54, y, x1, y + 18, T_ADD, null));
        y += 26;

        List<CommandBinds.Bind> binds = CommandBinds.all();
        int rows = Math.max(1, (yEnd - y) / 22);
        int maxScroll = Math.max(0, binds.size() - rows);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        for (int i = scroll; i < Math.min(binds.size(), scroll + rows); i++) {
            CommandBinds.Bind bd = binds.get(i);
            int ey = y + (i - scroll) * 22;
            boolean hover = in(mx, my, x0, ey, x1, ey + 20);
            box(ms, x0, ey, x1, ey + 20, hover ? 0xFF1A1A1A : 0xFF0F0F0F);
            AbstractGui.fill(ms, x0, ey + 2, x0 + 2, ey + 18, bd.key > 0 ? (0xFF000000 | accent(i * 0.1F)) : 0xFF262626);

            int bw = 56, bx = x1 - 26 - bw;
            this.font.drawShadow(ms, trim(bd.cmd, bx - x0 - 16), x0 + 9, ey + 6, 0xFFFFFFFF);

            boolean lis = listeningCmd == i;
            box(ms, bx, ey + 3, bx + bw, ey + 17, lis ? 0xFF2A2A2A : 0xFF090909);
            String bt = lis ? "press..." : keyName(bd.key);
            this.font.drawShadow(ms, bt, bx + (bw - this.font.width(bt)) / 2.0F, ey + 6,
                    lis ? 0xFFFFFFFF : bd.key > 0 ? 0xFFE6E6E6 : 0xFF6A6A6A);
            this.font.drawShadow(ms, "x", x1 - 12, ey + 6, hover ? 0xFFFFFFFF : 0xFF6A6A6A);

            hits.add(new Hit(bx, ey + 3, bx + bw, ey + 17, T_CMD_BIND, i));
            hits.add(new Hit(x1 - 22, ey, x1, ey + 20, T_CMD_REMOVE, i));
        }
        if (binds.isEmpty()) {
            this.font.drawShadow(ms, "Ще нема команд. Введи, напр., /home і натисни ADD.", x0 + 8, y + 5, 0xFF5A5A5A);
        }
    }

    // ---------------- Streamer: аліас та перемикачі ----------------
    private void drawToggleCard(MatrixStack ms, int mx, int my, int x0, int y, int x1, String label, String sub,
                                Object key, boolean on, int hitType, Object data) {
        boolean hover = in(mx, my, x0, y, x1, y + 24);
        box(ms, x0, y, x1, y + 24, hover ? 0xFF1A1A1A : 0xFF0F0F0F);
        AbstractGui.fill(ms, x0, y + 2, x0 + 2, y + 22, on ? (0xFF000000 | accent(0.0F)) : 0xFF262626);
        this.font.drawShadow(ms, label, x0 + 9, y + 4, 0xFFFFFFFF);
        this.font.drawShadow(ms, trim(sub, x1 - x0 - 60), x0 + 9, y + 14, 0xFF7C7C7C);
        drawSwitch(ms, x1 - 32, y + 6, key, on, 0.0F);
        hits.add(new Hit(x0, y, x1, y + 24, hitType, data));
    }

    private void drawStreamer(MatrixStack ms, int mx, int my, int x0, int y0, int x1, int yEnd) {
        this.font.drawShadow(ms, "STREAMER MODE", x0, y0, 0xFF000000 | accent(0.0F));
        this.font.drawShadow(ms, "ховає твій нік лише для тебе, інші бачать справжній",
                x0 + 10 + this.font.width("STREAMER MODE"), y0, 0xFF7C7C7C);

        int y = y0 + 16;
        drawToggleCard(ms, mx, my, x0, y, x1, "Streamer Mode", "головний перемикач режиму",
                "st-main", Config.STREAMER.enabled.get(), T_ROW, Config.STREAMER);
        y += 28;
        drawToggleCard(ms, mx, my, x0, y, x1, "Hide in chat", "чат, повідомлення про смерть і вхід, actionbar",
                "st-chat", Config.STREAMER_CHAT.get(), T_FLAG, Config.STREAMER_CHAT);
        y += 28;
        drawToggleCard(ms, mx, my, x0, y, x1, "Hide in tab list", "твій рядок у списку гравців (Tab)",
                "st-tab", Config.STREAMER_TAB.get(), T_FLAG, Config.STREAMER_TAB);
        y += 34;

        this.font.drawShadow(ms, "Чим замінювати твій нік", x0, y, 0xFFBDBDBD);
        y += 12;
        box(ms, x0, y, x1 - 58, y + 18, 0xFF090909);
        boolean caret = (System.currentTimeMillis() / 500L) % 2L == 0L;
        this.font.drawShadow(ms, input + (caret ? "_" : ""), x0 + 6, y + 5, 0xFFFFFFFF);
        box(ms, x1 - 54, y, x1, y + 18, 0xFF000000 | accent(0.2F));
        this.font.drawShadow(ms, "SET", x1 - 54 + (54 - this.font.width("SET")) / 2.0F, y + 5, 0xFF050505);
        hits.add(new Hit(x1 - 54, y, x1, y + 18, T_ALIAS, null));
        y += 24;

        this.font.drawShadow(ms, "Зараз показується: " + Config.STREAMER_ALIAS.get(), x0, y, 0xFFFFFFFF);
        y += 16;
        if (y + 10 < yEnd) {
            this.font.drawShadow(ms, "Справжній нік тут навмисно не показується - меню безпечне для стріму.", x0, y, 0xFF7C7C7C);
        }
        y += 11;
        if (y + 10 < yEnd) {
            this.font.drawShadow(ms, "Не охоплює: scoreboard збоку та деякі серверні плагіни з власними нікнеймами.", x0, y, 0xFF7C7C7C);
        }
    }

    // ---------------- Status: живі показники ----------------
    private void drawStatus(MatrixStack ms, int x0, int y0, int x1, int yEnd) {
        this.font.drawShadow(ms, "STATUS", x0, y0, 0xFF000000 | accent(0.0F));
        this.font.drawShadow(ms, "живі показники - одразу видно, що працює", x0 + 10 + this.font.width("STATUS"), y0, 0xFF7C7C7C);

        List<Object[]> rows = new ArrayList<>();
        boolean master = Config.MASTER.enabled.get();
        rows.add(new Object[]{"Master", master ? "ON" : "OFF", master ? 0xFFFFFFFF : 0xFF8C8C8C});

        String server = "Not connected";
        if (this.minecraft != null) {
            if (this.minecraft.getSingleplayerServer() != null) {
                server = "Singleplayer";
            } else {
                ServerData sd = this.minecraft.getCurrentServer();
                if (sd != null && sd.ip != null) server = sd.ip;
            }
        }
        rows.add(new Object[]{"Server", server, 0xFFFFFFFF});

        if (!Config.COMBAT_LOCK.get()) {
            rows.add(new Object[]{"Server lock", "OFF (no limits)", 0xFFC8C8C8});
        } else {
            boolean ok = this.minecraft != null && CombatGate.allowed(this.minecraft);
            rows.add(new Object[]{"Server lock", ok ? "ALL MODULES" : "SAFE MODE", ok ? 0xFFFFFFFF : 0xFF8C8C8C});
        }

        int fps = HudVisuals.currentFps();
        rows.add(new Object[]{"FPS", String.valueOf(fps), fps >= 60 ? 0xFFFFFFFF : fps >= 30 ? 0xFFC8C8C8 : 0xFF8C8C8C});
        int ping = this.minecraft != null ? HudVisuals.ping(this.minecraft) : 0;
        rows.add(new Object[]{"Ping", ping + " ms", ping < 80 ? 0xFFFFFFFF : ping < 150 ? 0xFFC8C8C8 : 0xFF8C8C8C});

        LivingEntity at = AimAssist.currentTarget();
        rows.add(new Object[]{"Aim Assist target", at != null ? at.getName().getString() : "none", at != null ? 0xFFFFFFFF : 0xFF8A8A8A});

        String fb = Fullbright.isActive() && this.minecraft != null
                ? "ON (gamma " + fmt(this.minecraft.options.gamma) + ")" : "OFF";
        rows.add(new Object[]{"Fullbright", fb, Fullbright.isActive() ? 0xFFFFFFFF : 0xFF8A8A8A});

        int on = 0, total = 0;
        for (Config.Module m : Config.MODULES) {
            if (m.hidden) continue;
            total++;
            if (m.enabled.get()) on++;
        }
        rows.add(new Object[]{"Freecam", Freecam.isActive() ? "ON" : "OFF", Freecam.isActive() ? 0xFFFFFFFF : 0xFF8A8A8A});
        boolean fishOn = Config.AUTO_FISH.enabled.get();
        rows.add(new Object[]{"Auto Fish", fishOn ? AutoFish.status() : "OFF", fishOn ? 0xFFFFFFFF : 0xFF8A8A8A});
        rows.add(new Object[]{"Streamer mode", Config.STREAMER.enabled.get() ? "ON" : "OFF",
                Config.STREAMER.enabled.get() ? 0xFFFFFFFF : 0xFF8A8A8A});
        rows.add(new Object[]{"Modules on", on + " / " + total, 0xFFFFFFFF});
        rows.add(new Object[]{"Team members", String.valueOf(Config.TEAM.get().size()), 0xFFFFFFFF});
        rows.add(new Object[]{"Allowed servers", String.valueOf(Config.COMBAT_SERVERS.get().size()), 0xFFFFFFFF});

        int gap = 6;
        int cw = (x1 - x0 - gap) / 2;
        int ch = 32;
        for (int i = 0; i < rows.size(); i++) {
            int cx = x0 + (i % 2) * (cw + gap);
            int cy = y0 + 18 + (i / 2) * (ch + gap);
            if (cy + ch > yEnd) break;
            Object[] r = rows.get(i);
            box(ms, cx, cy, cx + cw, cy + ch, 0xFF0F0F0F);
            AbstractGui.fill(ms, cx, cy + 3, cx + 2, cy + ch - 3, (Integer) r[2]);
            this.font.drawShadow(ms, (String) r[0], cx + 9, cy + 6, 0xFF7C7C7C);
            this.font.drawShadow(ms, trim((String) r[1], cw - 16), cx + 9, cy + 18, (Integer) r[2]);
        }
    }

    private void drawFooter(MatrixStack ms) {
        int fy = py + ph - FOOTER;
        AbstractGui.fill(ms, px + SIDEBAR, fy, px + pw, py + ph, 0xFF070707);
        String text;
        if (!hoverDesc.isEmpty()) text = hoverDesc;
        else if (isListTab()) text = "Enter або ADD - додати  |  клік по рядку (x) - видалити  |  колесо - прокрутка";
        else if (tab == TAB_STATUS) text = "RSHIFT або ESC - закрити меню";
        else if (tab == TAB_COMMANDS) text = "Введи команду -> ADD -> клікни на клавішу й натисни кнопку  |  потім кнопка в грі = команда";
        else if (tab == TAB_STREAMER) text = "Enter або SET - зберегти аліас  |  працює лише в твоєму клієнті";
        else text = "ЛКМ - вмик/вимик  |  ПКМ - налаштування  |  клік на клавішу -> натисни кнопку (ESC = прибрати)";
        this.font.drawShadow(ms, trim(text, pw - SIDEBAR - 20), px + SIDEBAR + 10, fy + 9, 0xFF8A8A8A);
    }

    // ------------------------------------------------------------------
    //  Малювальні хелпери
    // ------------------------------------------------------------------
    /** Чорно-білий акцент: білий із м'яким сірим відблиском, що біжить (замість веселки). */
    private static int accent(float hue) {
        float t = (System.currentTimeMillis() % 3200L) / 3200.0F;
        float w = 0.5F + 0.5F * (float) Math.sin(hue * 6.0F - t * 6.2831855F);
        int v = 150 + (int) (105.0F * w);
        return (v << 16) | (v << 8) | v;
    }

    /** Прямокутник зі скошеними кутами (імітація заокруглення). */
    private static void box(MatrixStack ms, int x1, int y1, int x2, int y2, int c) {
        AbstractGui.fill(ms, x1 + 1, y1, x2 - 1, y2, c);
        AbstractGui.fill(ms, x1, y1 + 1, x1 + 1, y2 - 1, c);
        AbstractGui.fill(ms, x2 - 1, y1 + 1, x2, y2 - 1, c);
    }

    /** Плавна анімація значення до цілі (для перемикачів і вкладок). */
    private float approach(Object key, float target) {
        float cur = anim.containsKey(key) ? anim.get(key) : target;
        cur += (target - cur) * 0.25F;
        if (Math.abs(target - cur) < 0.01F) cur = target;
        anim.put(key, cur);
        return cur;
    }

    private void drawSwitch(MatrixStack ms, int x, int y, Object key, boolean on, float hue) {
        float a = approach(key, on ? 1.0F : 0.0F);
        int track = 0xFF000000 | Chroma.mixRgb(0x2E2E2E, 0xF2F2F2, a);
        box(ms, x, y, x + 24, y + 12, track);
        int kx = x + 2 + (int) (12.0F * a);
        box(ms, kx, y + 2, kx + 8, y + 10, 0xFF000000 | Chroma.mixRgb(0xE8E8E8, 0x0A0A0A, a));
    }

    private void drawSwitch(MatrixStack ms, int x, int y, Config.Module m, boolean on, float hue) {
        drawSwitch(ms, x, y, (Object) m, on, hue);
    }

    private void drawChroma(MatrixStack ms, String text, float x, float y) {
        float cx = x;
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            this.font.drawShadow(ms, ch, cx, y, 0xFF000000 | accent(i * 0.06F));
            cx += this.font.width(ch);
        }
    }

    private String trim(String s, int maxW) {
        if (this.font.width(s) <= maxW) return s;
        String t = s;
        while (t.length() > 1 && this.font.width(t + "..") > maxW) t = t.substring(0, t.length() - 1);
        return t + "..";
    }

    private static boolean in(int mx, int my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    // ------------------------------------------------------------------
    //  Ввід
    // ------------------------------------------------------------------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (Hit h : hits) {
            if (mx >= h.x1 && mx < h.x2 && my >= h.y1 && my < h.y2) {
                handle(h, button);
                return true;
            }
        }
        listening = null;
        listeningCmd = -1;
        return super.mouseClicked(mx, my, button);
    }

    private void handle(Hit h, int button) {
        switch (h.type) {
            case T_TAB:
                tab = (Integer) h.data;
                scroll = 0;
                selected = null;
                listening = null;
                listeningCmd = -1;
                input = tab == TAB_STREAMER ? Config.STREAMER_ALIAS.get() : "";
                break;
            case T_FLAG: {
                ForgeConfigSpec.BooleanValue fv = (ForgeConfigSpec.BooleanValue) h.data;
                fv.set(!fv.get());
                fv.save();
                break;
            }
            case T_ALIAS:
                setAlias();
                break;
            case T_CMD_BIND:
                listeningCmd = (Integer) h.data;
                listening = null;
                break;
            case T_CMD_REMOVE:
                CommandBinds.remove((Integer) h.data);
                listeningCmd = -1;
                break;
            case T_ROW: {
                Config.Module m = (Config.Module) h.data;
                if (button == 1) selected = (selected == m) ? null : m;
                else m.toggle();
                break;
            }
            case T_BIND:
                listening = (Config.Module) h.data;
                listeningCmd = -1;
                break;
            case T_DEC:
                ((Setting) h.data).dec.run();
                break;
            case T_INC:
                ((Setting) h.data).inc.run();
                break;
            case T_MASTER:
                Config.MASTER.toggle();
                break;
            case T_LOCK:
                Config.COMBAT_LOCK.set(!Config.COMBAT_LOCK.get());
                Config.COMBAT_LOCK.save();
                break;
            case T_ADD:
                addEntry();
                break;
            case T_REMOVE:
                removeEntry((String) h.data);
                break;
            default:
                break;
        }
    }

    private void setAlias() {
        String v = input.trim();
        if (v.isEmpty()) return;
        Config.STREAMER_ALIAS.set(v);
        Config.STREAMER_ALIAS.save();
    }

    private void addEntry() {
        if (tab == TAB_STREAMER) {
            setAlias();
            return;
        }
        if (tab == TAB_COMMANDS) {
            CommandBinds.add(input);
            input = "";
            return;
        }
        String v = input.trim();
        if (v.isEmpty()) return;
        if (tab == TAB_TEAM) {
            Team.add(v);
        } else {
            List<String> l = new ArrayList<>(Config.COMBAT_SERVERS.get());
            String low = v.toLowerCase();
            if (!l.contains(low)) l.add(low);
            Config.COMBAT_SERVERS.set(l);
            Config.COMBAT_SERVERS.save();
        }
        input = "";
    }

    private void removeEntry(String e) {
        if (tab == TAB_TEAM) {
            Team.remove(e);
        } else {
            List<String> l = new ArrayList<>(Config.COMBAT_SERVERS.get());
            l.remove(e);
            Config.COMBAT_SERVERS.set(l);
            Config.COMBAT_SERVERS.save();
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listeningCmd >= 0) {
            CommandBinds.setKey(listeningCmd, keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode);
            listeningCmd = -1;
            return true;
        }
        if (listening != null) {
            listening.key.set(keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode);
            listening.key.save();
            listening = null;
            return true;
        }
        if (isInputTab()) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!input.isEmpty()) input = input.substring(0, input.length() - 1);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                addEntry();
                return true;
            }
        } else if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char c, int modifiers) {
        if (tab == TAB_COMMANDS && listening == null && listeningCmd < 0 && input.length() < 100 && c >= 32 && c != 127 && c != '\u00a7') {
            input += c;
            return true;
        }
        if (tab == TAB_STREAMER && listening == null && input.length() < 24 && c >= 32 && c != 127 && c != '\u00a7') {
            input += c;
            return true;
        }
        if (isListTab() && listening == null && input.length() < 40
                && (Character.isLetterOrDigit(c) || c == '_' || c == '.' || c == '-' || c == ':')) {
            input += c;
            return true;
        }
        return super.charTyped(c, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll -= (int) Math.signum(delta);
        if (scroll < 0) scroll = 0;
        return true;
    }

    // ------------------------------------------------------------------
    //  Назви клавіш
    // ------------------------------------------------------------------
    private static String keyName(int code) {
        if (code <= 0) return "NONE";
        if (code >= GLFW.GLFW_KEY_F1 && code <= GLFW.GLFW_KEY_F12) return "F" + (code - GLFW.GLFW_KEY_F1 + 1);
        switch (code) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT:   return "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT:    return "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_LEFT_CONTROL:  return "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_ALT:     return "RALT";
            case GLFW.GLFW_KEY_LEFT_ALT:      return "LALT";
            case GLFW.GLFW_KEY_SPACE:         return "SPACE";
            case GLFW.GLFW_KEY_TAB:           return "TAB";
            case GLFW.GLFW_KEY_ENTER:         return "ENTER";
            case GLFW.GLFW_KEY_BACKSPACE:     return "BKSP";
            case GLFW.GLFW_KEY_UP:            return "UP";
            case GLFW.GLFW_KEY_DOWN:          return "DOWN";
            case GLFW.GLFW_KEY_LEFT:          return "LEFT";
            case GLFW.GLFW_KEY_RIGHT:         return "RIGHT";
            case GLFW.GLFW_KEY_CAPS_LOCK:     return "CAPS";
            default: break;
        }
        String n = GLFW.glfwGetKeyName(code, 0);
        return n != null ? n.toUpperCase() : "KEY" + code;
    }

    // ------------------------------------------------------------------
    //  Налаштування модулів (права панель, ПКМ по модулю)
    // ------------------------------------------------------------------
    private static String fmt(double v) {
        return String.format(Locale.ROOT, "%.2f", v).replaceAll("\\.?0+$", "");
    }

    private static double round2(double x) {
        return Math.round(x * 100.0D) / 100.0D;
    }

    private static Setting dbl(String label, ForgeConfigSpec.DoubleValue v, double step, double min, double max) {
        return new Setting(label, () -> fmt(v.get()),
                () -> (float) ((v.get() - min) / (max - min)),
                () -> { v.set(Math.max(min, round2(v.get() - step))); v.save(); },
                () -> { v.set(Math.min(max, round2(v.get() + step))); v.save(); });
    }

    private static Setting num(String label, ForgeConfigSpec.IntValue v, int step, int min, int max) {
        return new Setting(label, () -> String.valueOf(v.get()),
                () -> (float) (v.get() - min) / (float) (max - min),
                () -> { v.set(Math.max(min, v.get() - step)); v.save(); },
                () -> { v.set(Math.min(max, v.get() + step)); v.save(); });
    }

    private static Setting flag(String label, ForgeConfigSpec.BooleanValue v) {
        Runnable flip = () -> { v.set(!v.get()); v.save(); };
        return new Setting(label, () -> v.get() ? "ON" : "OFF", null, flip, flip);
    }

    private static <E extends Enum<E>> Setting pick(String label, ForgeConfigSpec.EnumValue<E> v) {
        return new Setting(label, () -> v.get().name(), null,
                () -> { v.set(shift(v.get(), -1)); v.save(); },
                () -> { v.set(shift(v.get(), 1)); v.save(); });
    }

    private static <E extends Enum<E>> E shift(E cur, int dir) {
        E[] vals = cur.getDeclaringClass().getEnumConstants();
        return vals[(cur.ordinal() + dir + vals.length) % vals.length];
    }

    private static final int[] THEMES = {0xB359FF, 0x40E0FF, 0xFF5CA8, 0x55FF7A, 0xFFA030, 0xFFFFFF};

    private static Setting theme() {
        return new Setting("Theme color",
                () -> String.format("#%06X", Config.THEME_COLOR.get()), null,
                () -> cycleTheme(-1), () -> cycleTheme(1));
    }

    private static void cycleTheme(int dir) {
        int cur = 0;
        for (int i = 0; i < THEMES.length; i++) if (THEMES[i] == Config.THEME_COLOR.get()) cur = i;
        Config.THEME_COLOR.set(THEMES[(cur + dir + THEMES.length) % THEMES.length]);
        Config.THEME_COLOR.save();
    }

    private static List<Setting> settingsFor(Config.Module m) {
        List<Setting> l = new ArrayList<>();
        switch (m.id) {
            case "aimassist":
                l.add(dbl("Range (blocks)", Config.AIM_RANGE, 0.5D, 1.0D, 8.0D));
                l.add(dbl("FOV (deg)", Config.AIM_FOV, 10.0D, 10.0D, 360.0D));
                l.add(dbl("Speed (deg/tick)", Config.AIM_SPEED, 2.0D, 1.0D, 90.0D));
                l.add(flag("Target mobs", Config.AIM_MOBS));
                l.add(flag("Only while attacking", Config.AIM_ONLY_ATTACK));
                break;
            case "triggerbot":
                l.add(dbl("Hit range (blocks)", Config.TRIGGER_RANGE, 0.1D, 1.0D, 3.0D));
                l.add(flag("Target mobs", Config.TRIGGER_MOBS));
                break;
            case "autototem":
                l.add(num("Equip when HP <=", Config.AUTO_TOTEM_HP, 1, 1, 20));
                break;
            case "autoeat":
                l.add(num("Eat when hunger <=", Config.AUTO_EAT_LEVEL, 1, 1, 19));
                break;
            case "autofish":
                l.add(num("Reel delay (ticks)", Config.FISH_DELAY, 1, 1, 40));
                l.add(flag("Auto cast", Config.FISH_AUTOCAST));
                break;
            case "esp":
                l.add(dbl("Range (blocks)", Config.ESP_RANGE, 5.0D, 8.0D, 256.0D));
                break;
            case "streamer":
                l.add(flag("Hide in chat", Config.STREAMER_CHAT));
                l.add(flag("Hide in tab list", Config.STREAMER_TAB));
                break;
            case "autotool":
                l.add(flag("Weapons vs mobs", Config.AUTOTOOL_WEAPONS));
                l.add(flag("Switch back", Config.AUTOTOOL_BACK));
                break;
            case "coords":
                l.add(flag("Other dimension", Config.COORDS_NETHER));
                l.add(flag("Death point", Config.COORDS_DEATH));
                break;
            case "freecam":
                l.add(dbl("Speed (blocks/tick)", Config.FREECAM_SPEED, 0.1D, 0.1D, 5.0D));
                l.add(flag("Off on damage", Config.FREECAM_AUTO_OFF));
                break;
            case "fullbright":
                l.add(dbl("Brightness", Config.FB_LEVEL, 0.5D, 1.5D, 16.0D));
                break;
            case "hitparticles":
                l.add(pick("Hit style", Config.HIT_STYLE));
                l.add(pick("Crit style", Config.CRIT_STYLE));
                l.add(num("Hit count", Config.HIT_COUNT, 2, 0, 60));
                l.add(num("Crit count", Config.CRIT_COUNT, 2, 0, 80));
                l.add(dbl("Hit scale", Config.HIT_SCALE, 0.1D, 0.2D, 4.0D));
                break;
            case "chroma":
                l.add(dbl("Chroma speed", Config.CHROMA_SPEED, 0.25D, 0.1D, 10.0D));
                l.add(theme());
                break;
            case "chinahat":
                l.add(dbl("Size", Config.HAT_SIZE, 0.05D, 0.2D, 1.5D));
                l.add(dbl("Height", Config.HAT_HEIGHT, 0.05D, 0.1D, 1.2D));
                l.add(flag("Gradient", Config.HAT_GRADIENT));
                break;
            case "handswing":
                l.add(pick("Style", Config.HAND_STYLE));
                l.add(dbl("Angle", Config.HAND_ANGLE, 5.0D, 0.0D, 120.0D));
                l.add(dbl("Offset", Config.HAND_OFFSET, 0.05D, 0.0D, 0.6D));
                l.add(flag("Slow swing", Config.HAND_SLOW));
                break;
            case "targethud":
                l.add(dbl("Range (blocks)", Config.TARGET_RANGE, 4.0D, 4.0D, 128.0D));
                break;
            default:
                break;
        }
        return l;
    }
}
