package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.inventory.ContainerScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.ClickType;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Колесо вгору над слотом - перенести 1 предмет в інший інвентар (скриня <-> твій).
 * Колесо вниз - підтягнути 1 такий самий предмет з іншого інвентаря. Shift + вгору - весь стак.
 */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class ItemScroller {

    @SubscribeEvent
    public static void onScroll(GuiScreenEvent.MouseScrollEvent.Pre event) {
        if (!Config.ITEM_SCROLLER.on()) return;
        if (!(event.getGui() instanceof ContainerScreen)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null) return;

        ContainerScreen<?> gui = (ContainerScreen<?>) event.getGui();
        Container menu = gui.getMenu();
        Slot hovered = gui.getSlotUnderMouse();
        if (hovered == null) return;

        boolean hasOther = false;
        for (Slot s : menu.slots) {
            if (!(s.container instanceof PlayerInventory)) {
                hasOther = true;
                break;
            }
        }
        if (!hasOther) return; // працює лише там, де є другий інвентар (скриня, бочка...)

        double delta = event.getScrollDelta();
        if (delta == 0.0D) return;

        boolean hoveredIsPlayer = hovered.container instanceof PlayerInventory;
        ItemStack hs = hovered.getItem();
        if (hs.isEmpty()) return;

        if (delta > 0.0D) {
            if (Screen.hasShiftDown()) {
                click(mc, menu, hovered, ClickType.QUICK_MOVE);
            } else {
                Slot target = findTarget(menu, hs, !hoveredIsPlayer);
                if (target != null) moveOne(mc, menu, hovered, target);
            }
        } else {
            if (hs.getCount() >= hs.getMaxStackSize()) return;
            Slot src = findSource(menu, hs, hoveredIsPlayer, hovered);
            if (src != null) moveOne(mc, menu, src, hovered);
        }
        event.setCanceled(true);
    }

    private static boolean same(ItemStack a, ItemStack b) {
        return ItemStack.isSame(a, b) && ItemStack.tagMatches(a, b);
    }

    /** Куди покласти предмет: спершу недобиті стаки, потім порожні слоти. */
    private static Slot findTarget(Container menu, ItemStack stack, boolean playerSide) {
        for (Slot s : menu.slots) {
            if ((s.container instanceof PlayerInventory) != playerSide) continue;
            ItemStack in = s.getItem();
            if (!in.isEmpty() && same(in, stack) && in.getCount() < in.getMaxStackSize() && s.mayPlace(stack)) return s;
        }
        for (Slot s : menu.slots) {
            if ((s.container instanceof PlayerInventory) != playerSide) continue;
            if (!s.hasItem() && s.mayPlace(stack)) return s;
        }
        return null;
    }

    private static Slot findSource(Container menu, ItemStack stack, boolean hoveredIsPlayer, Slot hovered) {
        for (Slot s : menu.slots) {
            if (s == hovered || (s.container instanceof PlayerInventory) == hoveredIsPlayer) continue;
            if (s.hasItem() && same(s.getItem(), stack)) return s;
        }
        return null;
    }

    /** Підняти стак, правою кнопкою покласти 1 шт у ціль, решту повернути назад. */
    private static void moveOne(Minecraft mc, Container menu, Slot from, Slot to) {
        int id = menu.containerId;
        int a = menu.slots.indexOf(from);
        int b = menu.slots.indexOf(to);
        mc.gameMode.handleInventoryMouseClick(id, a, 0, ClickType.PICKUP, mc.player);
        mc.gameMode.handleInventoryMouseClick(id, b, 1, ClickType.PICKUP, mc.player);
        mc.gameMode.handleInventoryMouseClick(id, a, 0, ClickType.PICKUP, mc.player);
    }

    private static void click(Minecraft mc, Container menu, Slot slot, ClickType type) {
        mc.gameMode.handleInventoryMouseClick(menu.containerId, menu.slots.indexOf(slot), 0, type, mc.player);
    }
}
