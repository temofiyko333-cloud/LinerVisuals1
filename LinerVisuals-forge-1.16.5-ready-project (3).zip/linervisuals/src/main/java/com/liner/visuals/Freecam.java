package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.client.entity.player.RemoteClientPlayerEntity;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Freecam: камера відривається від гравця й літає вільно (WASD, Space - вгору, Shift - вниз, Ctrl - швидше).
 * Сам гравець стоїть на місці, не повертається й нічого не робить; серверу нічого не відправляється.
 * Реалізація: тимчасова клієнтська "камера-сутність", яку гра використовує як точку огляду.
 */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class Freecam {
    private static Entity camEntity;
    private static boolean active = false;
    private static float savedYaw, savedPitch;   // заморожений поворот реального гравця
    private static float camYaw, camPitch;
    private static float baseHealth;
    private static double cx, cy, cz;
    private static long lastNs = 0L;

    public static boolean isActive() {
        return active;
    }

    // ------------------------------------------------------------------
    //  Щокадру: старт/стоп, мишка, рух
    // ------------------------------------------------------------------
    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getInstance();

        long now = System.nanoTime();
        float dt = lastNs == 0L ? 1.0F : (now - lastNs) / 50000000.0F;
        lastNs = now;
        dt = Math.max(0.0F, Math.min(2.0F, dt));

        if (active && (mc.player == null || mc.level == null || mc.getCameraEntity() != camEntity)) {
            // світ перезавантажено / респавн / гра сама змінила камеру - тихо виходимо
            active = false;
            camEntity = null;
            Config.FREECAM.enabled.set(false);
            Config.FREECAM.enabled.save();
            return;
        }

        boolean want = Config.FREECAM.on() && mc.player != null && mc.level != null && mc.player.isAlive();
        if (want && !active) start(mc);
        else if (!want && active) stop(mc);

        if (active) update(mc, dt);
    }

    /** Перед кожним тіком гри повертаємо гравця назад, щоб на сервер не пішов повернутий погляд. */
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START || !active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) absorbMouse(mc.player);
    }

    private static void start(Minecraft mc) {
        ClientPlayerEntity p = mc.player;
        camYaw = p.getViewYRot(1.0F);
        camPitch = p.getViewXRot(1.0F);
        savedYaw = camYaw;
        savedPitch = camPitch;
        baseHealth = p.getHealth();
        cx = p.getX();
        cy = p.getY();
        cz = p.getZ();

        camEntity = new RemoteClientPlayerEntity(mc.level, p.getGameProfile());
        camEntity.moveTo(cx, cy, cz, camYaw, camPitch);
        mc.setCameraEntity(camEntity);
        active = true;
    }

    private static void stop(Minecraft mc) {
        if (mc.player != null) mc.setCameraEntity(mc.player);
        active = false;
        camEntity = null;
    }

    /** Мишка крутить реального гравця - переносимо цей поворот на камеру, а гравця повертаємо назад. */
    private static void absorbMouse(ClientPlayerEntity p) {
        float dy = p.getViewYRot(1.0F) - savedYaw;
        float dp = p.getViewXRot(1.0F) - savedPitch;
        if (dy == 0.0F && dp == 0.0F) return;
        camYaw += dy;
        camPitch = Math.max(-90.0F, Math.min(90.0F, camPitch + dp));
        p.turn(-dy / 0.15D, -dp / 0.15D);
        savedYaw = p.getViewYRot(1.0F);
        savedPitch = p.getViewXRot(1.0F);
    }

    private static void update(Minecraft mc, float dt) {
        ClientPlayerEntity p = mc.player;
        absorbMouse(p);

        // безпека: отримав шкоду - повертаємось у тіло
        if (Config.FREECAM_AUTO_OFF.get() && p.getHealth() < baseHealth - 0.01F) {
            Config.FREECAM.enabled.set(false);
            Config.FREECAM.enabled.save();
            stop(mc);
            return;
        }
        if (p.getHealth() > baseHealth) baseHealth = p.getHealth();

        if (mc.screen == null) {
            GameSettings o = mc.options;
            double speed = Config.FREECAM_SPEED.get() * (o.keySprint.isDown() ? 2.5D : 1.0D);
            double[] d = CamMath.move(camYaw, camPitch, o.keyUp.isDown(), o.keyDown.isDown(),
                    o.keyLeft.isDown(), o.keyRight.isDown(), o.keyJump.isDown(), o.keyShift.isDown(), speed, dt);
            cx += d[0];
            cy += d[1];
            cz += d[2];
        }
        camEntity.moveTo(cx, cy, cz, camYaw, camPitch);
    }

    // ------------------------------------------------------------------
    //  Поки Freecam активний - тіло гравця "заморожене"
    // ------------------------------------------------------------------
    @SubscribeEvent
    public static void onInput(InputUpdateEvent event) {
        if (!active) return;
        event.getMovementInput().forwardImpulse = 0.0F;
        event.getMovementInput().leftImpulse = 0.0F;
        event.getMovementInput().up = false;
        event.getMovementInput().down = false;
        event.getMovementInput().left = false;
        event.getMovementInput().right = false;
        event.getMovementInput().jumping = false;
        event.getMovementInput().shiftKeyDown = false;
    }

    /** Ніяких ударів/ставлення блоків "з камери". */
    @SubscribeEvent
    public static void onClick(InputEvent.ClickInputEvent event) {
        if (active) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (active) event.setCanceled(true);
    }
}
