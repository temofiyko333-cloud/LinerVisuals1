package com.liner.visuals;

/** Оцінка броні (без залежностей від Minecraft): що кращий елемент - те більше число. */
public final class ArmorLogic {
    private ArmorLogic() {
    }

    /**
     * @param defense       очки захисту елемента
     * @param toughness     міцність броні (алмаз 2, незерит 3)
     * @param prot,blast,fire,proj  рівні чарів Protection / Blast / Fire / Projectile
     * @param unbreaking    рівень Unbreaking
     * @param durabilityLeft,durabilityMax  залишок і максимум міцності (max = 0 - не ламається)
     * @param binding       прокляття прив'язки (одягти можна, зняти - ні)
     */
    public static double score(int defense, double toughness, int prot, int blast, int fire, int proj,
                               int unbreaking, int durabilityLeft, int durabilityMax, boolean binding) {
        double s = defense + toughness * 0.5D;
        s += prot * 0.9D + blast * 0.35D + fire * 0.25D + proj * 0.3D;
        s += unbreaking * 0.15D;
        if (durabilityMax > 0) {
            double f = Math.max(0.0D, Math.min(1.0D, (double) durabilityLeft / durabilityMax));
            s *= 0.6D + 0.4D * f;
            if (durabilityLeft <= 2) s *= 0.2D;   // ось-ось зламається
        }
        if (binding) s -= 100.0D;                  // ніколи не одягаємо
        return s;
    }

    /** Міняти варто, лише якщо новий помітно кращий (щоб не мінятись туди-сюди через дрібниці). */
    public static boolean worthSwap(double current, double candidate) {
        return candidate > current + 0.25D;
    }
}
