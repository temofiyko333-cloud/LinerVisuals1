package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    public static KeyBinding KEY_MENU;

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        KEY_MENU = new KeyBinding("key.linervisuals.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.linervisuals");
        ClientRegistry.registerKeyBinding(KEY_MENU);
        event.enqueueWork(Fullbright::restoreAtStartup);
        Config.ADVANTAGE_ALLOWED = () -> CombatGate.allowed(Minecraft.getInstance());
    }
}
