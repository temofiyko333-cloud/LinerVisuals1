package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Запам'ятовує, де ти загинув (зберігається в конфігу - не пропаде після виходу) і пише координати в чат. */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class DeathPoint {

    @SubscribeEvent
    public static void onGui(GuiOpenEvent event) {
        if (!(event.getGui() instanceof DeathScreen)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !Config.COORDS.on() || !Config.COORDS_DEATH.get()) return;

        String dim = mc.level.dimension() == World.NETHER ? "Nether"
                : mc.level.dimension() == World.END ? "End" : "Overworld";
        String s = CoordsMath.block(mc.player.getX()) + " " + CoordsMath.block(mc.player.getY()) + " "
                + CoordsMath.block(mc.player.getZ()) + " (" + dim + ")";
        Config.DEATH_POINT.set(s);
        Config.DEATH_POINT.save();
        mc.player.displayClientMessage(new StringTextComponent("\u00a7f[Liner] \u00a77Ти загинув тут: \u00a7f" + s), false);
    }
}
