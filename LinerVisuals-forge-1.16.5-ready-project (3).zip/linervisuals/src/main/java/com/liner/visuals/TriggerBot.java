package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.EntityRayTraceResult;

/**
 * Б'є, тільки коли приціл УЖЕ наведений на ворога (mc.hitResult). Не наведений - нічого не робить.
 * Проти щита: перемикається на сокиру, б'є і одразу повертає попередній слот (меч).
 */
public class TriggerBot {

    public static void tick(Minecraft mc) {
        if (!Config.TRIGGERBOT.on() || Freecam.isActive() || !CombatGate.allowed(mc)) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen != null) return;
        if (!p.isAlive() || p.isSpectator() || p.isUsingItem()) return;

        if (!(mc.hitResult instanceof EntityRayTraceResult)) return;
        EntityRayTraceResult er = (EntityRayTraceResult) mc.hitResult;
        Entity e = er.getEntity();

        // дистанція від очей до точки влучання, не далі за налаштовану (за замовчуванням 3 блоки)
        double dist = p.getEyePosition(1.0F).distanceTo(er.getLocation());
        boolean valid = Targeting.isValid(mc, e, Config.TRIGGER_MOBS.get());
        if (!CombatMath.shouldAttack(valid, dist, Config.TRIGGER_RANGE.get(), p.getAttackStrengthScale(0.5F))) return;

        LivingEntity target = (LivingEntity) e;

        if (Config.SHIELD_BREAK.on() && target.isBlocking()) {
            int prev = p.inventory.selected;
            if (!(p.inventory.getItem(prev).getItem() instanceof AxeItem)) {
                int axe = findAxe(p);
                if (axe >= 0) {
                    p.inventory.selected = axe;
                    attack(mc, e);
                    p.inventory.selected = prev; // одразу повертаємо меч
                    return;
                }
            }
        }
        attack(mc, e);
    }

    private static int findAxe(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) {
            if (p.inventory.getItem(i).getItem() instanceof AxeItem) return i;
        }
        return -1;
    }

    private static void attack(Minecraft mc, Entity e) {
        mc.gameMode.attack(mc.player, e);
        mc.player.swing(Hand.MAIN_HAND);
    }
}
