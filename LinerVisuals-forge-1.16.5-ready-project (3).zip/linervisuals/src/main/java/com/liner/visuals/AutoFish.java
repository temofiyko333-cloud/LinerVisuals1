package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Random;

/**
 * Авто-риболовля: ловить звук поклювки свого поплавка, підсікає й закидає знову.
 * Вудка має бути в руці (основній або лівій). Усю логіку часу веде FishLogic.
 */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class AutoFish {
    private static final FishLogic LOGIC = new FishLogic(new Random());

    @SubscribeEvent
    public static void onSound(PlaySoundEvent event) {
        if (!Config.AUTO_FISH.on()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        FishingBobberEntity bobber = mc.player.fishing;
        if (bobber == null) return;
        if (!"entity.fishing_bobber.splash".equals(event.getName())) return;

        ISound s = event.getSound();
        if (s == null) return;
        double dx = s.getX() - bobber.getX();
        double dz = s.getZ() - bobber.getZ();
        if (dx * dx + dz * dz < 9.0D) { // звук саме від нашого поплавка (до 3 блоків)
            LOGIC.onBite(true, bobber.tickCount, Config.FISH_DELAY.get());
        }
    }

    private static Hand rodHand(ClientPlayerEntity p) {
        if (p.getMainHandItem().getItem() == Items.FISHING_ROD) return Hand.MAIN_HAND;
        if (p.getOffhandItem().getItem() == Items.FISHING_ROD) return Hand.OFF_HAND;
        return null;
    }

    public static void tick(Minecraft mc) {
        ClientPlayerEntity p = mc.player;
        if (!Config.AUTO_FISH.on() || p == null || mc.gameMode == null) {
            LOGIC.reset();
            return;
        }
        if (mc.screen != null) return;

        Hand hand = rodHand(p);
        FishLogic.Action action = LOGIC.tick(hand != null, p.fishing != null,
                Config.FISH_DELAY.get(), Config.FISH_AUTOCAST.get());
        if (action == FishLogic.Action.USE && hand != null) {
            mc.gameMode.useItem(p, mc.level, hand);
            p.swing(hand);
        }
    }

    /** Короткий статус для вкладки Status. */
    public static String status() {
        Minecraft mc = Minecraft.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null) return "idle";
        if (rodHand(p) == null) return "take a rod";
        return LOGIC.describe(p.fishing != null);
    }
}
