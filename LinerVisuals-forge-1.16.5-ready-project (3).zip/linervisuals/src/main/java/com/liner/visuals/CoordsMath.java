package com.liner.visuals;

/** Координати, напрямок і перерахунок між світами (без залежностей від Minecraft). */
public final class CoordsMath {
    private CoordsMath() {
    }

    public static String block(double v) {
        return String.valueOf((int) Math.floor(v));
    }

    /** Куди дивишся: 0 = південь (+Z), 90 = захід (-X), 180 = північ (-Z), -90 = схід (+X). */
    public static String facing(float yaw) {
        int idx = ((int) Math.floor((yaw + 45.0F) / 90.0F)) & 3;
        switch (idx) {
            case 0:  return "South (+Z)";
            case 1:  return "West (-X)";
            case 2:  return "North (-Z)";
            default: return "East (+X)";
        }
    }

    /** Координати в іншому світі: оверворлд -> незер (/8), незер -> оверворлд (*8). */
    public static double[] otherDimension(double x, double z, boolean inNether) {
        return inNether ? new double[]{x * 8.0D, z * 8.0D} : new double[]{x / 8.0D, z / 8.0D};
    }
}
