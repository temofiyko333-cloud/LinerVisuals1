package com.liner.visuals;

/** Формули руху вільної камери (без залежностей від Minecraft - тестується окремо). */
public final class CamMath {
    private CamMath() {
    }

    /**
     * Зсув камери за кадр. yaw/pitch - у системі Minecraft (yaw 0 = південь, pitch вниз додатний).
     * Вперед йде туди, куди дивишся (разом із нахилом), вбік - горизонтально, вгору/вниз - вертикально.
     * Діагоналі не швидші за прямий рух.
     *
     * @return {dx, dy, dz} у блоках
     */
    public static double[] move(float yaw, float pitch, boolean fwd, boolean back, boolean left, boolean right,
                                boolean up, boolean down, double speedPerTick, float dtTicks) {
        double f = (fwd ? 1.0D : 0.0D) - (back ? 1.0D : 0.0D);
        double s = (right ? 1.0D : 0.0D) - (left ? 1.0D : 0.0D);
        double v = (up ? 1.0D : 0.0D) - (down ? 1.0D : 0.0D);

        double yr = Math.toRadians(yaw);
        double pr = Math.toRadians(pitch);
        double fx = -Math.sin(yr) * Math.cos(pr);
        double fy = -Math.sin(pr);
        double fz = Math.cos(yr) * Math.cos(pr);
        double rx = -Math.cos(yr);
        double rz = -Math.sin(yr);

        double dx = fx * f + rx * s;
        double dy = fy * f + v;
        double dz = fz * f + rz * s;

        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-9D) return new double[]{0.0D, 0.0D, 0.0D};
        double k = speedPerTick * dtTicks / Math.max(1.0D, len);
        return new double[]{dx * k, dy * k, dz * k};
    }
}
