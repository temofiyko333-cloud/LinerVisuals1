package com.liner.visuals;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.BooleanSupplier;

public class Config {
    public enum ParticleStyle { STARS, LINES, FIRE }
    public enum SwingStyle { SMOOTH, SLASH, CHOP, LOW }
    public enum Category { COMBAT, VISUAL, HUD, UTILITY }

    /** Модуль: вмикається/вимикається і має власний бінд клавіші (GLFW-код, -1 = нема). */
    public static class Module {
        public final String id;
        public final String name;
        public final String desc;
        public final Category cat;
        public final boolean hidden;
        public final ForgeConfigSpec.BooleanValue enabled;
        public final ForgeConfigSpec.IntValue key;

        Module(String id, String name, String desc, Category cat, boolean hidden,
               ForgeConfigSpec.BooleanValue enabled, ForgeConfigSpec.IntValue key) {
            this.id = id;
            this.name = name;
            this.desc = desc;
            this.cat = cat;
            this.hidden = hidden;
            this.enabled = enabled;
            this.key = key;
        }

        public boolean safe() {
            return SAFE_IDS.contains(id);
        }

        /** Модуль з перевагою заблоковано на поточному сервері (безпечний режим). */
        public boolean lockedHere() {
            return !safe() && this != MASTER && !ADVANTAGE_ALLOWED.getAsBoolean();
        }

        /** Увімкнений, Master увімкнений і модуль не заблоковано безпечним режимом сервера. */
        public boolean on() {
            if (this == MASTER) return enabled.get();
            if (!MASTER.enabled.get() || !enabled.get()) return false;
            return !lockedHere();
        }

        public void toggle() {
            enabled.set(!enabled.get());
            enabled.save();
        }
    }

    /**
     * Безпечні модулі: чисто косметика та інформація про себе - працюють на будь-якому сервері.
     * Решта (чити/автоматизація/перевага: aim assist, triggerbot, ESP, fullbright, freecam, auto-модулі тощо)
     * працюють тільки в одиночній грі та на серверах зі списку Servers (див. CombatGate).
     */
    public static final Set<String> SAFE_IDS = new HashSet<>(Arrays.asList(
            "hitparticles", "damagetext", "jumprings", "pearltrail", "chinahat", "blockoverlay", "handswing", "chroma",
            "watermark", "fps", "ping", "effectshud", "armorhud", "targethud", "ringcrosshair", "modulelist",
            "coords", "streamer", "commandbinds", "teamprotect"));

    /** Встановлюється клієнтом (ClientSetup): true = модулі з перевагою дозволені на цьому сервері. */
    public static volatile BooleanSupplier ADVANTAGE_ALLOWED = () -> true;

    public static final List<Module> MODULES = new ArrayList<>();
    public static final ForgeConfigSpec SPEC;

    // ===== Модулі =====
    public static final Module MASTER;
    // Combat
    public static final Module AIM_ASSIST, TRIGGERBOT, SHIELD_BREAK, AUTO_TOTEM, AUTO_ARMOR, TEAM_PROTECT;
    // Visual
    public static final Module ESP, TRACERS, NAMETAGS, PULSE, HIT_PARTICLES, DAMAGE_TEXT, JUMP_RINGS,
            PEARL_PATH, PEARL_TRAIL, CHINA_HAT, BLOCK_OVERLAY, HAND_SWING, CHROMA, FULLBRIGHT, FREECAM;
    // HUD
    public static final Module WATERMARK, FPS, PING, EFFECTS_HUD, ARMOR_HUD, TARGET_HUD,
            RING_CROSSHAIR, AIM_HINT, MODULE_LIST, COORDS;
    // Utility
    public static final Module AUTO_EAT, AUTO_FISH, ITEM_SCROLLER, STREAMER, COMMAND_BINDS, AUTO_TOOL;

    // ===== Налаштування =====
    public static final ForgeConfigSpec.BooleanValue COMBAT_LOCK, FISH_AUTOCAST;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> COMBAT_SERVERS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> TEAM;

    public static final ForgeConfigSpec.DoubleValue AIM_RANGE, AIM_FOV, AIM_SPEED, TRIGGER_RANGE;
    public static final ForgeConfigSpec.BooleanValue AIM_MOBS, AIM_ONLY_ATTACK, TRIGGER_MOBS;
    public static final ForgeConfigSpec.IntValue AUTO_TOTEM_HP, AUTO_EAT_LEVEL, FISH_DELAY;

    public static final ForgeConfigSpec.EnumValue<ParticleStyle> HIT_STYLE, CRIT_STYLE;
    public static final ForgeConfigSpec.IntValue HIT_COUNT, CRIT_COUNT;
    public static final ForgeConfigSpec.DoubleValue HIT_SCALE, CRIT_SCALE, HIT_ALPHA, CRIT_ALPHA;

    public static final ForgeConfigSpec.DoubleValue FB_LEVEL, FB_SAVED, FREECAM_SPEED;
    public static final ForgeConfigSpec.BooleanValue FREECAM_AUTO_OFF;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> CMD_BINDS;
    public static final ForgeConfigSpec.ConfigValue<String> STREAMER_ALIAS, DEATH_POINT;
    public static final ForgeConfigSpec.BooleanValue AUTOTOOL_WEAPONS, AUTOTOOL_BACK, COORDS_NETHER, COORDS_DEATH;
    public static final ForgeConfigSpec.BooleanValue STREAMER_CHAT, STREAMER_TAB;
    public static final ForgeConfigSpec.IntValue THEME_COLOR;
    public static final ForgeConfigSpec.DoubleValue CHROMA_SPEED;

    public static final ForgeConfigSpec.DoubleValue ESP_RANGE, TARGET_RANGE;

    public static final ForgeConfigSpec.DoubleValue HAT_SIZE, HAT_HEIGHT;
    public static final ForgeConfigSpec.BooleanValue HAT_GRADIENT;

    public static final ForgeConfigSpec.EnumValue<SwingStyle> HAND_STYLE;
    public static final ForgeConfigSpec.DoubleValue HAND_ANGLE, HAND_OFFSET;
    public static final ForgeConfigSpec.BooleanValue HAND_SLOW;

    private static Module mod(ForgeConfigSpec.Builder b, String id, String name, Category cat, String desc,
                              boolean def, int defKey, boolean hidden) {
        b.push(id);
        ForgeConfigSpec.BooleanValue en = b.define("enabled", def);
        ForgeConfigSpec.IntValue key = b.defineInRange("key", defKey, -1, 400);
        b.pop();
        Module m = new Module(id, name, desc, cat, hidden, en, key);
        MODULES.add(m);
        return m;
    }

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("modules");
        MASTER = mod(b, "master", "Master", Category.UTILITY, "Головний перемикач", true, 295, true); // F6

        // ---- Combat ----
        AIM_ASSIST   = mod(b, "aimassist", "Aim Assist", Category.COMBAT,
                "Плавно наводить приціл на найближчого ворога (команда/друзі ігноруються)", false, 75, false); // K
        TRIGGERBOT   = mod(b, "triggerbot", "Triggerbot", Category.COMBAT,
                "Б'є сам, але ТІЛЬКИ коли приціл уже наведений на ворога", false, -1, false);
        SHIELD_BREAK = mod(b, "shieldbreak", "Shield Breaker", Category.COMBAT,
                "Триггербот перемикається на сокиру проти щита, б'є і повертає меч", true, -1, false);
        AUTO_TOTEM   = mod(b, "autototem", "Auto Totem", Category.COMBAT,
                "Тримає тотем безсмертя в лівій руці", false, -1, false);
        AUTO_ARMOR   = mod(b, "autoarmor", "Auto Armor", Category.COMBAT,
                "Автоматично одягає найкращу броню з інвентаря", false, -1, false);
        TEAM_PROTECT = mod(b, "teamprotect", "Team Protect", Category.COMBAT,
                "Не дає вдарити гравців зі списку Team", true, -1, false);

        // ---- Visual ----
        ESP           = mod(b, "esp", "Player ESP", Category.VISUAL, "Підсвітка гравців поруч (крізь стіни)", true, 296, false); // F7
        TRACERS       = mod(b, "tracers", "Tracers", Category.VISUAL, "Лінії до гравців", false, 297, false);          // F8
        NAMETAGS      = mod(b, "nametags", "Nametags", Category.VISUAL, "Нік + HP + дистанція", true, 298, false);     // F9
        PULSE         = mod(b, "pulse", "Pulse", Category.VISUAL, "Пульсація боксу та хвилі під ногами", true, 299, false); // F10
        HIT_PARTICLES = mod(b, "hitparticles", "Hit Particles", Category.VISUAL, "Кастомні партикли при ударі", true, -1, false);
        DAMAGE_TEXT   = mod(b, "damagetext", "Damage Text", Category.VISUAL, "3D цифри шкоди над ворогом", true, -1, false);
        JUMP_RINGS    = mod(b, "jumprings", "Jump Rings", Category.VISUAL, "Кола від стрибків", true, -1, false);
        PEARL_PATH    = mod(b, "pearlpath", "Pearl Path", Category.VISUAL, "Траєкторія перла / стріли / зілля", true, -1, false);
        PEARL_TRAIL   = mod(b, "pearltrail", "Pearl Trail", Category.VISUAL, "Слід за перлом", true, -1, false);
        CHINA_HAT     = mod(b, "chinahat", "China Hat", Category.VISUAL, "Неоновий капелюх (від 3-ї особи)", true, -1, false);
        BLOCK_OVERLAY = mod(b, "blockoverlay", "Block Overlay", Category.VISUAL, "Неонове підсвічування блоку", true, -1, false);
        HAND_SWING    = mod(b, "handswing", "Hand Swing", Category.VISUAL, "Кастомний змах руки", true, -1, false);
        CHROMA        = mod(b, "chroma", "Chroma / RGB", Category.VISUAL, "Переливчасті кольори скрізь", true, -1, false);
        FREECAM       = mod(b, "freecam", "Freecam", Category.VISUAL,
                "Вільна камера: літай по світу, а персонаж стоїть (WASD, Space/Shift, Ctrl = швидше)", false, -1, false);
        FULLBRIGHT    = mod(b, "fullbright", "Fullbright", Category.VISUAL, "Повна яскравість: у печерах і вночі видно все", false, -1, false);

        // ---- HUD ----
        WATERMARK      = mod(b, "watermark", "Watermark", Category.HUD, "Liner Visuals у лівому верхньому куті", true, -1, false);
        FPS            = mod(b, "fps", "FPS Counter", Category.HUD, "Показувати FPS", true, -1, false);
        PING           = mod(b, "ping", "Ping Counter", Category.HUD, "Показувати пінг", true, -1, false);
        EFFECTS_HUD    = mod(b, "effectshud", "Potion Effects", Category.HUD, "Ефекти зілля й таймер справа посередині", true, -1, false);
        ARMOR_HUD      = mod(b, "armorhud", "Armor HUD", Category.HUD, "Скільки міцності лишилось у броні та зброї", true, -1, false);
        TARGET_HUD     = mod(b, "targethud", "Target HUD", Category.HUD, "HP, броня й дистанція цілі", true, -1, false);
        RING_CROSSHAIR = mod(b, "ringcrosshair", "Ring Crosshair", Category.HUD, "Динамічний приціл-кільце", true, -1, false);
        AIM_HINT       = mod(b, "aimhint", "Aim Hint", Category.HUD, "Стрілка в бік найближчого гравця", false, -1, false);
        COORDS         = mod(b, "coords", "Coords & Death Point", Category.HUD,
                "Координати, напрямок, незер-координати та місце останньої смерті", true, -1, false);
        MODULE_LIST    = mod(b, "modulelist", "Module List", Category.HUD, "Список увімкнених модулів справа зверху", false, -1, false);

        // ---- Utility ----
        AUTO_EAT      = mod(b, "autoeat", "Auto Eat", Category.UTILITY, "Їсть з хотбару, коли голод нижче ліміту", false, -1, false);
        AUTO_FISH     = mod(b, "autofish", "Auto Fish", Category.UTILITY, "Сам підсікає і закидає вудку", false, -1, false);
        AUTO_TOOL     = mod(b, "autotool", "Auto Tool", Category.UTILITY,
                "Сам бере найкращий інструмент для блока (і зброю для істот)", true, -1, false);
        COMMAND_BINDS = mod(b, "commandbinds", "Command Binds", Category.UTILITY,
                "Кнопка = команда в чат (напр. /home), виконується одразу", true, -1, false);
        STREAMER      = mod(b, "streamer", "Streamer Mode", Category.UTILITY,
                "Ховає твій нік лише для тебе: чат і таб-лист (інші бачать справжній)", false, -1, false);
        ITEM_SCROLLER = mod(b, "itemscroller", "Item Scroller", Category.UTILITY, "Перенос предметів колесом миші (Shift = весь стак)", true, -1, false);
        b.pop();

        b.push("combat");
        COMBAT_LOCK = b.comment("Бойові модулі (aim assist, triggerbot, auto totem, shield breaker) працюють лише в одиночній грі та на серверах зі списку нижче")
                .define("restrictToAllowedServers", true);
        COMBAT_SERVERS = b.comment("Сервери, де бойові модулі дозволені (анархії тощо)")
                .defineList("allowedServers", Arrays.asList("2b2t.org", "9b9t.com", "constantiam.net"), o -> o instanceof String);
        TEAM = b.comment("Друзі: aim assist і triggerbot їх ігнорують, Team Protect не дає їх вдарити")
                .defineList("team", new ArrayList<String>(), o -> o instanceof String);
        AIM_RANGE       = b.defineInRange("aimRange", 4.5D, 1.0D, 8.0D);
        AIM_FOV         = b.defineInRange("aimFov", 120.0D, 10.0D, 360.0D);
        AIM_SPEED       = b.comment("Макс. швидкість повороту, градусів за тік").defineInRange("aimSpeed", 18.0D, 1.0D, 90.0D);
        AIM_MOBS        = b.define("aimMobs", false);
        AIM_ONLY_ATTACK = b.comment("Наводитись тільки поки затиснута кнопка атаки").define("aimOnlyWhileAttacking", false);
        TRIGGER_MOBS    = b.define("triggerMobs", false);
        TRIGGER_RANGE   = b.comment("Дальність удару triggerbot, блоків (3.0 = ванільна дальність; більше не можна)")
                .defineInRange("triggerRange", 3.0D, 1.0D, 3.0D);
        AUTO_TOTEM_HP   = b.comment("Діставати тотем, коли HP <= значення (20 = завжди)").defineInRange("autoTotemHealth", 20, 1, 20);
        b.pop();

        b.push("utility");
        AUTO_EAT_LEVEL = b.comment("Їсти, коли голод <= значення").defineInRange("hungerLevel", 14, 1, 19);
        FISH_DELAY     = b.comment("Затримка підсічки після поклювки (тіків)").defineInRange("fishDelay", 6, 1, 40);
        FISH_AUTOCAST  = b.comment("Закидати вудку самому, якщо вона в руці, а ліски нема").define("fishAutoCast", false);
        b.pop();

        b.push("hit_particles");
        HIT_STYLE  = b.defineEnum("normalStyle", ParticleStyle.STARS);
        CRIT_STYLE = b.defineEnum("critStyle", ParticleStyle.FIRE);
        HIT_COUNT  = b.defineInRange("normalCount", 8, 0, 60);
        CRIT_COUNT = b.defineInRange("critCount", 18, 0, 80);
        HIT_SCALE  = b.defineInRange("normalScale", 1.0D, 0.2D, 4.0D);
        CRIT_SCALE = b.defineInRange("critScale", 1.4D, 0.2D, 4.0D);
        HIT_ALPHA  = b.defineInRange("normalAlpha", 0.9D, 0.1D, 1.0D);
        CRIT_ALPHA = b.defineInRange("critAlpha", 1.0D, 0.1D, 1.0D);
        b.pop();

        b.push("commands");
        CMD_BINDS = b.comment("Службове: бінди команд у форматі \"код_клавіші|команда\". Краще редагувати через меню.")
                .defineList("binds", new ArrayList<String>(), o -> o instanceof String);
        b.pop();

        b.push("autotool");
        AUTOTOOL_WEAPONS = b.comment("Бити істот найкращою зброєю з хотбару").define("weapons", true);
        AUTOTOOL_BACK    = b.comment("Повертати попередній слот, коли відпустив кнопку").define("switchBack", true);
        b.pop();

        b.push("coords");
        COORDS_NETHER = b.comment("Показувати координати в іншому світі (незер /8, оверворлд *8)").define("otherDimension", true);
        COORDS_DEATH  = b.comment("Запам'ятовувати місце смерті й писати його в чат").define("deathPoint", true);
        DEATH_POINT   = b.comment("Службове: координати останньої смерті").define("lastDeath", "");
        b.pop();

        b.push("streamer");
        STREAMER_ALIAS = b.comment("Чим замінювати твій нік (бачиш тільки ти)").define("alias", "Player");
        STREAMER_CHAT  = b.define("hideInChat", true);
        STREAMER_TAB   = b.define("hideInTabList", true);
        b.pop();

        b.push("freecam");
        FREECAM_SPEED    = b.comment("Швидкість камери, блоків за тік (0.6 ~ 12 блоків/с)").defineInRange("speed", 0.6D, 0.1D, 5.0D);
        FREECAM_AUTO_OFF = b.comment("Повертатись у тіло, якщо гравець отримав шкоду").define("autoOffOnDamage", true);
        b.pop();

        b.push("fullbright");
        FB_LEVEL = b.comment("Рівень яскравості (gamma)").defineInRange("level", 12.0D, 1.5D, 16.0D);
        FB_SAVED = b.comment("Службове: збережена яскравість до вмикання (-1 = нема). Не чіпати.")
                .defineInRange("savedGamma", -1.0D, -1.0D, 16.0D);
        b.pop();

        b.push("theme");
        THEME_COLOR  = b.comment("Колір теми RGB (десяткове число; 11754751 = 0xB359FF)")
                .defineInRange("themeColor", 0xB359FF, 0, 0xFFFFFF);
        CHROMA_SPEED = b.defineInRange("chromaSpeed", 1.0D, 0.1D, 10.0D);
        b.pop();

        b.push("ranges");
        ESP_RANGE    = b.comment("Радіус підсвітки гравців (блоків, по всіх осях)").defineInRange("espRange", 30.0D, 8.0D, 256.0D);
        TARGET_RANGE = b.defineInRange("targetRange", 32.0D, 4.0D, 128.0D);
        b.pop();

        b.push("china_hat");
        HAT_SIZE     = b.defineInRange("size", 0.55D, 0.2D, 1.5D);
        HAT_HEIGHT   = b.defineInRange("height", 0.45D, 0.1D, 1.2D);
        HAT_GRADIENT = b.define("gradient", true);
        b.pop();

        b.push("hand");
        HAND_STYLE  = b.defineEnum("style", SwingStyle.SMOOTH);
        HAND_ANGLE  = b.defineInRange("angle", 35.0D, 0.0D, 120.0D);
        HAND_OFFSET = b.defineInRange("offset", 0.15D, 0.0D, 0.6D);
        HAND_SLOW   = b.define("slowSwing", false);
        b.pop();

        SPEC = b.build();
    }
}
