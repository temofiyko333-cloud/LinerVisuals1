package com.liner.visuals;

import net.minecraft.block.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.DrawHighlightEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.opengl.GL11;

import java.util.List;

/** Неонове підсвічування блоку замість стандартної чорної сітки. */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class BlockOverlay {

    @SubscribeEvent
    public static void onHighlight(DrawHighlightEvent.HighlightBlock event) {
        if (!Config.BLOCK_OVERLAY.on()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        BlockRayTraceResult hit = (BlockRayTraceResult) event.getTarget();
        BlockPos pos = hit.getBlockPos();
        BlockState state = mc.level.getBlockState(pos);
        VoxelShape shape = state.getShape(mc.level, pos, ISelectionContext.of(mc.player));
        List<AxisAlignedBB> boxes = shape.toAabbs();
        if (boxes.isEmpty()) return;

        event.setCanceled(true); // прибираємо стандартну чорну рамку

        Vector3d cam = event.getInfo().getPosition();
        Matrix4f m = event.getMatrix().last().pose();
        double ox = pos.getX() - cam.x;
        double oy = pos.getY() - cam.y;
        double oz = pos.getZ() - cam.z;

        // об'єднаний бокс для заливки грані, на яку дивимось
        double ux1 = Double.MAX_VALUE, uy1 = Double.MAX_VALUE, uz1 = Double.MAX_VALUE;
        double ux2 = -Double.MAX_VALUE, uy2 = -Double.MAX_VALUE, uz2 = -Double.MAX_VALUE;
        for (AxisAlignedBB bb : boxes) {
            ux1 = Math.min(ux1, bb.minX);
            uy1 = Math.min(uy1, bb.minY);
            uz1 = Math.min(uz1, bb.minZ);
            ux2 = Math.max(ux2, bb.maxX);
            uy2 = Math.max(uy2, bb.maxY);
            uz2 = Math.max(uz2, bb.maxZ);
        }
        final double e = 0.002D;
        float x1 = (float) (ux1 + ox - e), y1 = (float) (uy1 + oy - e), z1 = (float) (uz1 + oz - e);
        float x2 = (float) (ux2 + ox + e), y2 = (float) (uy2 + oy + e), z2 = (float) (uz2 + oz + e);

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        Draw.begin(true, 2.5F);
        try {
            // заливка грані
            float[] fill = Chroma.get(0.0F);
            buf.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            switch (hit.getDirection()) {
                case UP:    Draw.quad(buf, m, fill, 0.22F, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1); break;
                case DOWN:  Draw.quad(buf, m, fill, 0.22F, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2); break;
                case NORTH: Draw.quad(buf, m, fill, 0.22F, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1); break;
                case SOUTH: Draw.quad(buf, m, fill, 0.22F, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2); break;
                case WEST:  Draw.quad(buf, m, fill, 0.22F, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1); break;
                default:    Draw.quad(buf, m, fill, 0.22F, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2); break;
            }
            tess.end();

            // неонові лінії
            buf.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
            int i = 0;
            for (AxisAlignedBB bb : boxes) {
                AxisAlignedBB moved = bb.move(ox, oy, oz).inflate(e);
                Draw.boxLines(buf, m, moved, Chroma.get(i++ * 0.08F), 1.0F);
            }
            tess.end();
        } finally {
            Draw.end();
        }
    }
}
