package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.inventory.container.ClickType;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;

/**
 * Автоматично одягає найкращу броню з інвентаря: захист, міцність (toughness), чарування (Protection та ін.),
 * враховує знос; не чіпає елітри та броню з прокляттям прив'язки.
 */
public class AutoArmor {
    private static int cooldown = 0;
    private static final EquipmentSlotType[] TYPES = {
            EquipmentSlotType.HEAD, EquipmentSlotType.CHEST, EquipmentSlotType.LEGS, EquipmentSlotType.FEET};

    public static void tick(Minecraft mc) {
        if (cooldown > 0) cooldown--;
        if (!Config.AUTO_ARMOR.on()) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.gameMode == null || cooldown > 0 || mc.screen != null) return;
        if (p.isCreative() || p.isSpectator() || !p.isAlive()) return;

        int id = p.inventoryMenu.containerId;
        for (EquipmentSlotType type : TYPES) {
            int armorIdx = type.getIndex();            // 0=черевики ... 3=шолом
            ItemStack cur = p.inventory.armor.get(armorIdx);
            double curScore;
            if (cur.isEmpty()) curScore = -1.0D;
            else if (!(cur.getItem() instanceof ArmorItem)) continue;      // елітри тощо не чіпаємо
            else if (level(Enchantments.BINDING_CURSE, cur) > 0) continue; // зняти все одно не вийде
            else curScore = score(cur);

            int bestInv = -1;
            double best = curScore;
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.inventory.getItem(i);
                if (!(s.getItem() instanceof ArmorItem)) continue;
                if (((ArmorItem) s.getItem()).getSlot() != type) continue;
                if (level(Enchantments.BINDING_CURSE, s) > 0) continue;
                double sc = score(s);
                if (ArmorLogic.worthSwap(best, sc) || (bestInv < 0 && ArmorLogic.worthSwap(curScore, sc))) {
                    best = sc;
                    bestInv = i;
                }
            }
            if (bestInv < 0) continue;

            int invSlot = bestInv < 9 ? 36 + bestInv : bestInv;
            if (cur.isEmpty()) {
                mc.gameMode.handleInventoryMouseClick(id, invSlot, 0, ClickType.QUICK_MOVE, p);
            } else {
                int armorSlot = 8 - armorIdx;          // у контейнері: 5=шолом ... 8=черевики
                mc.gameMode.handleInventoryMouseClick(id, invSlot, 0, ClickType.PICKUP, p);
                mc.gameMode.handleInventoryMouseClick(id, armorSlot, 0, ClickType.PICKUP, p);
                mc.gameMode.handleInventoryMouseClick(id, invSlot, 0, ClickType.PICKUP, p);
            }
            cooldown = 6;
            return;
        }
    }

    private static int level(Enchantment e, ItemStack s) {
        return EnchantmentHelper.getItemEnchantmentLevel(e, s);
    }

    private static double score(ItemStack s) {
        ArmorItem a = (ArmorItem) s.getItem();
        int max = s.isDamageableItem() ? s.getMaxDamage() : 0;
        int left = s.isDamageableItem() ? max - s.getDamageValue() : 0;
        return ArmorLogic.score(a.getDefense(), a.getToughness(),
                level(Enchantments.ALL_DAMAGE_PROTECTION, s), level(Enchantments.BLAST_PROTECTION, s),
                level(Enchantments.FIRE_PROTECTION, s), level(Enchantments.PROJECTILE_PROTECTION, s),
                level(Enchantments.UNBREAKING, s), left, max, level(Enchantments.BINDING_CURSE, s) > 0);
    }
}
