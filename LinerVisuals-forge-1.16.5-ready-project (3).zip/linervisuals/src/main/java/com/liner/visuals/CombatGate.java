package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;

/**
 * Бойові модулі працюють в одиночній грі та на серверах зі списку allowedServers
 * (анархії, де хаки дозволені). На інших серверах вони блокуються, щоб ти випадково не отримав бан.
 */
public class CombatGate {

    private static long lastNs = 0L;
    private static boolean cached = true;

    /** Результат кешується на 250 мс: Module.on() викликається сотні разів за кадр. */
    public static boolean allowed(Minecraft mc) {
        long now = System.nanoTime();
        if (lastNs != 0L && now - lastNs < 250000000L) return cached;
        lastNs = now;
        cached = compute(mc);
        return cached;
    }

    private static boolean compute(Minecraft mc) {
        if (!Config.COMBAT_LOCK.get()) return true;
        if (mc.getSingleplayerServer() != null) return true;

        ServerData sd = mc.getCurrentServer();
        if (sd == null || sd.ip == null) return false;

        String ip = sd.ip.toLowerCase();
        int colon = ip.indexOf(':');
        if (colon > 0) ip = ip.substring(0, colon);

        for (String s : Config.COMBAT_SERVERS.get()) {
            String allowed = s.toLowerCase();
            if (ip.equals(allowed) || ip.endsWith("." + allowed)) return true;
        }
        return false;
    }
}
