package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.network.play.NetworkPlayerInfo;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.text.IFormattableTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Optional;
import java.util.regex.Pattern;

/**
 * Режим стрімера: ховає ТВІЙ нік лише на твоєму екрані.
 * Інші гравці й сервер бачать справжній нік - змінюється тільки відображення в твоєму клієнті.
 */
@Mod.EventBusSubscriber(modid = LinerVisuals.MODID, value = Dist.CLIENT)
public class Streamer {
    private static boolean tabHidden = false;

    private static String alias() {
        String a = Config.STREAMER_ALIAS.get();
        return a == null || a.trim().isEmpty() ? "Player" : a;
    }

    /** Чат, повідомлення про смерть/вхід, actionbar: нік -> аліас зі збереженням кольорів і кліків. */
    @SubscribeEvent
    public static void onChat(ClientChatReceivedEvent event) {
        if (!Config.STREAMER.on() || !Config.STREAMER_CHAT.get()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || event.getMessage() == null) return;

        String real = mc.player.getGameProfile().getName();
        if (real == null || real.isEmpty()) return;
        final Pattern p = NickMask.pattern(real);

        ITextComponent in = event.getMessage();
        if (!p.matcher(in.getString()).find()) return;

        final String alias = alias();
        final IFormattableTextComponent out = new StringTextComponent("");
        in.visit((style, str) -> {
            out.append(new StringTextComponent(NickMask.mask(str, p, alias)).setStyle(style));
            return Optional.empty();
        }, Style.EMPTY);
        event.setMessage(out);
    }

    /** Таб-лист: підміняємо відображуване ім'я лише у власного гравця. Викликається щотіка. */
    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.getConnection() == null) return;
        NetworkPlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        if (info == null) return;

        boolean want = Config.STREAMER.on() && Config.STREAMER_TAB.get();
        if (want) {
            info.setTabListDisplayName(ScorePlayerTeam.formatNameForTeam(info.getTeam(), new StringTextComponent(alias())));
            tabHidden = true;
        } else if (tabHidden) {
            info.setTabListDisplayName(null);
            tabHidden = false;
        }
    }
}
