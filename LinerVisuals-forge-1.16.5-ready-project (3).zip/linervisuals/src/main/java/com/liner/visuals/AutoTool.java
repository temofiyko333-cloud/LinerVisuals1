package com.liner.visuals;

import net.minecraft.block.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.CreatureAttribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.util.math.RayTraceResult;

/**
 * Auto Tool: коли починаєш ламати блок - у руку сам береться найкращий інструмент з хотбару
 * (швидкість + Efficiency + чи випаде дроп). Б'єш істоту - береться найкраща зброя.
 * Коли відпустив кнопку - повертає попередній слот. Викликається на початку тіка, ДО обробки кліку,
 * тому прогрес ламання не скидається.
 */
public class AutoTool {
    private static int prevSlot = -1;

    public static void tick(Minecraft mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.level == null) return;
        if (!Config.AUTO_TOOL.on()) {
            restore(mc);
            return;
        }

        boolean attacking = mc.screen == null && mc.options.keyAttack.isDown()
                && !p.isUsingItem() && !p.isCreative() && !p.isSpectator();
        if (!attacking) {
            restore(mc);
            return;
        }

        RayTraceResult hr = mc.hitResult;
        if (hr == null) return;
        if (hr.getType() == RayTraceResult.Type.BLOCK && hr instanceof BlockRayTraceResult) {
            BlockState state = mc.level.getBlockState(((BlockRayTraceResult) hr).getBlockPos());
            switchTo(p, bestForBlock(p, state));
        } else if (Config.AUTOTOOL_WEAPONS.get() && hr.getType() == RayTraceResult.Type.ENTITY
                && hr instanceof EntityRayTraceResult) {
            switchTo(p, bestWeapon(p));
        }
    }

    private static void switchTo(ClientPlayerEntity p, int slot) {
        if (slot < 0 || slot == p.inventory.selected) return;
        if (prevSlot < 0) prevSlot = p.inventory.selected;
        p.inventory.selected = slot;
    }

    private static void restore(Minecraft mc) {
        if (prevSlot >= 0 && mc.player != null && Config.AUTOTOOL_BACK.get()) {
            mc.player.inventory.selected = prevSlot;
        }
        prevSlot = -1;
    }

    private static int durabilityLeft(ItemStack s) {
        return s.isDamageableItem() ? s.getMaxDamage() - s.getDamageValue() : ToolLogic.UNBREAKABLE;
    }

    private static int bestForBlock(ClientPlayerEntity p, BlockState state) {
        double[] scores = new double[9];
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.inventory.getItem(i);
            float base = s.isEmpty() ? 1.0F : s.getDestroySpeed(state);
            boolean correct = !state.requiresCorrectToolForDrops() || (!s.isEmpty() && s.isCorrectToolForDrops(state));
            int eff = s.isEmpty() ? 0 : EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_EFFICIENCY, s);
            scores[i] = ToolLogic.blockScore(base, eff, correct, s.isEmpty() ? ToolLogic.UNBREAKABLE : durabilityLeft(s));
        }
        return ToolLogic.pickBest(scores, p.inventory.selected, 0.5D);
    }

    private static int bestWeapon(ClientPlayerEntity p) {
        double[] scores = new double[9];
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.inventory.getItem(i);
            double dmg = 0.0D, spd = 0.0D;
            if (!s.isEmpty()) {
                for (AttributeModifier m : s.getAttributeModifiers(EquipmentSlotType.MAINHAND).get(Attributes.ATTACK_DAMAGE)) {
                    dmg += m.getAmount();
                }
                for (AttributeModifier m : s.getAttributeModifiers(EquipmentSlotType.MAINHAND).get(Attributes.ATTACK_SPEED)) {
                    spd += m.getAmount();
                }
            }
            double sharp = s.isEmpty() ? 0.0D : EnchantmentHelper.getDamageBonus(s, CreatureAttribute.UNDEFINED);
            scores[i] = ToolLogic.weaponScore(dmg, sharp, spd, s.isEmpty() ? ToolLogic.UNBREAKABLE : durabilityLeft(s));
        }
        return ToolLogic.pickBest(scores, p.inventory.selected, 0.5D);
    }
}
