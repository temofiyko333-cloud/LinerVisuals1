package com.liner.visuals;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.IRenderTypeBuffer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3f;

/** Спільні хелпери для малювання геометрії (камера-відносні координати). */
public class Draw {

    public static void begin(boolean depthTest, float lineWidth) {
        RenderSystem.disableTexture();
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);
        if (depthTest) RenderSystem.enableDepthTest();
        else RenderSystem.disableDepthTest();
        RenderSystem.lineWidth(lineWidth);
    }

    public static void end() {
        RenderSystem.lineWidth(1.0F);
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.enableTexture();
        RenderSystem.enableDepthTest();
    }

    public static int healthColor(float frac) {
        frac = Math.max(0.0F, Math.min(1.0F, frac));
        int r = (int) (Math.min(1.0F, 2.0F * (1.0F - frac)) * 255);
        int g = (int) (Math.min(1.0F, 2.0F * frac) * 255);
        return 0xFF000000 | (r << 16) | (g << 8);
    }

    public static void vert(BufferBuilder b, Matrix4f m, float x, float y, float z, float[] c, float a) {
        b.vertex(m, x, y, z).color(c[0], c[1], c[2], a).endVertex();
    }

    private static void vertP(BufferBuilder b, Matrix4f m, float[] p, float[] c, float a) {
        vert(b, m, p[0], p[1], p[2], c, a);
    }

    public static void line(BufferBuilder b, Matrix4f m, float x1, float y1, float z1,
                            float x2, float y2, float z2, float[] c, float a) {
        vert(b, m, x1, y1, z1, c, a);
        vert(b, m, x2, y2, z2, c, a);
    }

    public static void boxLines(BufferBuilder b, Matrix4f m, AxisAlignedBB bb, float[] c, float a) {
        float x1 = (float) bb.minX, y1 = (float) bb.minY, z1 = (float) bb.minZ;
        float x2 = (float) bb.maxX, y2 = (float) bb.maxY, z2 = (float) bb.maxZ;
        line(b, m, x1, y1, z1, x2, y1, z1, c, a);
        line(b, m, x2, y1, z1, x2, y1, z2, c, a);
        line(b, m, x2, y1, z2, x1, y1, z2, c, a);
        line(b, m, x1, y1, z2, x1, y1, z1, c, a);
        line(b, m, x1, y2, z1, x2, y2, z1, c, a);
        line(b, m, x2, y2, z1, x2, y2, z2, c, a);
        line(b, m, x2, y2, z2, x1, y2, z2, c, a);
        line(b, m, x1, y2, z2, x1, y2, z1, c, a);
        line(b, m, x1, y1, z1, x1, y2, z1, c, a);
        line(b, m, x2, y1, z1, x2, y2, z1, c, a);
        line(b, m, x2, y1, z2, x2, y2, z2, c, a);
        line(b, m, x1, y1, z2, x1, y2, z2, c, a);
    }

    public static void quad(BufferBuilder b, Matrix4f m, float[] c, float a, float... p) {
        for (int i = 0; i < 12; i += 3) {
            vert(b, m, p[i], p[i + 1], p[i + 2], c, a);
        }
    }

    public static void fillBox(BufferBuilder b, Matrix4f m, AxisAlignedBB bb, float[] c, float a) {
        float x1 = (float) bb.minX, y1 = (float) bb.minY, z1 = (float) bb.minZ;
        float x2 = (float) bb.maxX, y2 = (float) bb.maxY, z2 = (float) bb.maxZ;
        quad(b, m, c, a, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2);
        quad(b, m, c, a, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1);
        quad(b, m, c, a, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1);
        quad(b, m, c, a, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2);
        quad(b, m, c, a, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1);
        quad(b, m, c, a, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2);
    }

    /** Кільце лініями (GL_LINES). */
    public static void ring(BufferBuilder b, Matrix4f m, double cx, double cy, double cz,
                            float radius, float[] c, float a) {
        final int seg = 40;
        for (int i = 0; i < seg; i++) {
            double t1 = 2.0D * Math.PI * i / seg;
            double t2 = 2.0D * Math.PI * (i + 1) / seg;
            line(b, m,
                    (float) (cx + Math.cos(t1) * radius), (float) cy, (float) (cz + Math.sin(t1) * radius),
                    (float) (cx + Math.cos(t2) * radius), (float) cy, (float) (cz + Math.sin(t2) * radius),
                    c, a);
        }
    }

    /** Пласке кільце-смуга (GL_QUADS) з веселковим градієнтом по колу. */
    public static void annulus(BufferBuilder b, Matrix4f m, double cx, double cy, double cz,
                               float r1, float r2, int seg, float a, float hue) {
        for (int i = 0; i < seg; i++) {
            double t1 = 2.0D * Math.PI * i / seg;
            double t2 = 2.0D * Math.PI * (i + 1) / seg;
            float[] col = Chroma.get(hue + i / (float) seg);
            float c1 = (float) Math.cos(t1), s1 = (float) Math.sin(t1);
            float c2 = (float) Math.cos(t2), s2 = (float) Math.sin(t2);
            vert(b, m, (float) (cx + c1 * r1), (float) cy, (float) (cz + s1 * r1), col, a * 0.35F);
            vert(b, m, (float) (cx + c1 * r2), (float) cy, (float) (cz + s1 * r2), col, a);
            vert(b, m, (float) (cx + c2 * r2), (float) cy, (float) (cz + s2 * r2), col, a);
            vert(b, m, (float) (cx + c2 * r1), (float) cy, (float) (cz + s2 * r1), col, a * 0.35F);
        }
    }

    /** Біл-борд зірочка (GL_TRIANGLES). */
    public static void star(BufferBuilder b, Matrix4f m, float cx, float cy, float cz,
                            Vector3f right, Vector3f up, float size, float[] col, float a) {
        final int n = 8;
        float[][] pts = new float[n][];
        for (int i = 0; i < n; i++) {
            double ang = Math.PI / 2.0D + i * Math.PI / 4.0D;
            float rad = (i % 2 == 0) ? size : size * 0.3F;
            pts[i] = at(cx, cy, cz, right, up, (float) Math.cos(ang) * rad, (float) Math.sin(ang) * rad);
        }
        for (int i = 0; i < n; i++) {
            vert(b, m, cx, cy, cz, col, a);
            vertP(b, m, pts[i], col, a * 0.55F);
            vertP(b, m, pts[(i + 1) % n], col, a * 0.55F);
        }
    }

    /** Біл-борд "язичок полум'я" (GL_TRIANGLES). */
    public static void flame(BufferBuilder b, Matrix4f m, float cx, float cy, float cz,
                             Vector3f right, Vector3f up, float size, float[] hot, float[] cool, float a) {
        float[] top = at(cx, cy, cz, right, up, 0.0F, size * 1.6F);
        float[] r = at(cx, cy, cz, right, up, size * 0.65F, size * 0.1F);
        float[] l = at(cx, cy, cz, right, up, -size * 0.65F, size * 0.1F);
        float[] bot = at(cx, cy, cz, right, up, 0.0F, -size * 0.8F);
        vertP(b, m, top, hot, a * 0.8F);
        vertP(b, m, l, cool, a);
        vertP(b, m, r, cool, a);
        vertP(b, m, l, cool, a);
        vertP(b, m, bot, cool, a * 0.4F);
        vertP(b, m, r, cool, a);
    }

    private static float[] at(float cx, float cy, float cz, Vector3f right, Vector3f up, float u, float v) {
        return new float[]{
                cx + right.x() * u + up.x() * v,
                cy + right.y() * u + up.y() * v,
                cz + right.z() * u + up.z() * v};
    }

    /** Текст у світі, повернутий до камери (видно крізь стіни). */
    public static void worldText(Minecraft mc, MatrixStack ms, IRenderTypeBuffer.Impl src, String text,
                                 double x, double y, double z, float scale, int argb, int background) {
        ms.pushPose();
        ms.translate(x, y, z);
        ms.mulPose(mc.getEntityRenderDispatcher().cameraOrientation());
        ms.scale(-scale, -scale, scale);
        float w = mc.font.width(text);
        mc.font.drawInBatch(text, -w / 2.0F, 0.0F, argb, false, ms.last().pose(), src, true, background, 15728880);
        ms.popPose();
    }
}
