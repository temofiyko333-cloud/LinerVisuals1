package com.liner.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Vector3d;

/** Плавно повертає камеру до найближчого ворога (друзі зі списку Team ігноруються). */
public class AimAssist {
    private static LivingEntity current;
    private static long lastNs = 0L;

    public static LivingEntity currentTarget() {
        return current;
    }

    public static void frame(Minecraft mc, float pt) {
        long now = System.nanoTime();
        float dt = lastNs == 0L ? 1.0F : (now - lastNs) / 50000000.0F; // у тіках
        lastNs = now;
        dt = MathHelper.clamp(dt, 0.0F, 2.0F);

        ClientPlayerEntity p = mc.player;
        if (!Config.AIM_ASSIST.on() || p == null || mc.level == null || Freecam.isActive() || !CombatGate.allowed(mc)) {
            current = null;
            return;
        }
        if (mc.screen != null || mc.isPaused() || !p.isAlive() || p.isSpectator()) {
            current = null;
            return;
        }
        if (Config.AIM_ONLY_ATTACK.get() && !mc.options.keyAttack.isDown()) {
            current = null;
            return;
        }

        double range = Config.AIM_RANGE.get();
        double fov = Config.AIM_FOV.get();
        boolean mobs = Config.AIM_MOBS.get();

        if (current != null) {
            boolean ok = Targeting.isValid(mc, current, mobs)
                    && p.canSee(current)
                    && p.getEyePosition(pt).distanceTo(Targeting.aimPoint(current, pt)) <= range + 0.5D;
            if (!ok) current = null;
        }
        if (current == null) {
            current = Targeting.findAimTarget(mc, pt, range, fov, mobs, null);
        }
        if (current == null) return;

        Vector3d eye = p.getEyePosition(pt);
        Vector3d aim = Targeting.aimPoint(current, pt);
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float targetYaw = CombatMath.yawTo(dx, dz);
        float targetPitch = CombatMath.pitchTo(dx, dy, dz);

        float dyaw = CombatMath.wrapDegrees(targetYaw - p.getViewYRot(1.0F));
        float dpitch = targetPitch - p.getViewXRot(1.0F);

        float speed = Config.AIM_SPEED.get().floatValue();
        float stepYaw = CombatMath.aimStep(dyaw, dt, speed);
        float stepPitch = CombatMath.aimStep(dpitch, dt, speed);

        // turn() приймає "одиниці миші": градуси = вхід * 0.15
        p.turn(stepYaw / 0.15D, stepPitch / 0.15D);
    }
}
