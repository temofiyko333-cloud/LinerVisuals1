package net.minecraftforge.common;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

/** Тестова імітація ForgeConfigSpec: ловить дублікати шляхів, значення поза діапазоном і некоректні дефолти. */
public class ForgeConfigSpec {
    public static final Set<String> PATHS = new HashSet<>();

    public static class ConfigValue<T> {
        public final String path;
        protected T value;

        ConfigValue(String path, T value) {
            this.path = path;
            this.value = value;
        }

        public T get() { return value; }
        public void set(T v) { value = v; }
        public void save() { }
    }

    public static class BooleanValue extends ConfigValue<Boolean> { BooleanValue(String p, boolean v) { super(p, v); } }
    public static class IntValue extends ConfigValue<Integer> { IntValue(String p, int v) { super(p, v); } }
    public static class DoubleValue extends ConfigValue<Double> { DoubleValue(String p, double v) { super(p, v); } }
    public static class EnumValue<V extends Enum<V>> extends ConfigValue<V> { EnumValue(String p, V v) { super(p, v); } }

    public static class Builder {
        private final Deque<String> stack = new ArrayDeque<>();

        public Builder comment(String c) { return this; }
        public Builder push(String s) { stack.addLast(s); return this; }
        public Builder pop() { stack.removeLast(); return this; }

        private String path(String key) {
            if (key == null || key.isEmpty() || key.contains(".")) throw new IllegalStateException("bad key: " + key);
            String p = String.join(".", stack) + (stack.isEmpty() ? "" : ".") + key;
            if (!PATHS.add(p)) throw new IllegalStateException("DUPLICATE config path: " + p);
            return p;
        }

        public BooleanValue define(String key, boolean def) { return new BooleanValue(path(key), def); }

        public <T> ConfigValue<T> define(String key, T def) {
            if (def == null) throw new IllegalStateException("null default: " + key);
            return new ConfigValue<>(path(key), def);
        }

        public IntValue defineInRange(String key, int def, int min, int max) {
            if (min > max || def < min || def > max) throw new IllegalStateException("default out of range: " + key);
            return new IntValue(path(key), def);
        }

        public DoubleValue defineInRange(String key, double def, double min, double max) {
            if (min > max || def < min || def > max) throw new IllegalStateException("default out of range: " + key);
            return new DoubleValue(path(key), def);
        }

        public <V extends Enum<V>> EnumValue<V> defineEnum(String key, V def) {
            if (def == null) throw new IllegalStateException("null enum default: " + key);
            return new EnumValue<>(path(key), def);
        }

        public <T> ConfigValue<List<? extends T>> defineList(String key, List<? extends T> def, Predicate<Object> validator) {
            for (Object o : def) if (!validator.test(o)) throw new IllegalStateException("bad list default: " + key);
            return new ConfigValue<List<? extends T>>(path(key), def);
        }

        public ForgeConfigSpec build() { return new ForgeConfigSpec(); }
    }
}
