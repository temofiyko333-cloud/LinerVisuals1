package net.minecraft.client;

public class Minecraft {
    public net.minecraft.client.entity.player.ClientPlayerEntity player;
}
