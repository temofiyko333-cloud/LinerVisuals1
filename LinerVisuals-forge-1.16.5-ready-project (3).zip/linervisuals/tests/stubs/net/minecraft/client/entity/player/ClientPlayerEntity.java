package net.minecraft.client.entity.player;

import java.util.ArrayList;
import java.util.List;

public class ClientPlayerEntity {
    public final List<String> sent = new ArrayList<>();

    public void chat(String message) {
        sent.add(message);
    }
}
