#!/bin/sh
# Тести логіки мода (без Minecraft). Потрібен JDK 8+.  Запуск: sh tests/run.sh
set -e
cd "$(dirname "$0")/.."
JAVAC=${JAVAC:-javac}
rm -rf /tmp/liner-tests && mkdir -p /tmp/liner-tests
$JAVAC -encoding UTF-8 -d /tmp/liner-tests \
  $(find tests/stubs -name '*.java') \
  src/main/java/com/liner/visuals/Config.java \
  src/main/java/com/liner/visuals/Chroma.java \
  src/main/java/com/liner/visuals/CombatMath.java \
  src/main/java/com/liner/visuals/NickMask.java \
  src/main/java/com/liner/visuals/CommandBinds.java \
  src/main/java/com/liner/visuals/FishLogic.java \
  src/main/java/com/liner/visuals/CamMath.java \
  src/main/java/com/liner/visuals/ArmorLogic.java \
  src/main/java/com/liner/visuals/ToolLogic.java \
  src/main/java/com/liner/visuals/CoordsMath.java \
  tests/Check.java
java -Dfile.encoding=UTF-8 -cp /tmp/liner-tests Check
