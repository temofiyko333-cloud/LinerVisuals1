import com.liner.visuals.ArmorLogic;
import com.liner.visuals.CamMath;
import com.liner.visuals.CoordsMath;
import com.liner.visuals.ToolLogic;
import com.liner.visuals.Chroma;
import com.liner.visuals.CombatMath;
import com.liner.visuals.CommandBinds;
import com.liner.visuals.Config;
import com.liner.visuals.FishLogic;
import com.liner.visuals.NickMask;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.regex.Pattern;

/** Тести реальної логіки мода (без запуску Minecraft). Запуск: tests/run.sh */
public class Check {
    static int pass = 0, fail = 0;

    static void ok(String name, boolean cond) {
        if (cond) { pass++; System.out.println("  ok    " + name); }
        else { fail++; System.out.println("  FAIL  " + name); }
    }

    static boolean near(double a, double b, double eps) { return Math.abs(a - b) <= eps; }

    public static void main(String[] args) {
        System.out.println("== Config ==");
        try {
            Config.MODULES.size();
            ok("Config завантажується без дублікатів шляхів та поганих дефолтів", true);
        } catch (Throwable t) {
            ok("Config завантажується: " + t, false);
            summary();
        }
        Set<String> ids = new HashSet<>();
        boolean keysOk = true;
        for (Config.Module m : Config.MODULES) {
            ids.add(m.id);
            int k = m.key.get();
            if (k < -1 || k > 400) keysOk = false;
        }
        ok("id модулів унікальні (" + Config.MODULES.size() + " шт.)", ids.size() == Config.MODULES.size());
        ok("коди клавіш у допустимому діапазоні", keysOk);
        ok("Master увімкнений, прихований, бінд F6 (295)", Config.MASTER.enabled.get() && Config.MASTER.hidden && Config.MASTER.key.get() == 295);
        ok("Aim Assist: вимкнений, бінд K (75)", !Config.AIM_ASSIST.enabled.get() && Config.AIM_ASSIST.key.get() == 75);
        ok("Triggerbot за замовчуванням вимкнений", !Config.TRIGGERBOT.enabled.get());
        ok("Дальність triggerbot за замовчуванням = 3.0", Config.TRIGGER_RANGE.get() == 3.0D);
        ok("Радіус підсвітки гравців за замовчуванням = 30", Config.ESP_RANGE.get() == 30.0D);
        ok("Combat lock увімкнений, у списку 2b2t.org", Config.COMBAT_LOCK.get() && Config.COMBAT_SERVERS.get().contains("2b2t.org"));

        Config.MASTER.enabled.set(true);
        ok("on(): ESP працює, коли Master ON", Config.ESP.on());
        Config.MASTER.enabled.set(false);
        ok("on(): все вимкнено, коли Master OFF", !Config.ESP.on() && !Config.MASTER.on());
        Config.MASTER.enabled.set(true);

        System.out.println("== CombatMath: кути ==");
        ok("ціль на півдні (+Z) -> yaw 0", near(CombatMath.yawTo(0, 1), 0, 1e-3));
        ok("ціль на заході (-X) -> yaw 90", near(CombatMath.yawTo(-1, 0), 90, 1e-3));
        ok("ціль на сході (+X) -> yaw -90", near(CombatMath.yawTo(1, 0), -90, 1e-3));
        ok("ціль на півночі (-Z) -> |yaw| 180", near(Math.abs(CombatMath.yawTo(0, -1)), 180, 1e-3));
        ok("ціль вище -> pitch від'ємний (вгору)", CombatMath.pitchTo(0, 1, 1) < 0 && near(CombatMath.pitchTo(0, 1, 1), -45, 1e-3));
        ok("ціль нижче -> pitch додатний (вниз)", near(CombatMath.pitchTo(1, -1, 0), 45, 1e-3));
        ok("wrap: 190 -> -170", near(CombatMath.wrapDegrees(190), -170, 1e-3));
        ok("wrap: -190 -> 170", near(CombatMath.wrapDegrees(-190), 170, 1e-3));
        ok("wrap: 360 -> 0", near(CombatMath.wrapDegrees(360), 0, 1e-3));
        ok("wrap: короткий шлях 170 -> -170 це +20", near(CombatMath.wrapDegrees(-170 - 170), 20, 1e-3));

        System.out.println("== Aim Assist: плавність ==");
        float[] dts = {0.139F, 0.3F, 1.0F, 2.0F};   // 144 fps, ~60 fps, 20 fps, 10 fps (ліміт)
        for (float dt : dts) {
            float yaw = 0, target = 170, speed = 18;
            boolean monotonic = true, noOvershoot = true, capped = true;
            float prev = yaw;
            int frames = 0;
            while (frames < 3000 && Math.abs(CombatMath.wrapDegrees(target - yaw)) > 0.3F) {
                float d = CombatMath.wrapDegrees(target - yaw);
                float step = CombatMath.aimStep(d, dt, speed);
                if (Math.abs(step) > speed * dt + 1e-4F) capped = false;
                yaw += step;
                if (yaw < prev - 1e-4F) monotonic = false;
                if (yaw > target + 1e-3F) noOvershoot = false;
                prev = yaw;
                frames++;
            }
            ok("dt=" + dt + ": доходить до цілі за " + frames + " кадрів, без ривків і перельоту",
                    frames < 3000 && monotonic && noOvershoot && capped);
        }
        float step = CombatMath.aimStep(CombatMath.wrapDegrees(-170 - 170), 1.0F, 18);
        ok("поворот через 180 градусів іде коротким шляхом (+)", step > 0);
        ok("нульова різниця -> нуль кроку", CombatMath.aimStep(0, 1.0F, 18) == 0);

        System.out.println("== Triggerbot: рішення ==");
        ok("ворог на 2.9 блока, зброя готова -> б'є", CombatMath.shouldAttack(true, 2.9, 3.0, 1.0F));
        ok("рівно 3.0 блока -> б'є", CombatMath.shouldAttack(true, 3.0, 3.0, 1.0F));
        ok("3.01 блока -> НЕ б'є", !CombatMath.shouldAttack(true, 3.01, 3.0, 1.0F));
        ok("5 блоків -> НЕ б'є", !CombatMath.shouldAttack(true, 5.0, 3.0, 1.0F));
        ok("не навівся (невалідна ціль/друг) -> НЕ б'є", !CombatMath.shouldAttack(false, 1.0, 3.0, 1.0F));
        ok("зброя ще не відкотилась (0.5) -> НЕ б'є", !CombatMath.shouldAttack(true, 1.0, 3.0, 0.5F));
        ok("відкат 0.92 -> б'є", CombatMath.shouldAttack(true, 1.0, 3.0, 0.92F));
        ok("власна дальність 2.0: ворог на 2.5 -> НЕ б'є", !CombatMath.shouldAttack(true, 2.5, 2.0, 1.0F));

        System.out.println("== Command Binds (кнопка -> команда) ==");
        Minecraft mc = new Minecraft();
        ClientPlayerEntity pl = new ClientPlayerEntity();
        mc.player = pl;
        Config.COMMAND_BINDS.enabled.set(true);
        ok("normalize('home') -> '/home'", CommandBinds.normalize("home").equals("/home"));
        ok("normalize('  /Home ') -> '/Home'", CommandBinds.normalize("  /Home ").equals("/Home"));
        ok("normalize('') -> ''", CommandBinds.normalize("   ").isEmpty());

        CommandBinds.add("home");
        CommandBinds.add("/spawn");
        CommandBinds.add("   ");
        ok("додано 2 команди (порожня ігнорується)", CommandBinds.all().size() == 2);
        ok("команда збережена зі слешем", CommandBinds.all().get(0).cmd.equals("/home"));
        ok("нова команда без клавіші (-1)", CommandBinds.all().get(0).key == -1);

        CommandBinds.onKey(mc, 75);
        ok("клавіша не призначена -> нічого не відправлено", pl.sent.isEmpty());

        CommandBinds.setKey(0, 75);
        CommandBinds.setKey(1, 76);
        CommandBinds.onKey(mc, 75);
        ok("K -> відправлено рівно '/home'", pl.sent.equals(Arrays.asList("/home")));
        CommandBinds.onKey(mc, 76);
        ok("L -> '/spawn'", pl.sent.equals(Arrays.asList("/home", "/spawn")));
        CommandBinds.onKey(mc, 77);
        CommandBinds.onKey(mc, -1);
        ok("інші/невідомі клавіші нічого не шлють", pl.sent.size() == 2);

        pl.sent.clear();
        Config.COMMAND_BINDS.enabled.set(false);
        CommandBinds.onKey(mc, 75);
        ok("модуль вимкнено -> нічого не відправлено", pl.sent.isEmpty());
        Config.COMMAND_BINDS.enabled.set(true);
        Config.MASTER.enabled.set(false);
        CommandBinds.onKey(mc, 75);
        ok("Master OFF -> нічого не відправлено", pl.sent.isEmpty());
        Config.MASTER.enabled.set(true);

        CommandBinds.add("/msg Bob a|b");
        CommandBinds.setKey(2, 78);
        pl.sent.clear();
        CommandBinds.onKey(mc, 78);
        ok("символ '|' у команді не ламає збереження", pl.sent.equals(Arrays.asList("/msg Bob a|b")));

        CommandBinds.remove(0);
        ok("видалення першої команди", CommandBinds.all().size() == 2 && CommandBinds.all().get(0).cmd.equals("/spawn"));
        CommandBinds.remove(99);
        CommandBinds.remove(-1);
        ok("видалення неіснуючого індексу безпечне", CommandBinds.all().size() == 2);
        CommandBinds.setKey(99, 5);
        ok("setKey з поганим індексом безпечний", CommandBinds.all().size() == 2);

        Config.CMD_BINDS.set(new ArrayList<>(Arrays.asList("garbage", "x|/a", "75|/ok", "|/nokey")));
        ok("пошкоджені рядки в конфігу пропускаються, робочі лишаються",
                CommandBinds.all().size() == 1 && CommandBinds.all().get(0).cmd.equals("/ok"));


        System.out.println("== Auto Fish: цикл ==");
        {
            FishLogic f = new FishLogic(new Random(1));
            int uses = 0;
            for (int t = 0; t < 200; t++) if (f.tick(true, true, 6, false) == FishLogic.Action.USE) uses++;
            ok("без поклювки 200 тіків нічого не робить", uses == 0);

            ok("плюск у перші тіки після закиду (вік 10) ігнорується", !f.onBite(true, 10, 6));
            ok("поклювка від неіснуючого поплавка ігнорується", !f.onBite(false, 100, 6));
            ok("справжня поклювка (вік 40) приймається", f.onBite(true, 40, 6));
            ok("друга поклювка під час підсічки ігнорується", !f.onBite(true, 41, 6));

            int reelAt = -1, recastAt = -1, total = 0;
            boolean bobber = true;
            for (int t = 1; t <= 80; t++) {
                FishLogic.Action a = f.tick(true, bobber, 6, false);
                if (a == FishLogic.Action.USE) {
                    total++;
                    if (reelAt < 0) { reelAt = t; bobber = false; }       // підсікли -> поплавок зник
                    else { recastAt = t; bobber = true; }                 // закинули -> поплавок з'явився
                }
            }
            ok("підсічка через 6..8 тіків після поклювки (було " + reelAt + ")", reelAt >= 6 && reelAt <= 8);
            ok("закид через 14..21 тік після підсічки (було " + (recastAt - reelAt) + ")", recastAt - reelAt >= 14 && recastAt - reelAt <= 21);
            ok("за цикл рівно 2 використання вудки (підсічка + закид)", total == 2);
        }
        {
            FishLogic f = new FishLogic(new Random(2));
            f.onBite(true, 50, 6);
            f.tick(true, true, 6, false);
            boolean used = false;
            for (int t = 0; t < 40; t++) if (f.tick(false, true, 6, false) == FishLogic.Action.USE) used = true;
            ok("вудку прибрали з руки посеред циклу - скидання, жодних дій", !used);
        }
        {
            FishLogic f = new FishLogic(new Random(3));
            f.onBite(true, 50, 6);
            int uses = 0;
            for (int t = 0; t < 60; t++) if (f.tick(true, false, 6, false) == FishLogic.Action.USE) uses++;
            ok("ліску вже зібрано вручну - не закидає зайвий раз", uses == 0);
        }
        {
            FishLogic f = new FishLogic(new Random(4));
            f.onBite(true, 50, 6);
            boolean bobber = true; int uses = 0;
            for (int t = 0; t < 12; t++) { if (f.tick(true, bobber, 6, false) == FishLogic.Action.USE) { uses++; bobber = false; } }
            // користувач закинув сам, поки йшла пауза перед закидом
            bobber = true;
            for (int t = 0; t < 60; t++) if (f.tick(true, bobber, 6, false) == FishLogic.Action.USE) uses++;
            ok("користувач закинув сам під час паузи - мод не закидає вдруге", uses == 1);
        }
        {
            FishLogic f = new FishLogic(new Random(5));
            int firstUse = -1;
            for (int t = 1; t <= FishLogic.MAX_WAIT_TICKS + 40; t++) {
                if (f.tick(true, true, 6, false) == FishLogic.Action.USE) { firstUse = t; break; }
            }
            ok("вудка застрягла (немає поклювки ~60 с) - сама підсікає (тік " + firstUse + ")",
                    firstUse > FishLogic.MAX_WAIT_TICKS && firstUse <= FishLogic.MAX_WAIT_TICKS + 10);
        }
        {
            FishLogic f = new FishLogic(new Random(6));
            int uses = 0;
            for (int t = 0; t < 500; t++) if (f.tick(true, false, 6, false) == FishLogic.Action.USE) uses++;
            ok("авто-закид вимкнено: з вудкою в руці без ліски нічого не робить", uses == 0);

            FishLogic g = new FishLogic(new Random(7));
            int castTick = -1, castUses = 0; boolean bobber = false;
            for (int t = 1; t <= 300; t++) {
                if (g.tick(true, bobber, 6, true) == FishLogic.Action.USE) { castUses++; if (castTick < 0) castTick = t; bobber = true; }
            }
            ok("авто-закид увімкнено: закидає за ~2 с (тік " + castTick + "), без спаму (разів: " + castUses + ")",
                    castTick >= 35 && castTick <= 45 && castUses == 1);
        }
        {
            FishLogic f = new FishLogic(new Random(8));
            ok("опис стану: idle / waiting", f.describe(false).equals("idle") && f.describe(true).equals("waiting for bite"));
            f.onBite(true, 50, 6);
            ok("опис стану: reeling in", f.describe(true).equals("reeling in"));
        }


        System.out.println("== Freecam: рух камери ==");
        {
            double[] d;
            d = CamMath.move(0, 0, true, false, false, false, false, false, 1.0, 1.0F);
            ok("вперед при yaw 0 (південь) -> +Z", near(d[0], 0, 1e-9) && near(d[1], 0, 1e-9) && near(d[2], 1, 1e-9));
            d = CamMath.move(90, 0, true, false, false, false, false, false, 1.0, 1.0F);
            ok("вперед при yaw 90 (захід) -> -X", near(d[0], -1, 1e-9) && near(d[2], 0, 1e-9));
            d = CamMath.move(-90, 0, true, false, false, false, false, false, 1.0, 1.0F);
            ok("вперед при yaw -90 (схід) -> +X", near(d[0], 1, 1e-9));
            d = CamMath.move(0, 0, false, true, false, false, false, false, 1.0, 1.0F);
            ok("назад -> -Z", near(d[2], -1, 1e-9));
            d = CamMath.move(0, 0, false, false, false, true, false, false, 1.0, 1.0F);
            ok("вправо при yaw 0 -> -X (права рука дивлячись на південь)", near(d[0], -1, 1e-9) && near(d[2], 0, 1e-9));
            d = CamMath.move(0, 0, false, false, true, false, false, false, 1.0, 1.0F);
            ok("вліво при yaw 0 -> +X", near(d[0], 1, 1e-9));
            d = CamMath.move(90, 0, false, false, false, true, false, false, 1.0, 1.0F);
            ok("вправо при yaw 90 (дивимось на захід) -> -Z (північ)", near(d[0], 0, 1e-9) && near(d[2], -1, 1e-9));
            d = CamMath.move(0, 0, false, false, false, false, true, false, 1.0, 1.0F);
            ok("Space -> вгору (+Y)", near(d[1], 1, 1e-9) && near(d[0], 0, 1e-9));
            d = CamMath.move(0, 0, false, false, false, false, false, true, 1.0, 1.0F);
            ok("Shift -> вниз (-Y)", near(d[1], -1, 1e-9));
            d = CamMath.move(0, -90, true, false, false, false, false, false, 1.0, 1.0F);
            ok("дивишся вгору (pitch -90) і йдеш вперед -> летиш вгору", near(d[1], 1, 1e-9));
            d = CamMath.move(0, 90, true, false, false, false, false, false, 1.0, 1.0F);
            ok("дивишся вниз (pitch 90) і йдеш вперед -> летиш вниз", near(d[1], -1, 1e-9));
            d = CamMath.move(0, 0, true, true, false, false, false, false, 1.0, 1.0F);
            ok("вперед+назад одночасно -> стоїмо", d[0] == 0 && d[1] == 0 && d[2] == 0);
            d = CamMath.move(0, 0, false, false, false, false, false, false, 1.0, 1.0F);
            ok("жодної клавіші -> стоїмо", d[0] == 0 && d[1] == 0 && d[2] == 0);
            d = CamMath.move(37, 20, true, false, false, true, true, false, 0.6, 1.0F);
            ok("діагональ (вперед+вправо+вгору) не швидша за швидкість 0.6",
                    near(Math.sqrt(d[0]*d[0] + d[1]*d[1] + d[2]*d[2]), 0.6, 1e-9));
            d = CamMath.move(0, 0, true, false, false, false, false, false, 0.6, 0.5F);
            ok("розмір кроку пропорційний часу кадру (0.6 * 0.5)", near(d[2], 0.3, 1e-9));
            final float dtFast = 0.139F;   // ~144 fps
            double total = 0;
            for (int i = 0; i < 20; i++) total += CamMath.move(0, 0, true, false, false, false, false, false, 0.6, dtFast)[2];
            double second = 0;
            for (int i = 0; i < 20; i++) second += CamMath.move(0, 0, true, false, false, false, false, false, 0.6, 1.0F)[2];
            ok("швидкість за тік однакова при різному FPS (144 fps ~ 20 fps)", near(total / (20 * (double) dtFast), second / 20, 1e-9));
            d = CamMath.move(0, 0, true, false, false, false, false, false, 0.6, 1.0F);
            ok("Config: швидкість Freecam за замовчуванням 0.6", Config.FREECAM_SPEED.get() == 0.6D && Config.FREECAM_AUTO_OFF.get());
            ok("Freecam за замовчуванням вимкнений", !Config.FREECAM.enabled.get());
        }


        System.out.println("== Auto Armor: оцінка ==");
        {
            double leather = ArmorLogic.score(3, 0, 0, 0, 0, 0, 0, 80, 80, false);
            double gold    = ArmorLogic.score(5, 0, 0, 0, 0, 0, 0, 77, 77, false);
            double chain   = ArmorLogic.score(5, 0, 0, 0, 0, 0, 0, 240, 240, false);
            double iron    = ArmorLogic.score(6, 0, 0, 0, 0, 0, 0, 240, 240, false);
            double diamond = ArmorLogic.score(8, 2, 0, 0, 0, 0, 0, 528, 528, false);
            double netherite = ArmorLogic.score(8, 3, 0, 0, 0, 0, 0, 592, 592, false);
            ok("порядок нагрудників: шкіра < золото/кольчуга < залізо < алмаз < незерит",
                    leather < gold && gold <= chain && chain < iron && iron < diamond && diamond < netherite);
            double ironProt4 = ArmorLogic.score(6, 0, 4, 0, 0, 0, 0, 240, 240, false);
            ok("залізо з Protection IV краще за звичайний алмаз", ironProt4 > diamond);
            double diamondProt4 = ArmorLogic.score(8, 2, 4, 0, 0, 0, 3, 528, 528, false);
            ok("алмаз Prot IV + Unbreaking III краще за алмаз без чарів", diamondProt4 > diamond);
            double brokenDiamond = ArmorLogic.score(8, 2, 0, 0, 0, 0, 0, 2, 528, false);
            ok("алмаз на межі поломки (2 міцності) гірший за свіже залізо", brokenDiamond < iron);
            double halfDiamond = ArmorLogic.score(8, 2, 0, 0, 0, 0, 0, 264, 528, false);
            ok("наполовину зношений алмаз все ще кращий за нове залізо", halfDiamond > iron);
            ok("прокляття прив'язки - ніколи не обирається", ArmorLogic.score(8, 3, 4, 0, 0, 0, 3, 592, 592, true) < leather);
            ok("worthSwap: різниця 0.1 - не міняти", !ArmorLogic.worthSwap(9.0, 9.1));
            ok("worthSwap: різниця 1.0 - міняти", ArmorLogic.worthSwap(9.0, 10.0));
            ok("порожній слот (-1) - будь-яка броня краще", ArmorLogic.worthSwap(-1.0, leather));
        }

        System.out.println("== Auto Tool: вибір інструмента ==");
        {
            final int U = ToolLogic.UNBREAKABLE;
            double hand = ToolLogic.blockScore(1.0F, 0, false, U);
            double ironPick = ToolLogic.blockScore(6.0F, 0, true, 250);
            double ironPickEff5 = ToolLogic.blockScore(6.0F, 5, true, 250);
            double woodPickOnObsidian = ToolLogic.blockScore(2.0F, 0, false, 59);
            double diamondPickOnObsidian = ToolLogic.blockScore(8.0F, 0, true, 1561);
            ok("кирка проти каменю краща за руку", ironPick > hand);
            ok("Efficiency V робить кирку ще кращою", ironPickEff5 > ironPick);
            ok("Efficiency не діє на предмет, що не прискорює (швидкість 1)", ToolLogic.blockScore(1.0F, 5, false, U) == 1.0D);
            ok("дерев'яна кирка на обсидіані (дроп не випаде) гірша за алмазну", woodPickOnObsidian < diamondPickOnObsidian);
            ok("майже зламаний інструмент (1 міцності) не береться", ToolLogic.blockScore(8.0F, 0, true, 1) < 0);
            ok("інструмент з 2 міцності ще можна", ToolLogic.blockScore(8.0F, 0, true, 2) > 1000);
            double[] sc = new double[9];
            java.util.Arrays.fill(sc, 1.0);
            sc[3] = ironPick;
            ok("є кирка в слоті 3 -> обираємо 3", ToolLogic.pickBest(sc, 0, 0.5) == 3);
            ok("уже тримаємо найкращий -> міняти не треба (-1)", ToolLogic.pickBest(sc, 3, 0.5) == -1);
            double[] eq = new double[9];
            java.util.Arrays.fill(eq, 1.0);
            ok("усе однакове -> не міняємо", ToolLogic.pickBest(eq, 4, 0.5) == -1);
            double[] close = new double[9];
            java.util.Arrays.fill(close, 1000.0);
            close[2] = 1000.2;
            ok("виграш менший за поріг (0.2 < 0.5) -> не міняємо", ToolLogic.pickBest(close, 0, 0.5) == -1);
            double[] broken = new double[9];
            java.util.Arrays.fill(broken, 1.0);
            broken[1] = ToolLogic.blockScore(8.0F, 0, true, 1);
            ok("зламаний інструмент не вибирається навіть якщо він швидкий", ToolLogic.pickBest(broken, 0, 0.5) == -1);

            double dSword = ToolLogic.weaponScore(6.0, 0, -2.4, U);   // алмазний меч (шкода 7, швидкість 1.6)
            double dAxe   = ToolLogic.weaponScore(8.0, 0, -3.0, U);   // алмазна сокира (шкода 9, швидкість 1.0)
            double fist   = ToolLogic.weaponScore(0.0, 0, 0.0, U);
            double sharpIron = ToolLogic.weaponScore(5.0, 3.0, -2.4, U); // залізний меч Sharpness V
            ok("алмазний меч (DPS) кращий за алмазну сокиру", dSword > dAxe);
            ok("будь-яка зброя краща за кулак", dSword > fist && dAxe > fist);
            ok("залізний меч Sharpness V кращий за звичайний алмазний", sharpIron > dSword);
            ok("зброя з 1 міцності не береться", ToolLogic.weaponScore(6.0, 0, -2.4, 1) < 0);
        }

        System.out.println("== Coords & Death Point ==");
        {
            ok("yaw 0 -> South (+Z)", CoordsMath.facing(0).equals("South (+Z)"));
            ok("yaw 90 -> West (-X)", CoordsMath.facing(90).equals("West (-X)"));
            ok("yaw 180 -> North (-Z)", CoordsMath.facing(180).equals("North (-Z)"));
            ok("yaw -180 -> North (-Z)", CoordsMath.facing(-180).equals("North (-Z)"));
            ok("yaw -90 -> East (+X)", CoordsMath.facing(-90).equals("East (+X)"));
            ok("yaw 270 -> East (+X)", CoordsMath.facing(270).equals("East (+X)"));
            ok("yaw 360 -> South (+Z)", CoordsMath.facing(360).equals("South (+Z)"));
            ok("межа секторів: 44 - South, 46 - West", CoordsMath.facing(44).equals("South (+Z)") && CoordsMath.facing(46).equals("West (-X)"));
            double[] n = CoordsMath.otherDimension(800, -1600, false);
            ok("оверворлд (800, -1600) -> незер (100, -200)", n[0] == 100 && n[1] == -200);
            double[] o = CoordsMath.otherDimension(100, -200, true);
            ok("незер (100, -200) -> оверворлд (800, -1600)", o[0] == 800 && o[1] == -1600);
            ok("block() округлює вниз, як блоки: -0.5 -> -1, 12.9 -> 12", CoordsMath.block(-0.5).equals("-1") && CoordsMath.block(12.9).equals("12"));
            ok("Config: Auto Tool увімкнений за замовчуванням, Auto Armor вимкнений", Config.AUTO_TOOL.enabled.get() && !Config.AUTO_ARMOR.enabled.get());
            ok("Config: Coords увімкнений, місце смерті порожнє", Config.COORDS.enabled.get() && Config.DEATH_POINT.get().isEmpty());
        }


        System.out.println("== Безпечний режим сервера ==");
        {
            java.util.function.BooleanSupplier saved = Config.ADVANTAGE_ALLOWED;
            Config.MASTER.enabled.set(true);
            for (Config.Module m : Config.MODULES) m.enabled.set(true);

            Config.ADVANTAGE_ALLOWED = () -> false;   // сервер не зі списку
            boolean unsafeOff = true, safeOn = true;
            for (Config.Module m : Config.MODULES) {
                if (m == Config.MASTER) continue;
                if (m.safe() && !m.on()) safeOn = false;
                if (!m.safe() && m.on()) unsafeOff = false;
            }
            ok("на чужому сервері ВСІ модулі з перевагою вимкнені, навіть якщо ввімкнені в налаштуваннях", unsafeOff);
            ok("безпечні (косметика/HUD) модулі працюють", safeOn);
            ok("Master не залежить від блокування", Config.MASTER.on());

            String[] mustBeLocked = {"aimassist", "triggerbot", "shieldbreak", "autototem", "autoarmor", "esp", "tracers",
                    "nametags", "pulse", "pearlpath", "aimhint", "fullbright", "freecam", "autofish", "autoeat", "autotool", "itemscroller"};
            boolean all = true;
            for (String id : mustBeLocked) {
                boolean found = false;
                for (Config.Module m : Config.MODULES) if (m.id.equals(id)) { found = true; if (m.safe() || m.on()) all = false; }
                if (!found) all = false;
            }
            ok("модулі з переваги блокуються, id збігаються з реальними і не потрапили в безпечні", all);

            String[] mustBeSafe = {"watermark", "fps", "ping", "effectshud", "armorhud", "hitparticles", "chinahat", "streamer", "commandbinds"};
            boolean sOk = true;
            for (String id : mustBeSafe) for (Config.Module m : Config.MODULES) if (m.id.equals(id) && !m.on()) sOk = false;
            ok("FPS/ping/вотермарка/ефекти/броня/партикли/стрімер/бінди команд лишаються доступні", sOk);
            ok("lockedHere(): true для aim assist, false для вотермарки",
                    Config.AIM_ASSIST.lockedHere() && !Config.WATERMARK.lockedHere());

            Config.ADVANTAGE_ALLOWED = () -> true;    // одиночна гра / сервер зі списку
            boolean allOn = true;
            for (Config.Module m : Config.MODULES) if (!m.on()) allOn = false;
            ok("у дозволеному місці працює все, що ввімкнено", allOn);

            Config.ADVANTAGE_ALLOWED = saved;
            for (Config.Module m : Config.MODULES) m.enabled.set(false);
            Config.MASTER.enabled.set(true);
            Config.ESP.enabled.set(true);
            Config.WATERMARK.enabled.set(true);
            Config.COMMAND_BINDS.enabled.set(true);
            Config.CHROMA.enabled.set(true);
        }

        System.out.println("== Streamer: заміна ніка ==");
        Pattern p = NickMask.pattern("Steve");
        ok("<Steve> hi -> <Player> hi", NickMask.mask("<Steve> hi", p, "Player").equals("<Player> hi"));
        ok("регістр не важливий: steve/STEVE", NickMask.mask("steve and STEVE", p, "X").equals("X and X"));
        ok("інший нік Steve_2 не чіпається", NickMask.mask("Steve_2 joined", p, "X").equals("Steve_2 joined"));
        ok("MySteve (частина слова) не чіпається", NickMask.mask("MySteve", p, "X").equals("MySteve"));
        ok("Steve! та (Steve) - замінюються", NickMask.mask("Steve! (Steve)", p, "Q").equals("Q! (Q)"));
        ok("спецсимволи в аліасі безпечні ($1, \\)", NickMask.mask("Steve", p, "$1\\x").equals("$1\\x"));
        ok("спецсимволи в ніку екрануються (A.B)", NickMask.mask("AxB A.B", NickMask.pattern("A.B"), "Z").equals("AxB Z"));
        ok("повідомлення без ніка лишається як було", NickMask.mask("hello world", p, "X").equals("hello world"));

        System.out.println("== Chroma ==");
        Config.CHROMA.enabled.set(true);
        boolean range = true;
        for (float o = -1.0F; o <= 2.0F; o += 0.07F) {
            float[] c = Chroma.get(o);
            if (c.length != 3) range = false;
            for (float v : c) if (v < 0 || v > 1.0001F) range = false;
        }
        ok("Chroma.get завжди повертає RGB у [0,1]", range);
        Config.CHROMA.enabled.set(false);
        float[] th = Chroma.get(0.3F);
        ok("Chroma вимкнено -> колір теми #B359FF", near(th[0], 0xB3 / 255.0, 1e-3) && near(th[1], 0x59 / 255.0, 1e-3) && near(th[2], 1.0, 1e-3));
        Config.CHROMA.enabled.set(true);
        ok("mixRgb(чорний, білий, 0) = чорний", Chroma.mixRgb(0x000000, 0xFFFFFF, 0f) == 0x000000);
        ok("mixRgb(чорний, білий, 1) = білий", Chroma.mixRgb(0x000000, 0xFFFFFF, 1f) == 0xFFFFFF);
        ok("mixRgb середина = сірий", Chroma.mixRgb(0x000000, 0xFFFFFF, 0.5f) == 0x7F7F7F);
        ok("mixRgb обрізає t поза [0,1]", Chroma.mixRgb(0x102030, 0xF0E0D0, 5f) == 0xF0E0D0);

        summary();
    }

    static void summary() {
        System.out.println();
        System.out.println("Разом: " + pass + " пройдено, " + fail + " провалено");
        System.exit(fail == 0 ? 0 : 1);
    }
}
